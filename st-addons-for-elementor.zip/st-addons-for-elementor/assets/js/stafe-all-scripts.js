(function ($, elementor) {
    "use strict";
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-alex-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-alex-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-alice-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-alice-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-alter-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-alter-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (n, e) {
        "use strict";
        var t = function (n, e) {
            var t = n.find(".stafe-amox-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    e(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-amox-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (n, e) {
        "use strict";
        var t = function (n, e) {
            var t = n.find(".stafe-buzz-list-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    e(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-buzz-list-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var o = function (e, n) {
            var o = e.find(".stafe-camux-slider");
            if (!o.length) return;
            var t = o.find(".swiper-carousel"),
                i = o.data("settings");
            const r = elementorFrontend.utils.swiper;
            !(async function () {
                var o = await new r(t, i);
                i.pauseOnHover &&
                    n(t).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
                var s = e.find(".stafe-camux-slider-wrap").find(".stafe-camux-thumbs"),
                    l = await new r(s, {
                        spaceBetween: 10,
                        slidesPerView: 4,
                        touchRatio: 0.2,
                        slideToClickedSlide: !0,
                        loop: !!i.loop && i.loop,
                        speed: i.speed ? i.speed : 500,
                        loopedSlides: 4,
                        breakpoints: { 0: { slidesPerView: 2 }, 768: { slidesPerView: 3 }, 1024: { slidesPerView: 4 } },
                    });
                (o.controller.control = l), (l.controller.control = o);
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-camux-slider.default", o);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var o = function (e, n) {
            var o = e.find(".stafe-carbon-main");
            if (!o.length) return;
            var t = o.find(".swiper-carousel"),
                r = o.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                var o = await new i(t, r);
                r.pauseOnHover &&
                    n(t).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
                var s = e.find(".stafe-carbon-slider-wrap").find(".stafe-carbon-thumbs"),
                    a = await new i(s, {
                        spaceBetween: 0,
                        slidesPerView: 1,
                        touchRatio: 0.2,
                        slideToClickedSlide: !0,
                        centeredSlides: !0,
                        loop: !!r.loop && r.loop,
                        speed: r.speed ? r.speed : 500,
                        loopedSlides: 4,
                        breakpoints: { 768: { slidesPerView: 3, spaceBetween: 20 } },
                    });
                (o.controller.control = a), (a.controller.control = o);
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-carbon-slider.default", o);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-category-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-category-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (n, e) {
        "use strict";
        var t = function (n, e) {
            var t = n.find(".stafe-crystal-slider");
            if (!t.length) return;
            var r = t.find(".swiper-carousel"),
                o = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(r, o);
                o.pauseOnHover &&
                    e(r).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-crystal-slider.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-elite-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-elite-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (n, e) {
        "use strict";
        var t = function (n, e) {
            var t = n.find(".stafe-harold-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    e(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-harold-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-hazel-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-hazel-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-maple-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-maple-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-news-ticker"),
                o = t.data("settings");
            t.length && n(t).upkNewsTicker(o);
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-news-ticker.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e) {
        (e.alert = function (t) {
            e.alert.hide(),
                e(
                    (function (e, t, n) {
                        return ['<div class="stafe-newsletter-' + e + " " + t + '">', '<div class="stafe-alert-box">', n, "</div>", "</div>"].join("");
                    })("alert", "", { text: t }.text)
                ).appendTo(document.body);
        }),
            (e.alert.hide = function () {
                e(".stafe-newsletter-alert").slideUp(800).remove();
            });
    })(jQuery),
        (function (e, t) {
            "use strict";
            var n = function (e, t) {
                var n = e.find(".stafe-newsletter");
                if (n.length) {
                    var i = window.STAddonsElementorConfig.mailchimp;
                    return (
                        n.submit(function () {
                            var e = t(this);
                            return (
                                t.alert('<span class="uwk-newsletter-loader"></span>' + i.subscribing),
                                t.ajax({
                                    url: e.attr("action"),
                                    type: "POST",
                                    data: e.serialize(),
                                    success: function (e) {
                                        setTimeout(function () {
                                            t.alert(e),
                                                setTimeout(function () {
                                                    t.alert.hide();
                                                }, 5e3);
                                        }, 2e3);
                                    },
                                }),
                                !1
                            );
                        }),
                        !1
                    );
                }
            };
            jQuery(window).on("elementor/frontend/init", function () {
                elementorFrontend.hooks.addAction("frontend/element_ready/stafe-newsletter.default", n);
            });
        })(jQuery, window.elementorFrontend);
    !(function (n, e) {
        "use strict";
        var t = function (n, e) {
            var t = n.find(".stafe-noxe-slider");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    e(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-noxe-slider.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (n, e) {
        "use strict";
        var t = function (n, e) {
            var t = n.find(".stafe-paradox-slider");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    e(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-paradox-slider.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, i) {
        "use strict";
        var o = function (e, i) {
            var o = e.find(".stafe-pholox-slider"),
                n = o.data("settings");
            o.data("widget");
            if (!o.length) return;
            const r = elementorFrontend.utils.swiper;
            !(async function () {
                var e = o.find(".stafe-thumbs-slider .swiper-thumbs"),
                    t = o.find(".stafe-main-slider .swiper-carousel"),
                    d = await new r(t, n),
                    s = await new r(e, {
                        spaceBetween: 15,
                        slidesPerView: 2,
                        touchRatio: 0.2,
                        slideToClickedSlide: !0,
                        loop: !!n.loop && n.loop,
                        speed: n.speed ? n.speed : 500,
                        loopedSlides: 4,
                        breakpoints: { 768: { slidesPerView: 3, spaceBetween: 20 }, 1440: { slidesPerView: 4, spaceBetween: 30 } },
                    });
                (d.controller.control = s),
                    (s.controller.control = d),
                    d.on("slideChange", function () {
                        a();
                    });
                var a = function () {
                    o.find(".stafe-video-wrap").css("z-index", -1);
                    var e = o.find(".stafe-video-iframe");
                    Array.prototype.forEach.call(e, function (e) {
                        var i = e.src;
                        (e.src = i.replace("autoplay=1", "")), o.find(".stafe-video-iframe").prop("src", "");
                    });
                };
                o.find(".stafe-pholox-video-trigger").on("click", function () {
                    console.log("s");
                    var e = i(this).data("src").split("?")[0],
                        n = o.find(".stafe-main-slider .swiper-slide-active .stafe-img-wrap");
                    o.find(".stafe-img-wrap").removeClass("stafe-width-100"),
                        i(n).addClass("stafe-width-100"),
                        n.find(".stafe-video-iframe").attr("src", e + "?autoplay=1&modestbranding=1&showinfo=0&rel=0&controls=0&loop=1"),
                        n.find(".stafe-video-wrap").css("z-index", 10);
                });
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-pholox-slider.default", o);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var t = function (e, n) {
            var t = e.find(".stafe-ramble-carousel");
            if (!t.length) return;
            var o = t.find(".swiper-carousel"),
                r = t.data("settings");
            const i = elementorFrontend.utils.swiper;
            !(async function () {
                await new i(o, r);
                r.pauseOnHover &&
                    n(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-ramble-carousel.default", t);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var r = function (e, n) {
            var r = e.find(".stafe-reading-progress"),
                o = r.data("settings");
            r.length && (n(".stafe-reading-progress-wrap") && n(".stafe-reading-progress-wrap").remove(), jQuery.scrolline(o), n("body.admin-bar").length && "top" == o.position && n(".stafe-reading-progress-wrap").css("margin-top", 32));
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-reading-progress.default", r);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, n) {
        "use strict";
        var o = function (e, n) {
            var o = e.find(".stafe-skide-slider");
            if (!o.length) return;
            var t = o.find(".swiper-carousel"),
                i = o.data("settings");
            const r = elementorFrontend.utils.swiper;
            !(async function () {
                var o = await new r(t, i);
                i.pauseOnHover &&
                    n(t).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
                var s = e.find(".stafe-skide-slider-wrap").find(".stafe-skide-thumbs"),
                    d = await new r(s, {
                        spaceBetween: 10,
                        slidesPerView: 2,
                        touchRatio: 0.2,
                        slideToClickedSlide: !0,
                        loop: !!i.loop && i.loop,
                        speed: i.speed ? i.speed : 500,
                        loopedSlides: 4,
                        breakpoints: { 1024: { slidesPerView: 3, spaceBetween: 20 } },
                    });
                (o.controller.control = d), (d.controller.control = o);
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-skide-slider.default", o);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e, i) {
        "use strict";
        var n = function (e, i) {
            var n = e.find(".stafe-snog-slider");
            if (!n.length) return;
            var o = n.find(".stafe-main-slider"),
                t = n.data("settings"),
                d = n.data("widget-settings");
            const l = elementorFrontend.utils.swiper;
            !(async function () {
                var n = await new l(o, t);
                t.pauseOnHover &&
                    i(o).hover(
                        function () {
                            this.swiper.autoplay.stop();
                        },
                        function () {
                            this.swiper.autoplay.start();
                        }
                    );
                var s = e.find(".stafe-snog-slider-wrap").find(".stafe-snog-thumbs"),
                    a = await new l(s, { spaceBetween: 0, effect: "slide", lazy: !0, slidesPerView: 2, touchRatio: 0.2, loop: !!t.loop && t.loop, speed: t.speed ? t.speed : 800, loopedSlides: 4 }),
                    r = await new l(i(d.id).find(".stafe-content-slider"), {
                        parallax: !0,
                        effect: "fade",
                        slidesPerView: 1,
                        loop: !!t.loop && t.loop,
                        speed: t.speed ? t.speed : 800,
                        loopedSlides: 4,
                        allowTouchMove: !1,
                        pagination: { el: d.id + " .stafe-pagination", clickable: !0 },
                    });
                (n.controller.control = a),
                    (a.controller.control = n),
                    i(document).ready(function () {
                        setTimeout(() => {
                            var e = i(d.id).find(".stafe-main-slider")[0].swiper,
                                n = i(d.id).find(".stafe-main-slider .swiper-slide-active"),
                                o = n.data("swiper-slide-index");
                            void 0 === o && (o = n.index()),
                                i(d.id)
                                    .find(".stafe-navigation-prev")
                                    .on("click", function () {
                                        e.slidePrev();
                                    }),
                                i(d.id)
                                    .find(".stafe-navigation-next")
                                    .on("click", function () {
                                        e.slideNext();
                                    }),
                                i(d.id)
                                    .find(".swiper-pagination-bullet")
                                    .on("click", function () {
                                        var n = i(this).index();
                                        t.loop ? e.slideToLoop(n) : e.slideTo(n), i(d.id).addClass("wait--");
                                    }),
                                e.on("slideChange", function (i) {
                                    r.slideToLoop(e.realIndex);
                                });
                        }, 3e3);
                    });
            })();
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-snog-slider.default", n);
        });
    })(jQuery, window.elementorFrontend);
    !(function (e) {
        e(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-static-social-count.default", function (t) {
                t.find(".stafe-static-social-count").each(function () {
                    var t = e(this)[0],
                        n = e(t).find(".counter-value");
                    t &&
                        e(n).each(function () {
                            var t = e(this);
                            jQuery({ Counter: 0 }).animate(
                                { Counter: t.text() },
                                {
                                    duration: 3e3,
                                    easing: "swing",
                                    step: function () {
                                        t.text(
                                            (function (e) {
                                                if ((e = e.toString().replace(/[^0-9.]/g, "")) <= 999) return Math.ceil(e);
                                                let t,
                                                    n = [
                                                        { v: 1e3, s: "K" },
                                                        { v: 1e6, s: "M" },
                                                        { v: 1e9, s: "B" },
                                                        { v: 1e12, s: "T" },
                                                        { v: 1e15, s: "P" },
                                                        { v: 1e18, s: "E" },
                                                    ];
                                                for (t = n.length - 1; t > 0 && !(e >= n[t].v); t--);
                                                return (e / n[t].v).toFixed(2).replace(/\.0+$|(\.[0-9]*[1-9])0+$/, "$1") + n[t].s;
                                            })(this.Counter)
                                        );
                                    },
                                }
                            );
                        });
                });
            });
        });
    })(jQuery);
    !(function (n, i) {
        "use strict";
        var e = function (n, i) {
            var e = n.find(".stafe-in-animation");
            if (e.length) {
                var t,
                    a = [],
                    r = e.data("in-animation-delay") ? e.data("in-animation-delay") : 200;
                elementorFrontend.waypoint(
                    jQuery(".stafe-in-animation .stafe-item"),
                    function () {
                        a.push(i(this)), l();
                    },
                    { offset: "90%" }
                );
            }
            function l() {
                t ||
                    (t = window.setInterval(function () {
                        a.length ? (jQuery(a.shift()).addClass("is-inview"), l()) : (window.clearInterval(t), (t = null));
                    }, r));
            }
        };
        jQuery(window).on("elementor/frontend/init", function () {
            n.each(
                [
                    "alex-grid",
                    "alice-grid",
                    "alter-grid",
                    "amox-grid",
                    "buzz-list",
                    "classic-list",
                    "elite-grid",
                    "fanel-list",
                    "featured-list",
                    "harold-list",
                    "hazel-grid",
                    "kalon-grid",
                    "maple-grid",
                    "ramble-grid",
                    "recent-comments",
                    "scott-list",
                    "tiny-list",
                    "welsh-list",
                    "wixer-grid",
                ],
                function (n, i) {
                    elementorFrontend.hooks.addAction("frontend/element_ready/stafe-" + i + ".default", e);
                }
            );
        });
    })(jQuery, window.elementorFrontend);
    ("use strict");
    (function () {
        function k(e, b) {
            if (!(e instanceof b)) throw new TypeError("Cannot call a class as a function");
        }
        function z(e, b) {
            for (var f = 0; f < b.length; f++) {
                var a = b[f];
                a.enumerable = a.enumerable || !1;
                a.configurable = !0;
                "value" in a && (a.writable = !0);
                var c = Object,
                    d = c.defineProperty;
                a: {
                    var g = a.key;
                    if ("object" === typeof g && null !== g) {
                        var h = g[Symbol.toPrimitive];
                        if (void 0 !== h) {
                            g = h.call(g, "string");
                            if ("object" !== typeof g) break a;
                            throw new TypeError("@@toPrimitive must return a primitive value.");
                        }
                        g = String(g);
                    }
                }
                d.call(c, e, "symbol" === typeof g ? g : String(g), a);
            }
        }
        function l(e, b, f) {
            b && z(e.prototype, b);
            f && z(e, f);
            Object.defineProperty(e, "prototype", { writable: !1 });
            return e;
        }
        function p(e, b) {
            if ("function" !== typeof b && null !== b) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(b && b.prototype, { constructor: { value: e, writable: !0, configurable: !0 } });
            Object.defineProperty(e, "prototype", { writable: !1 });
            b && v(e, b);
        }
        function u(e) {
            u = Object.setPrototypeOf
                ? Object.getPrototypeOf.bind()
                : function (b) {
                      return b.__proto__ || Object.getPrototypeOf(b);
                  };
            return u(e);
        }
        function v(e, b) {
            v = Object.setPrototypeOf
                ? Object.setPrototypeOf.bind()
                : function (f, a) {
                      f.__proto__ = a;
                      return f;
                  };
            return v(e, b);
        }
        function B() {
            if ("undefined" === typeof Reflect || !Reflect.construct || Reflect.construct.sham) return !1;
            if ("function" === typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})), !0;
            } catch (e) {
                return !1;
            }
        }
        function n(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e;
        }
        function q(e) {
            var b = B();
            return function () {
                var f = u(e);
                if (b) {
                    var a = u(this).constructor;
                    f = Reflect.construct(f, arguments, a);
                } else f = f.apply(this, arguments);
                if (!f || ("object" !== typeof f && "function" !== typeof f)) {
                    if (void 0 !== f) throw new TypeError("Derived constructors may only return object or undefined");
                    f = n(this);
                }
                return f;
            };
        }
        function t(e) {
            var b = Array.isArray(e) ? w(e) : void 0;
            b || (b = ("undefined" !== typeof Symbol && null != e[Symbol.iterator]) || null != e["@@iterator"] ? Array.from(e) : void 0);
            if (!b)
                a: {
                    if (e) {
                        if ("string" === typeof e) {
                            b = w(e, void 0);
                            break a;
                        }
                        b = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === b && e.constructor && (b = e.constructor.name);
                        if ("Map" === b || "Set" === b) {
                            b = Array.from(e);
                            break a;
                        }
                        if ("Arguments" === b || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(b)) {
                            b = w(e, void 0);
                            break a;
                        }
                    }
                    b = void 0;
                }
            if (!(e = b)) throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            return e;
        }
        function w(e, b) {
            if (null == b || b > e.length) b = e.length;
            for (var f = 0, a = Array(b); f < b; f++) a[f] = e[f];
            return a;
        }
        var C = (function () {
                function e() {
                    k(this, e);
                    this.handlers = {};
                }
                l(e, [
                    {
                        key: "addEventListener",
                        value: function () {
                            var b = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document,
                                f = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "click";
                            this.handlers[f] = { func: 2 < arguments.length ? arguments[2] : void 0, target: b };
                            var a = f.split(".")[0];
                            b.addEventListener(a, this.handlers[f].func);
                        },
                    },
                    {
                        key: "removeEventListener",
                        value: function () {
                            var b = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "click",
                                f = b.split(".")[0],
                                a = this.handlers[b];
                            a.target.removeEventListener(f, a.func);
                            delete this.handlers[b];
                        },
                    },
                    {
                        key: "removeAll",
                        value: function () {
                            for (var b in this.handlers) this.removeEventListener(b);
                        },
                    },
                ]);
                return e;
            })(),
            D = function () {
                return "".concat(0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "id", "-").concat(Math.random().toString(36).substr(2, 8));
            },
            m = (function () {
                function e() {
                    k(this, e);
                    this.events = new C();
                    this.callback = function () {};
                    this.updateInstanceId();
                }
                l(e, [
                    {
                        key: "eventHandler",
                        value: function (b, f) {
                            var a = this,
                                c = f.share_url,
                                d = f.windowTitle,
                                g = f.windowWidth,
                                h = f.windowHeight;
                            b.preventDefault();
                            f = Math.round((window.outerHeight || window.document.documentElement.offsetHeight) / 2 - h / 2);
                            var r = Math.round((window.outerWidth || window.document.documentElement.offsetWidth) / 2 - g / 2);
                            g = "width=".concat(g, ",height=").concat(h);
                            f = "left=".concat(r, ",top=").concat(f);
                            var A = "".concat(g, ",").concat(f, ",location=no,toolbar=no,menubar=no"),
                                x = window.open(c, d, A),
                                E = setInterval(function () {
                                    x.closed && (a.callback(b, { share_url: c, windowTitle: d, windowOptions: A }, x), clearInterval(E));
                                }, 10);
                            return x;
                        },
                    },
                    {
                        key: "setShareCallback",
                        value: function (b) {
                            this.callback = b;
                        },
                    },
                    {
                        key: "createEvents",
                        value: function (b) {
                            var f = this;
                            t(b).forEach(function (a) {
                                var c = f.getPreparedData(a);
                                f.events.addEventListener(a, "click.".concat(f.instanceId), function (d) {
                                    return f.eventHandler.call(f, d, c);
                                });
                            });
                        },
                    },
                    {
                        key: "getInstance",
                        value: function () {
                            "function" === typeof this.shareWindow && this.shareWindow();
                            "function" === typeof this.getCounter && this.getCounter();
                            return this;
                        },
                    },
                    {
                        key: "updateInstanceId",
                        value: function () {
                            this.instanceId = D();
                        },
                    },
                    {
                        key: "reNewInstance",
                        value: function () {
                            this.events.removeAll();
                            this.updateInstanceId();
                            return this.getInstance();
                        },
                    },
                ]);
                return e;
            })(),
            y = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('link[rel="apple-touch-icon"]');
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.title = encodeURIComponent(c);
                    g.image = d ? encodeURIComponent(d.href) : "";
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            a = a.dataset.image ? encodeURIComponent(a.dataset.image) : this.image;
                            c = "https://vk.com/share.php?url=".concat(c, "&title=").concat(d, "&image=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="vkontakte"]');
                            return this.createEvents(a);
                        },
                    },
                    {
                        key: "getCounter",
                        value: function () {
                            var a = document.createElement("script"),
                                c = document.querySelectorAll('[data-counter="vkontakte"]'),
                                d = "https://vk.com/share.php?act=count&index=1&url=".concat(this.url);
                            window.VK = Object.assign({}, { Share: {} }, window.VK);
                            0 < c.length &&
                                ((window.VK.Share.count = function (g, h) {
                                    t(c).forEach(function (r) {
                                        r.innerHTML = h;
                                    });
                                    null !== a.parentNode && a.parentNode.removeChild(a);
                                }),
                                (a.src = d),
                                document.body.appendChild(a));
                        },
                    },
                ]);
                return b;
            })(m),
            F = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://facebook.com/sharer/sharer.php?u=".concat(c, "&t=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="facebook"]');
                            return this.createEvents(a);
                        },
                    },
                    {
                        key: "getCounter",
                        value: function () {
                            var a = document.createElement("script"),
                                c = ("goodshare_" + Math.random()).replace(".", ""),
                                d = document.querySelectorAll('[data-counter="facebook"]'),
                                g = "https://graph.facebook.com/?id=".concat(this.url, "&callback=").concat(c);
                            0 < d.length &&
                                ((window[c] = function (h) {
                                    t(d).forEach(function (r) {
                                        r.innerHTML = h.share ? h.share.share_count : 0;
                                    });
                                    null !== a.parentNode && a.parentNode.removeChild(a);
                                }),
                                (a.src = g),
                                document.body.appendChild(a));
                        },
                    },
                ]);
                return b;
            })(m),
            G = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://connect.ok.ru/offer?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="odnoklassniki"]');
                            return this.createEvents(a);
                        },
                    },
                    {
                        key: "getCounter",
                        value: function () {
                            var a = document.createElement("script"),
                                c = document.querySelectorAll('[data-counter="odnoklassniki"]'),
                                d = "https://connect.ok.ru/dk?st.cmd=extLike&uid=1&ref=".concat(this.url);
                            window.ODKL = {};
                            0 < c.length &&
                                ((window.ODKL.updateCount = function (g, h) {
                                    t(c).forEach(function (r) {
                                        r.innerHTML = h;
                                    });
                                    null !== a.parentNode && a.parentNode.removeChild(a);
                                }),
                                (a.src = d),
                                document.body.appendChild(a));
                        },
                    },
                ]);
                return b;
            })(m),
            H = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('meta[name="description"]'),
                        g = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : document.querySelector('link[rel="apple-touch-icon"]');
                    k(this, b);
                    var h = f.call(this);
                    h.url = encodeURIComponent(a);
                    h.title = encodeURIComponent(c);
                    h.description = d ? encodeURIComponent(d.content) : "";
                    h.image = g ? encodeURIComponent(g.href) : "";
                    h.createEvents = h.createEvents.bind(n(h));
                    return h;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title,
                                g = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            a = a.dataset.image ? encodeURIComponent(a.dataset.image) : this.image;
                            c = "https://connect.mail.ru/share?url=".concat(c, "&title=").concat(d, "&description=").concat(g, "&imageurl=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="moimir"]');
                            return this.createEvents(a);
                        },
                    },
                    {
                        key: "getCounter",
                        value: function () {
                            var a = document.createElement("script"),
                                c = encodeURIComponent(this.url.replace(/^.*?:\/\//, "")),
                                d = ("goodshare_" + Math.random()).replace(".", ""),
                                g = document.querySelectorAll('[data-counter="moimir"]');
                            0 < g.length &&
                                ((window[d] = function (h) {
                                    t(g).forEach(function (r) {
                                        r.innerHTML = h.share_mm;
                                    });
                                    null !== a.parentNode && a.parentNode.removeChild(a);
                                }),
                                (a.src = "https://appsmail.ru/share/count/" + c + "?callback=" + d),
                                document.body.appendChild(a));
                        },
                    },
                ]);
                return b;
            })(m),
            I = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('meta[name="description"]');
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.title = encodeURIComponent(c);
                    g.description = d ? encodeURIComponent(d.content) : "";
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            a = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            c = "https://www.tumblr.com/widgets/share/tool?canonicalUrl=".concat(c, "&title=").concat(d, "&caption=").concat(a, "&posttype=link");
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="tumblr"]');
                            return this.createEvents(a);
                        },
                    },
                    {
                        key: "getCounter",
                        value: function () {
                            var a = document.createElement("script"),
                                c = ("goodshare_" + Math.random()).replace(".", ""),
                                d = document.querySelectorAll('[data-counter="tumblr"]'),
                                g = "https://api.tumblr.com/v2/share/stats?url=".concat(this.url, "&callback=").concat(c);
                            0 < d.length &&
                                ((window[c] = function (h) {
                                    t(d).forEach(function (r) {
                                        r.innerHTML = h.response.note_count;
                                    });
                                    null !== a.parentNode && a.parentNode.removeChild(a);
                                }),
                                (a.src = g),
                                document.body.appendChild(a));
                        },
                    },
                ]);
                return b;
            })(m),
            J = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.querySelector('meta[name="description"]'),
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('link[rel="apple-touch-icon"]');
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.description = c ? encodeURIComponent(c.content) : "";
                    g.image = d ? encodeURIComponent(d.href) : "";
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            a = a.dataset.image ? encodeURIComponent(a.dataset.image) : this.image;
                            c = "https://www.pinterest.com/pin/create/button/?url=".concat(c, "&description=").concat(d, "&media=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="pinterest"]');
                            return this.createEvents(a);
                        },
                    },
                    {
                        key: "getCounter",
                        value: function () {
                            var a = document.createElement("script"),
                                c = ("goodshare_" + Math.random()).replace(".", ""),
                                d = document.querySelectorAll('[data-counter="pinterest"]'),
                                g = "https://api.pinterest.com/v1/urls/count.json?url=".concat(this.url, "&callback=").concat(c);
                            0 < d.length &&
                                ((window[c] = function (h) {
                                    t(d).forEach(function (r) {
                                        r.innerHTML = 0 < h.length ? h.count : 0;
                                    });
                                    null !== a.parentNode && a.parentNode.removeChild(a);
                                }),
                                (a.src = g),
                                document.body.appendChild(a));
                        },
                    },
                ]);
                return b;
            })(m),
            K = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://reddit.com/submit?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="reddit"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            L = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://buffer.com/add?url=".concat(c, "&text=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="buffer"]');
                            return this.createEvents(a);
                        },
                    },
                    {
                        key: "getCounter",
                        value: function () {
                            var a = document.createElement("script"),
                                c = ("goodshare_" + Math.random()).replace(".", ""),
                                d = document.querySelectorAll('[data-counter="buffer"]'),
                                g = "https://api.bufferapp.com/1/links/shares.json?url=".concat(this.url, "&callback=").concat(c);
                            0 < d.length &&
                                ((window[c] = function (h) {
                                    t(d).forEach(function (r) {
                                        r.innerHTML = h ? h.shares : 0;
                                    });
                                    a.parentNode.removeChild(a);
                                }),
                                (a.src = g),
                                document.body.appendChild(a));
                        },
                    },
                ]);
                return b;
            })(m),
            M = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "";
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.title = encodeURIComponent(c);
                    g.hashtags = encodeURIComponent(d);
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            a = a.dataset.hashtags ? encodeURIComponent(a.dataset.hashtags) : this.hashtags;
                            c = "https://twitter.com/share?url=".concat(c, "&text=").concat(d, "&hashtags=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="twitter"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            N = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://livejournal.com/update.bml?event=".concat(c, "&subject=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="livejournal"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            O = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('meta[name="description"]');
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.title = encodeURIComponent(c);
                    g.description = d ? encodeURIComponent(d.content) : "";
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            a = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            c = "https://www.linkedin.com/shareArticle?url=".concat(c, "&text=").concat(d, "&summary=").concat(a, "&mini=true");
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="linkedin"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            P = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('meta[name="description"]');
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.title = encodeURIComponent(c);
                    g.description = d ? encodeURIComponent(d.content) : "";
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            a = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            c = "https://www.evernote.com/clip.action?url=".concat(c, "&title=").concat(d, "&body=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="evernote"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            Q = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://del.icio.us/save?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="delicious"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            R = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://share.flipboard.com/bookmarklet/popout?ext=sharethis&title=".concat(a, "&url=").concat(c, "&v=2");
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="flipboard"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            S = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "https://mix.com/mixit?su=submit&url=".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="mix"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            T = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "https://www.meneame.net/submit?url=".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="meneame"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            U = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://www.blogger.com/blog-this.g?u=".concat(c, "&n=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="blogger"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            V = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://getpocket.com/save?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="pocket"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            W = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://www.instapaper.com/edit?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="instapaper"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            X = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://digg.com/submit?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="digg"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            Y = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "http://www.liveinternet.ru/journal_post.php?action=n_add&cnurl=".concat(c, "&cntitle=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="liveinternet"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            Z = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('meta[name="description"]');
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.title = encodeURIComponent(c);
                    g.description = d ? encodeURIComponent(d.content) : "";
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            a = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            c = "https://surfingbird.ru/share?url=".concat(c, "&title=").concat(d, "&description=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="surfingbird"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            aa = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "https://www.xing.com/spi/shares/new?url=".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="xing"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ba = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('meta[name="description"]'),
                        g = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : document.querySelector('link[rel="apple-touch-icon"]');
                    k(this, b);
                    var h = f.call(this);
                    h.url = encodeURIComponent(a);
                    h.title = encodeURIComponent(c);
                    h.description = d ? encodeURIComponent(d.content) : "";
                    h.image = g ? encodeURIComponent(g.href) : "";
                    h.createEvents = h.createEvents.bind(n(h));
                    return h;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title,
                                g = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            a = a.dataset.image ? encodeURIComponent(a.dataset.image) : this.image;
                            c = "https://wordpress.com/wp-admin/press-this.php?u=".concat(c, "&t=").concat(d, "&s=").concat(g, "&i=").concat(a, "&v=2");
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="wordpress"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ca = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title,
                        d = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : document.querySelector('meta[name="description"]');
                    k(this, b);
                    var g = f.call(this);
                    g.url = encodeURIComponent(a);
                    g.title = encodeURIComponent(c);
                    g.description = d ? encodeURIComponent(d.content) : "";
                    g.createEvents = g.createEvents.bind(n(g));
                    return g;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url,
                                d = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            a = a.dataset.description ? encodeURIComponent(a.dataset.description) : this.description;
                            c = "https://cang.baidu.com/do/add?iu=".concat(c, "&it=").concat(d, "&dc=").concat(a, "&fr=ien");
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="baidu"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            da = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "http://share.renren.com/share/buttonshare.do?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="renren"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ea = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://service.weibo.com/share/share.php?url=".concat(c, "&title=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="weibo"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            fa = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "sms:?&body=".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="sms"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ha = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                        c = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : document.title;
                    k(this, b);
                    var d = f.call(this);
                    d.url = encodeURIComponent(a);
                    d.title = encodeURIComponent(c);
                    d.createEvents = d.createEvents.bind(n(d));
                    return d;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.title ? encodeURIComponent(a.dataset.title) : this.title;
                            c = "https://web.skype.com/share?url=".concat(c, "&text=").concat(a);
                            return { callback: this.callback, share_url: c, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="skype"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ia = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            var c = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = a.dataset.rhash ? a.dataset.rhash : null;
                            var d = "https://t.me/share/url?url=".concat(c);
                            null !== a && (d = "https://t.me/iv?url=".concat(c, "&rhash=").concat(a));
                            return { callback: this.callback, share_url: d, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="telegram"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ja = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "viber://forward?text=".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="viber"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ka = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "https://api.whatsapp.com/send?text=".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="whatsapp"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            la = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "https://chart.apis.google.com/chart?cht=qr&chs=196x196&chld=Q%7C0&chl=".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="wechat"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m),
            ma = (function (e) {
                function b() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                    k(this, b);
                    var c = f.call(this);
                    c.url = encodeURIComponent(a);
                    c.createEvents = c.createEvents.bind(n(c));
                    return c;
                }
                p(b, e);
                var f = q(b);
                l(b, [
                    {
                        key: "getPreparedData",
                        value: function (a) {
                            a = a.dataset.url ? encodeURIComponent(a.dataset.url) : this.url;
                            a = "line://msg/text/".concat(a);
                            return { callback: this.callback, share_url: a, windowTitle: "Share this", windowWidth: 640, windowHeight: 480 };
                        },
                    },
                    {
                        key: "shareWindow",
                        value: function () {
                            var a = document.querySelectorAll('[data-social="line"]');
                            return this.createEvents(a);
                        },
                    },
                ]);
                return b;
            })(m);
        m = (function (e) {
            function b() {
                var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : document.location.href;
                k(this, b);
                var c = f.call(this);
                c.url = a;
                c.createEvents = c.createEvents.bind(n(c));
                return c;
            }
            p(b, e);
            var f = q(b);
            l(b, [
                {
                    key: "getPreparedData",
                    value: function (a) {
                        return { callback: this.callback, share_url: a.dataset.url ? a.dataset.url : this.url };
                    },
                },
                {
                    key: "createFakeTextarea",
                    value: function (a) {
                        var c = "rtl" === document.documentElement.getAttribute("dir"),
                            d = document.createElement("textarea");
                        d.style.fontSize = "12pt";
                        d.style.border = "0";
                        d.style.padding = "0";
                        d.style.margin = "0";
                        d.style.position = "absolute";
                        d.style[c ? "right" : "left"] = "-9999px";
                        d.style.top = "".concat(window.pageYOffset || document.documentElement.scrollTop, "px");
                        d.setAttribute("readonly", "");
                        d.value = a;
                        return d;
                    },
                },
                {
                    key: "legacyCopyToClipboard",
                    value: function (a) {
                        var c = this;
                        return new Promise(function () {
                            var d = c.createFakeTextarea(a);
                            document.body.appendChild(d);
                            d.select();
                            d.setSelectionRange(0, d.value.length);
                            document.execCommand("copy");
                            document.body.removeChild(d);
                        });
                    },
                },
                {
                    key: "eventHandler",
                    value: function (a, c) {
                        var d = this,
                            g = c.share_url;
                        a.preventDefault();
                        try {
                            navigator.permissions.query({ name: "clipboard-write" }).then(function (h) {
                                "granted" === h.state || "prompt" === h.state
                                    ? navigator.clipboard.writeText(g).then(function () {
                                          d.callback(a, { share_url: g });
                                      })
                                    : d.legacyCopyToClipboard(g).then(function () {
                                          d.callback(a, { share_url: g });
                                      });
                            });
                        } catch (h) {
                            this.legacyCopyToClipboard(g).then(function () {
                                d.callback(a, { share_url: g });
                            });
                        }
                    },
                },
                {
                    key: "shareWindow",
                    value: function () {
                        var a = document.querySelectorAll('[data-social="copy-to-clipboard"]');
                        return this.createEvents(a);
                    },
                },
            ]);
            return b;
        })(m);
        var na = [y, F, G, H, O, I, J, K, L, M, N, P, Q, R, V, S, T, U, W, X, Y, Z, aa, ba, ca, da, ea, fa, ha, ia, ja, ka, la, ma, m];
        y = (function () {
            function e() {
                k(this, e);
                this.providers = na;
                this.getProviders();
            }
            l(e, [
                {
                    key: "setShareCallback",
                    value: function (b) {
                        this.providers = this.providers.map(function (f) {
                            return f.setShareCallback(b);
                        });
                    },
                },
                {
                    key: "getProviders",
                    value: function () {
                        return (this.providers = this.providers.map(function (b) {
                            return new b().getInstance();
                        }));
                    },
                },
                {
                    key: "reNewAllInstance",
                    value: function () {
                        this.providers = this.providers.map(function (b) {
                            return b.reNewInstance();
                        });
                    },
                },
            ]);
            return e;
        })();
        window._goodshare = new y();
    })();

    !(function (t, i, o, a) {
        t.extend({
            scrolline: function (a) {
                var r = { backColor: "#ecf0f1", direction: "horizontal", frontColor: "#2ecc71", opacity: 1, position: "top", reverse: !1, weight: 5, zindex: 1e3, scrollEnd: function () {} };
                function e(i) {
                    (this.params = t.extend(r, i)), (this.$back = t(o.createElement("div")).addClass("stafe-reading-progress-wrap")), (this.$front = t(o.createElement("div"))), this.init();
                }
                (e.prototype = {
                    init: function () {
                        var o,
                            a,
                            r,
                            e,
                            n,
                            s,
                            p,
                            c,
                            d = this;
                        "vertical" != d.params.direction && (d.params.direction = "horizontal"),
                            "vertical" == d.params.direction && "right" != d.params.position && (d.params.position = "left"),
                            "horizontal" == d.params.direction && "bottom" != d.params.position && (d.params.position = "top"),
                            "vertical" == d.params.direction
                                ? ((r = o = 0), "right" == d.params.position ? ((a = 0), (e = "auto")) : ((a = "auto"), (e = 0)))
                                : ((a = e = 0), "bottom" == d.params.position ? ((o = "auto"), (r = 0)) : ((o = 0), (r = "auto"))),
                            d.params.reverse && !0 === d.params.reverse ? ("vertical" == d.params.direction ? ((p = s = c = 0), (n = "auto")) : ((p = s = s = 0), (c = "auto"))) : ((n = c = 0), (p = s = "auto")),
                            d.$front
                                .css({ background: d.params.frontColor, bottom: p, height: 0, left: c, margin: 0, overflow: "hidden", padding: 0, position: "absolute", right: s, top: n, width: 0, transition: "all 0.3s ease 0s" })
                                .appendTo(d.$back),
                            d.$back
                                .css({
                                    background: d.params.backColor,
                                    bottom: r,
                                    height: 0,
                                    left: e,
                                    opacity: d.params.opacity,
                                    margin: 0,
                                    overflow: "hidden",
                                    position: "fixed",
                                    padding: 0,
                                    right: a,
                                    top: o,
                                    width: 0,
                                    zIndex: d.params.zindex,
                                })
                                .appendTo("body"),
                            t(i).on("load resize scroll orientationchange", function () {
                                d.scrollListener();
                            });
                    },
                    scrollListener: function () {
                        var a,
                            r,
                            e,
                            n,
                            s,
                            p,
                            c = this,
                            d = t(i).height(),
                            h = t(i).width(),
                            l = t(o).height(),
                            m = t(i).scrollTop(),
                            g = m / (l - d),
                            u = Math.round(100 * g);
                        "vertical" == c.params.direction
                            ? ((s = ((m + d) * d) / l), (s = u + "%"), (a = c.params.weight), (r = p = d), (e = c.params.weight), (n = s))
                            : ((s = ((m + d) * h) / l), (s = u + "%"), (a = p = h), (r = c.params.weight), (e = s), (n = c.params.weight)),
                            c.$back.css({ height: r, width: a }),
                            c.$front.css({ height: n, width: e }),
                            s >= p && c.params.scrollEnd();
                    },
                }),
                    new e(a);
            },
        });
    })(jQuery, window, document);
    !(function (t) {
        "use strict";
        (t.upkNewsTicker = function (i, e) {
            var s = { effect: "fade", direction: "ltr", autoPlay: !1, interval: 4e3, scrollSpeed: 2, pauseOnHover: !1, position: "auto", zIndex: 99999 },
                n = this;
            (n.settings = {}),
                (n._element = t(i)),
                (n._label = n._element.children(".stafe-news-ticker-label")),
                (n._news = n._element.children(".stafe-news-ticker-content")),
                (n._ul = n._news.children("ul")),
                (n._li = n._ul.children("li")),
                (n._controls = n._element.children(".stafe-news-ticker-controls")),
                (n._prev = n._controls.find(".stafe-news-ticker-prev").parent()),
                (n._action = n._controls.find(".stafe-news-ticker-action").parent()),
                (n._next = n._controls.find(".stafe-news-ticker-next").parent()),
                (n._pause = !1),
                (n._controlsIsActive = !0),
                (n._totalNews = n._ul.children("li").length),
                (n._activeNews = 0),
                (n._interval = !1),
                (n._frameId = null);
            var l = function () {
                    var t = parseFloat(n._ul.css("marginLeft"));
                    (t -= n.settings.scrollSpeed / 2),
                        n._ul.css({ marginLeft: t }),
                        t <= -n._ul.find("li:first-child").outerWidth() && (n._ul.find("li:first-child").insertAfter(n._ul.find("li:last-child")), n._ul.css({ marginLeft: 0 })),
                        !1 === n._pause && ((n._frameId = requestAnimationFrame(l)), (window.requestAnimationFrame && n._frameId) || setTimeout(l, 16));
                },
                a = function () {
                    var t = parseFloat(n._ul.css("marginRight"));
                    (t -= n.settings.scrollSpeed / 2),
                        n._ul.css({ marginRight: t }),
                        t <= -n._ul.find("li:first-child").outerWidth() && (n._ul.find("li:first-child").insertAfter(n._ul.find("li:last-child")), n._ul.css({ marginRight: 0 })),
                        !1 === n._pause && (n._frameId = requestAnimationFrame(a)),
                        (window.requestAnimationFrame && n._frameId) || setTimeout(a, 16);
                },
                c = function () {
                    "rtl" === n.settings.direction
                        ? n._ul.stop().animate({ marginRight: -n._ul.find("li:first-child").outerWidth() }, 300, function () {
                              n._ul.find("li:first-child").insertAfter(n._ul.find("li:last-child")), n._ul.css({ marginRight: 0 }), (n._controlsIsActive = !0);
                          })
                        : n._ul.stop().animate({ marginLeft: -n._ul.find("li:first-child").outerWidth() }, 300, function () {
                              n._ul.find("li:first-child").insertAfter(n._ul.find("li:last-child")), n._ul.css({ marginLeft: 0 }), (n._controlsIsActive = !0);
                          });
                },
                o = function () {
                    "rtl" === n.settings.direction
                        ? (parseInt(n._ul.css("marginRight"), 10) >= 0 && (n._ul.css({ "margin-right": -n._ul.find("li:last-child").outerWidth() }), n._ul.find("li:last-child").insertBefore(n._ul.find("li:first-child"))),
                          n._ul.stop().animate({ marginRight: 0 }, 300, function () {
                              n._controlsIsActive = !0;
                          }))
                        : (parseInt(n._ul.css("marginLeft"), 10) >= 0 && (n._ul.css({ "margin-left": -n._ul.find("li:last-child").outerWidth() }), n._ul.find("li:last-child").insertBefore(n._ul.find("li:first-child"))),
                          n._ul.stop().animate({ marginLeft: 0 }, 300, function () {
                              n._controlsIsActive = !0;
                          }));
                },
                r = function () {
                    switch (((n._controlsIsActive = !0), n.settings.effect)) {
                        case "typography":
                            n._ul.find("li").hide(), n._ul.find("li").eq(n._activeNews).width(30).show(), n._ul.find("li").eq(n._activeNews).animate({ width: "100%", opacity: 1 }, 1500);
                            break;
                        case "fade":
                            n._ul.find("li").hide(), n._ul.find("li").eq(n._activeNews).fadeIn();
                            break;
                        case "slide-down":
                            n._totalNews <= 1
                                ? n._ul.find("li").animate({ top: 30, opacity: 0 }, 300, function () {
                                      t(this).css({ top: -30, opacity: 0, display: "block" }), t(this).animate({ top: 0, opacity: 1 }, 300);
                                  })
                                : (n._ul.find("li:visible").animate({ top: 30, opacity: 0 }, 300, function () {
                                      t(this).hide();
                                  }),
                                  n._ul.find("li").eq(n._activeNews).css({ top: -30, opacity: 0 }).show(),
                                  n._ul.find("li").eq(n._activeNews).animate({ top: 0, opacity: 1 }, 300));
                            break;
                        case "slide-up":
                            n._totalNews <= 1
                                ? n._ul.find("li").animate({ top: -30, opacity: 0 }, 300, function () {
                                      t(this).css({ top: 30, opacity: 0, display: "block" }), t(this).animate({ top: 0, opacity: 1 }, 300);
                                  })
                                : (n._ul.find("li:visible").animate({ top: -30, opacity: 0 }, 300, function () {
                                      t(this).hide();
                                  }),
                                  n._ul.find("li").eq(n._activeNews).css({ top: 30, opacity: 0 }).show(),
                                  n._ul.find("li").eq(n._activeNews).animate({ top: 0, opacity: 1 }, 300));
                            break;
                        case "slide-right":
                            n._totalNews <= 1
                                ? n._ul.find("li").animate({ left: "50%", opacity: 0 }, 300, function () {
                                      t(this).css({ left: -50, opacity: 0, display: "block" }), t(this).animate({ left: 0, opacity: 1 }, 300);
                                  })
                                : (n._ul.find("li:visible").animate({ left: "50%", opacity: 0 }, 300, function () {
                                      t(this).hide();
                                  }),
                                  n._ul.find("li").eq(n._activeNews).css({ left: -50, opacity: 0 }).show(),
                                  n._ul.find("li").eq(n._activeNews).animate({ left: 0, opacity: 1 }, 300));
                            break;
                        case "slide-left":
                            n._totalNews <= 1
                                ? n._ul.find("li").animate({ left: "-50%", opacity: 0 }, 300, function () {
                                      t(this).css({ left: "50%", opacity: 0, display: "block" }), t(this).animate({ left: 0, opacity: 1 }, 300);
                                  })
                                : (n._ul.find("li:visible").animate({ left: "-50%", opacity: 0 }, 300, function () {
                                      t(this).hide();
                                  }),
                                  n._ul.find("li").eq(n._activeNews).css({ left: "50%", opacity: 0 }).show(),
                                  n._ul.find("li").eq(n._activeNews).animate({ left: 0, opacity: 1 }, 300));
                            break;
                        default:
                            n._ul.find("li").hide(), n._ul.find("li").eq(n._activeNews).show();
                    }
                },
                u = function () {
                    if (((n._pause = !1), n.settings.autoPlay))
                        if ("scroll" === n.settings.effect) "rtl" === n.settings.direction ? (n._ul.width() > n._news.width() ? a() : n._ul.css({ marginRight: 0 })) : n._ul.width() > n._news.width() ? l() : n._ul.css({ marginLeft: 0 });
                        else
                            n.pause(),
                                (n._interval = setInterval(function () {
                                    n.next();
                                }, n.settings.interval));
                },
                _ = function () {
                    n._element.width() < 480
                        ? (n._label.hide(), "rtl" == n.settings.direction ? n._news.css({ right: 0 }) : n._news.css({ left: 0 }))
                        : (n._label.show(), "rtl" == n.settings.direction ? n._news.css({ right: n._label.outerWidth() }) : n._news.css({ left: n._label.outerWidth() }));
                };
            (n.init = function () {
                (n.settings = t.extend({}, s, e)),
                    n._element.addClass("stafe-effect-" + n.settings.effect + " stafe-direction-" + n.settings.direction),
                    (function () {
                        if ((n._label.length > 0 && ("rtl" == n.settings.direction ? n._news.css({ right: n._label.outerWidth() }) : n._news.css({ left: n._label.outerWidth() })), n._controls.length > 0)) {
                            var i = n._controls.outerWidth();
                            "rtl" == n.settings.direction ? n._news.css({ left: i }) : n._news.css({ right: i });
                        }
                        if ("scroll" === n.settings.effect) {
                            var e = 0;
                            n._li.each(function () {
                                e += t(this).outerWidth();
                            }),
                                (e += 50),
                                n._ul.css({ width: e });
                        }
                    })(),
                    "scroll" != n.settings.effect && r(),
                    u(),
                    n.settings.autoPlay ? n._action.find("span").removeClass("stafe-news-ticker-play").addClass("stafe-news-ticker-pause") : n._action.find("span").removeClass("stafe-news-ticker-pause").addClass("stafe-news-ticker-play"),
                    n._element.on("mouseleave", function (i) {
                        var e = t(document.elementFromPoint(i.clientX, i.clientY)).parents(".stafe-breaking-news")[0];
                        t(this)[0] !== e && (!0 === n.settings.pauseOnHover ? !0 === n.settings.autoPlay && n.play() : !0 === n.settings.autoPlay && !0 === n._pause && n.play());
                    }),
                    n._element.on("mouseenter", function () {
                        !0 === n.settings.pauseOnHover && n.pause();
                    }),
                    n._next.on("click", function () {
                        n._controlsIsActive && ((n._controlsIsActive = !1), n.pause(), n.next());
                    }),
                    n._prev.on("click", function () {
                        n._controlsIsActive && ((n._controlsIsActive = !1), n.pause(), n.prev());
                    }),
                    n._action.on("click", function () {
                        n._controlsIsActive &&
                            (n._action.find("span").hasClass("stafe-news-ticker-pause")
                                ? (n._action.find("span").removeClass("stafe-news-ticker-pause").addClass("stafe-news-ticker-play"), n.stop())
                                : ((n.settings.autoPlay = !0), n._action.find("span").removeClass("stafe-news-ticker-play").addClass("stafe-news-ticker-pause")));
                    }),
                    _(),
                    t(window).on("resize", function () {
                        _(), n.pause(), n.play();
                    });
            }),
                (n.pause = function () {
                    (n._pause = !0), clearInterval(n._interval), cancelAnimationFrame(n._frameId);
                }),
                (n.stop = function () {
                    (n._pause = !0), (n.settings.autoPlay = !1);
                }),
                (n.play = function () {
                    u();
                }),
                (n.next = function () {
                    "scroll" === n.settings.effect ? c() : (n._activeNews++, n._activeNews >= n._totalNews && (n._activeNews = 0), r());
                }),
                (n.prev = function () {
                    "scroll" === n.settings.effect ? o() : (n._activeNews--, n._activeNews < 0 && (n._activeNews = n._totalNews - 1), r());
                }),
                n.init();
        }),
            (t.fn.upkNewsTicker = function (i) {
                return this.each(function () {
                    if (null == t(this).data("upkNewsTicker")) {
                        var e = new t.upkNewsTicker(this, i);
                        t(this).data("upkNewsTicker", e);
                    }
                });
            });
    })(jQuery);
})(jQuery, window.elementorFrontend);
