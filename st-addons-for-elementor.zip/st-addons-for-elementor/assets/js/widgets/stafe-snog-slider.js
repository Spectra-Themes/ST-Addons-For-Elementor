!(function (e, i) {
    "use strict";
    var n = function (e, i) {
        var n = e.find(".stafe-snog-slider");
        if (!n.length) return;
        var o = n.find(".stafe-main-slider"),
            t = n.data("settings"),
            d = n.data("widget-settings");
        const l = elementorFrontend.utils.swiper;
        !(async function () {
            var n = await new l(o, t);
            t.pauseOnHover &&
                i(o).hover(
                    function () {
                        this.swiper.autoplay.stop();
                    },
                    function () {
                        this.swiper.autoplay.start();
                    }
                );
            var s = e.find(".stafe-snog-slider-wrap").find(".stafe-snog-thumbs"),
                a = await new l(s, { spaceBetween: 0, effect: "slide", lazy: !0, slidesPerView: 2, touchRatio: 0.2, loop: !!t.loop && t.loop, speed: t.speed ? t.speed : 800, loopedSlides: 4 }),
                r = await new l(i(d.id).find(".stafe-content-slider"), {
                    parallax: !0,
                    effect: "fade",
                    slidesPerView: 1,
                    loop: !!t.loop && t.loop,
                    speed: t.speed ? t.speed : 800,
                    loopedSlides: 4,
                    allowTouchMove: !1,
                    pagination: { el: d.id + " .stafe-pagination", clickable: !0 },
                });
            (n.controller.control = a),
                (a.controller.control = n),
                i(document).ready(function () {
                    setTimeout(() => {
                        var e = i(d.id).find(".stafe-main-slider")[0].swiper,
                            n = i(d.id).find(".stafe-main-slider .swiper-slide-active"),
                            o = n.data("swiper-slide-index");
                        void 0 === o && (o = n.index()),
                            i(d.id)
                                .find(".stafe-navigation-prev")
                                .on("click", function () {
                                    e.slidePrev();
                                }),
                            i(d.id)
                                .find(".stafe-navigation-next")
                                .on("click", function () {
                                    e.slideNext();
                                }),
                            i(d.id)
                                .find(".swiper-pagination-bullet")
                                .on("click", function () {
                                    var n = i(this).index();
                                    t.loop ? e.slideToLoop(n) : e.slideTo(n), i(d.id).addClass("wait--");
                                }),
                            e.on("slideChange", function (i) {
                                r.slideToLoop(e.realIndex);
                            });
                    }, 3e3);
                });
        })();
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-snog-slider.default", n);
    });
})(jQuery, window.elementorFrontend);
