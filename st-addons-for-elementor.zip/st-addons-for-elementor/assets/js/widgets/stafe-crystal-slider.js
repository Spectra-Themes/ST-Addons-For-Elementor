!(function (n, e) {
    "use strict";
    var t = function (n, e) {
        var t = n.find(".stafe-crystal-slider");
        if (!t.length) return;
        var r = t.find(".swiper-carousel"),
            o = t.data("settings");
        const i = elementorFrontend.utils.swiper;
        !(async function () {
            await new i(r, o);
            o.pauseOnHover &&
                e(r).hover(
                    function () {
                        this.swiper.autoplay.stop();
                    },
                    function () {
                        this.swiper.autoplay.start();
                    }
                );
        })();
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-crystal-slider.default", t);
    });
})(jQuery, window.elementorFrontend);
!function(n,e){"use strict";var t=function(n,e){var t=n.find(".stafe-crystal-slider");if(!t.length)return;var r=t.find(".swiper-carousel"),o=t.data("settings");const i=elementorFrontend.utils.swiper;!async function(){await new i(r,o);o.pauseOnHover&&e(r).hover((function(){this.swiper.autoplay.stop()}),(function(){this.swiper.autoplay.start()}))}()};jQuery(window).on("elementor/frontend/init",(function(){elementorFrontend.hooks.addAction("frontend/element_ready/stafe-crystal-slider.default",t)}))}(jQuery,window.elementorFrontend);