!(function (e) {
    (e.alert = function (t) {
        e.alert.hide(),
            e(
                (function (e, t, n) {
                    return ['<div class="stafe-newsletter-' + e + " " + t + '">', '<div class="stafe-alert-box">', n, "</div>", "</div>"].join("");
                })("alert", "", { text: t }.text)
            ).appendTo(document.body);
    }),
        (e.alert.hide = function () {
            e(".stafe-newsletter-alert").slideUp(800).remove();
        });
})(jQuery),
    (function (e, t) {
        "use strict";
        var n = function (e, t) {
            var n = e.find(".stafe-newsletter");
            if (n.length) {
                var i = window.STAddonsElementorConfig.mailchimp;
                return (
                    n.submit(function () {
                        var e = t(this);
                        return (
                            t.alert('<span class="uwk-newsletter-loader"></span>' + i.subscribing),
                            t.ajax({
                                url: e.attr("action"),
                                type: "POST",
                                data: e.serialize(),
                                success: function (e) {
                                    setTimeout(function () {
                                        t.alert(e),
                                            setTimeout(function () {
                                                t.alert.hide();
                                            }, 5e3);
                                    }, 2e3);
                                },
                            }),
                            !1
                        );
                    }),
                    !1
                );
            }
        };
        jQuery(window).on("elementor/frontend/init", function () {
            elementorFrontend.hooks.addAction("frontend/element_ready/stafe-newsletter.default", n);
        });
    })(jQuery, window.elementorFrontend);
