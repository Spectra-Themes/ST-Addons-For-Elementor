!(function (e, n) {
    "use strict";
    var o = function (e, n) {
        var o = e.find(".stafe-skide-slider");
        if (!o.length) return;
        var t = o.find(".swiper-carousel"),
            i = o.data("settings");
        const r = elementorFrontend.utils.swiper;
        !(async function () {
            var o = await new r(t, i);
            i.pauseOnHover &&
                n(t).hover(
                    function () {
                        this.swiper.autoplay.stop();
                    },
                    function () {
                        this.swiper.autoplay.start();
                    }
                );
            var s = e.find(".stafe-skide-slider-wrap").find(".stafe-skide-thumbs"),
                d = await new r(s, {
                    spaceBetween: 10,
                    slidesPerView: 2,
                    touchRatio: 0.2,
                    slideToClickedSlide: !0,
                    loop: !!i.loop && i.loop,
                    speed: i.speed ? i.speed : 500,
                    loopedSlides: 4,
                    breakpoints: { 1024: { slidesPerView: 3, spaceBetween: 20 } },
                });
            (o.controller.control = d), (d.controller.control = o);
        })();
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-skide-slider.default", o);
    });
})(jQuery, window.elementorFrontend);
