!(function (e, n) {
    "use strict";
    var t = function (e, n) {
        var t = e.find(".stafe-news-ticker"),
            o = t.data("settings");
        t.length && n(t).upkNewsTicker(o);
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-news-ticker.default", t);
    });
})(jQuery, window.elementorFrontend);
