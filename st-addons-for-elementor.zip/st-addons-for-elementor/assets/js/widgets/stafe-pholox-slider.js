!(function (e, i) {
    "use strict";
    var o = function (e, i) {
        var o = e.find(".stafe-pholox-slider"),
            n = o.data("settings");
        o.data("widget");
        if (!o.length) return;
        const r = elementorFrontend.utils.swiper;
        !(async function () {
            var e = o.find(".stafe-thumbs-slider .swiper-thumbs"),
                t = o.find(".stafe-main-slider .swiper-carousel"),
                d = await new r(t, n),
                s = await new r(e, {
                    spaceBetween: 15,
                    slidesPerView: 2,
                    touchRatio: 0.2,
                    slideToClickedSlide: !0,
                    loop: !!n.loop && n.loop,
                    speed: n.speed ? n.speed : 500,
                    loopedSlides: 4,
                    breakpoints: { 768: { slidesPerView: 3, spaceBetween: 20 }, 1440: { slidesPerView: 4, spaceBetween: 30 } },
                });
            (d.controller.control = s),
                (s.controller.control = d),
                d.on("slideChange", function () {
                    a();
                });
            var a = function () {
                o.find(".stafe-video-wrap").css("z-index", -1);
                var e = o.find(".stafe-video-iframe");
                Array.prototype.forEach.call(e, function (e) {
                    var i = e.src;
                    (e.src = i.replace("autoplay=1", "")), o.find(".stafe-video-iframe").prop("src", "");
                });
            };
            o.find(".stafe-pholox-video-trigger").on("click", function () {
                console.log("s");
                var e = i(this).data("src").split("?")[0],
                    n = o.find(".stafe-main-slider .swiper-slide-active .stafe-img-wrap");
                o.find(".stafe-img-wrap").removeClass("stafe-width-100"),
                    i(n).addClass("stafe-width-100"),
                    n.find(".stafe-video-iframe").attr("src", e + "?autoplay=1&modestbranding=1&showinfo=0&rel=0&controls=0&loop=1"),
                    n.find(".stafe-video-wrap").css("z-index", 10);
            });
        })();
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-pholox-slider.default", o);
    });
})(jQuery, window.elementorFrontend);
