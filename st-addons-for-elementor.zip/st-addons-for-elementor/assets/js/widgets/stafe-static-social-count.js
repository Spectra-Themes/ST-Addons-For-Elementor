!(function (e) {
    e(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-static-social-count.default", function (t) {
            t.find(".stafe-static-social-count").each(function () {
                var t = e(this)[0],
                    n = e(t).find(".counter-value");
                t &&
                    e(n).each(function () {
                        var t = e(this);
                        jQuery({ Counter: 0 }).animate(
                            { Counter: t.text() },
                            {
                                duration: 3e3,
                                easing: "swing",
                                step: function () {
                                    t.text(
                                        (function (e) {
                                            if ((e = e.toString().replace(/[^0-9.]/g, "")) <= 999) return Math.ceil(e);
                                            let t,
                                                n = [
                                                    { v: 1e3, s: "K" },
                                                    { v: 1e6, s: "M" },
                                                    { v: 1e9, s: "B" },
                                                    { v: 1e12, s: "T" },
                                                    { v: 1e15, s: "P" },
                                                    { v: 1e18, s: "E" },
                                                ];
                                            for (t = n.length - 1; t > 0 && !(e >= n[t].v); t--);
                                            return (e / n[t].v).toFixed(2).replace(/\.0+$|(\.[0-9]*[1-9])0+$/, "$1") + n[t].s;
                                        })(this.Counter)
                                    );
                                },
                            }
                        );
                    });
            });
        });
    });
})(jQuery);
