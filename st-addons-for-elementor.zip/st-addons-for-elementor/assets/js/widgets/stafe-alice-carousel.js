!(function (e, n) {
    "use strict";
    var t = function (e, n) {
        var t = e.find(".stafe-alice-carousel");
        if (!t.length) return;
        var o = t.find(".swiper-carousel"),
            r = t.data("settings");
        const i = elementorFrontend.utils.swiper;
        !(async function () {
            await new i(o, r);
            r.pauseOnHover &&
                n(o).hover(
                    function () {
                        this.swiper.autoplay.stop();
                    },
                    function () {
                        this.swiper.autoplay.start();
                    }
                );
        })();
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-alice-carousel.default", t);
    });
})(jQuery, window.elementorFrontend);
