!(function (e, n) {
    "use strict";
    var r = function (e, n) {
        var r = e.find(".stafe-reading-progress"),
            o = r.data("settings");
        r.length && (n(".stafe-reading-progress-wrap") && n(".stafe-reading-progress-wrap").remove(), jQuery.scrolline(o), n("body.admin-bar").length && "top" == o.position && n(".stafe-reading-progress-wrap").css("margin-top", 32));
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-reading-progress.default", r);
    });
})(jQuery, window.elementorFrontend);
