!(function (e, n) {
    "use strict";
    var o = function (e, n) {
        var o = e.find(".stafe-carbon-main");
        if (!o.length) return;
        var t = o.find(".swiper-carousel"),
            r = o.data("settings");
        const i = elementorFrontend.utils.swiper;
        !(async function () {
            var o = await new i(t, r);
            r.pauseOnHover &&
                n(t).hover(
                    function () {
                        this.swiper.autoplay.stop();
                    },
                    function () {
                        this.swiper.autoplay.start();
                    }
                );
            var s = e.find(".stafe-carbon-slider-wrap").find(".stafe-carbon-thumbs"),
                a = await new i(s, {
                    spaceBetween: 0,
                    slidesPerView: 1,
                    touchRatio: 0.2,
                    slideToClickedSlide: !0,
                    centeredSlides: !0,
                    loop: !!r.loop && r.loop,
                    speed: r.speed ? r.speed : 500,
                    loopedSlides: 4,
                    breakpoints: { 768: { slidesPerView: 3, spaceBetween: 20 } },
                });
            (o.controller.control = a), (a.controller.control = o);
        })();
    };
    jQuery(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/stafe-carbon-slider.default", o);
    });
})(jQuery, window.elementorFrontend);
