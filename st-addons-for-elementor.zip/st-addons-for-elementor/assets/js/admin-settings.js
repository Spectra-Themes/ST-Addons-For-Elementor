jQuery(document).ready(function() {
    jQuery('.stafe-no-result').removeClass('st-animation-shake');
});

function filterSearch(e) {
    var parentID = '#' + jQuery(e).data('id');
    var search = jQuery(parentID).find('.st-search-input').val().toLowerCase();

    jQuery(".stafe-options .stafe-option-item").filter(function() {
        jQuery(this).toggle(jQuery(this).attr('data-widget-name').toLowerCase().indexOf(search) > -1)
    });

    if (!search) {
        jQuery(parentID).find('.st-search-input').attr('st-filter-control', "");
        jQuery(parentID).find('.stafe-widget-all').trigger('click');
    } else {
        jQuery(parentID).find('.st-search-input').attr('st-filter-control', "filter: [data-widget-name*='" + search + "']");
        jQuery(parentID).find('.st-search-input').removeClass('st-active'); // Thanks to Bar-Rabbas
        jQuery(parentID).find('.st-search-input').trigger('click');
    }
}

jQuery('.stafe-options-parent').each(function(e, item) {
    var eachItem = '#' + jQuery(item).attr('id');
    jQuery(eachItem).on("beforeFilter", function() {
        jQuery(eachItem).find('.stafe-no-result').removeClass('st-animation-shake');
    });

    jQuery(eachItem).on("afterFilter", function() {

        var isElementVisible = false;
        var i = 0;

        if (jQuery(eachItem).closest(".stafe-options-parent").eq(i).is(":visible")) {} else {
            isElementVisible = true;
        }

        while (!isElementVisible && i < jQuery(eachItem).find(".stafe-option-item").length) {
            if (jQuery(eachItem).find(".stafe-option-item").eq(i).is(":visible")) {
                isElementVisible = true;
            }
            i++;
        }

        if (isElementVisible === false) {
            jQuery(eachItem).find('.stafe-no-result').addClass('st-animation-shake');
        }
    });


});


jQuery('.stafe-widget-filter-nav li a').on('click', function(e) {
    jQuery(this).closest('.st-widget-filter-wrapper').find('.st-search-input').val('');
    jQuery(this).closest('.st-widget-filter-wrapper').find('.st-search-input').val('').attr('st-filter-control', '');
});


jQuery(document).ready(function($) {
    'use strict';

    function hashHandler() {
        var $tab = jQuery('.st-addons-for-elementor-dashboard .st-tab');
        if (window.location.hash) {
            var hash = window.location.hash.substring(1);
            spectraThemesAddons.tab($tab).show(jQuery('#st-' + hash).data('tab-index'));
        }
    }

    jQuery(window).on('load', function() {
        hashHandler();
    });

    window.addEventListener("hashchange", hashHandler, true);

    jQuery('.toplevel_page_st_addons_for_elementor_options > ul > li > a ').on('click', function(event) {
        jQuery(this).parent().siblings().removeClass('current');
        jQuery(this).parent().addClass('current');
    });

    jQuery('#st_addons_for_elementor_active_modules_page a.stafe-active-all-widget').click(function() {

        jQuery('#st_addons_for_elementor_active_modules_page .stafe-option-item:not(.stafe-pro-inactive) .checkbox:visible').each(function() {
            jQuery(this).attr('checked', 'checked').prop("checked", true);
        });

        jQuery(this).addClass('st-active');
        jQuery('a.stafe-deactive-all-widget').removeClass('st-active');
    });

    jQuery('#st_addons_for_elementor_active_modules_page a.stafe-deactive-all-widget').click(function() {

        jQuery('#st_addons_for_elementor_active_modules_page .stafe-option-item:not(.stafe-pro-inactive) .checkbox:visible').each(function() {
            jQuery(this).removeAttr('checked');
        });

        jQuery(this).addClass('st-active');
        jQuery('a.stafe-active-all-widget').removeClass('st-active');
    });

    jQuery('#st_addons_for_elementor_third_party_widget_page a.stafe-active-all-widget').click(function() {

        jQuery('#st_addons_for_elementor_third_party_widget_page .checkbox:visible').each(function() {
            jQuery(this).attr('checked', 'checked').prop("checked", true);
        });

        jQuery(this).addClass('st-active');
        jQuery('a.stafe-deactive-all-widget').removeClass('st-active');
    });

    jQuery('#st_addons_for_elementor_third_party_widget_page a.stafe-deactive-all-widget').click(function() {

        jQuery('#st_addons_for_elementor_third_party_widget_page .checkbox:visible').each(function() {
            jQuery(this).removeAttr('checked');
        });

        jQuery(this).addClass('st-active');
        jQuery('a.stafe-active-all-widget').removeClass('st-active');
    });

    jQuery('#st_addons_for_elementor_elementor_extend_page a.stafe-active-all-widget').click(function() {

        jQuery('#st_addons_for_elementor_elementor_extend_page .checkbox:visible').each(function() {
            jQuery(this).attr('checked', 'checked').prop("checked", true);
        });

        jQuery(this).addClass('st-active');
        jQuery('a.stafe-deactive-all-widget').removeClass('st-active');
    });

    jQuery('#st_addons_for_elementor_elementor_extend_page a.stafe-deactive-all-widget').click(function() {

        jQuery('#st_addons_for_elementor_elementor_extend_page .checkbox:visible').each(function() {
            jQuery(this).removeAttr('checked');
        });

        jQuery(this).addClass('st-active');
        jQuery('a.stafe-active-all-widget').removeClass('st-active');
    });

    jQuery('form.settings-save').submit(function(event) {
        event.preventDefault();

        spectraThemesAddons.notification({
            message: '<div st-spinner></div> <?php esc_html_e("Please wait, Saving settings...", "st-addons-for-elementor") ?>',
            timeout: false
        });

        jQuery(this).ajaxSubmit({
            success: function() {
                spectraThemesAddons.notification.closeAll();
                spectraThemesAddons.notification({
                    message: '<span class="dashicons dashicons-yes"></span> <?php esc_html_e("Settings Saved Successfully.", "st-addons-for-elementor") ?>',
                    status: 'primary'
                });
            },
            error: function(data) {
                spectraThemesAddons.notification.closeAll();
                spectraThemesAddons.notification({
                    message: '<span st-icon=\'icon: warning\'></span> <?php esc_html_e("Unknown error, make sure access is correct!", "st-addons-for-elementor") ?>',
                    status: 'warning'
                });
            }
        });

        return false;
    });

    jQuery('#st_addons_for_elementor_active_modules_page .stafe-pro-inactive .checkbox').each(function() {
        jQuery(this).removeAttr('checked');
        jQuery(this).attr("disabled", true);
    });

});