!(function (n, i) {
    "use strict";
    var e = function (n, i) {
        var e = n.find(".stafe-in-animation");
        if (e.length) {
            var t,
                a = [],
                r = e.data("in-animation-delay") ? e.data("in-animation-delay") : 200;
            elementorFrontend.waypoint(
                jQuery(".stafe-in-animation .stafe-item"),
                function () {
                    a.push(i(this)), l();
                },
                { offset: "90%" }
            );
        }
        function l() {
            t ||
                (t = window.setInterval(function () {
                    a.length ? (jQuery(a.shift()).addClass("is-inview"), l()) : (window.clearInterval(t), (t = null));
                }, r));
        }
    };
    jQuery(window).on("elementor/frontend/init", function () {
        n.each(
            [
                "alex-grid",
                "alice-grid",
                "alter-grid",
                "amox-grid",
                "buzz-list",
                "classic-list",
                "elite-grid",
                "fanel-list",
                "featured-list",
                "harold-list",
                "hazel-grid",
                "kalon-grid",
                "maple-grid",
                "ramble-grid",
                "recent-comments",
                "scott-list",
                "tiny-list",
                "welsh-list",
                "wixer-grid",
            ],
            function (n, i) {
                elementorFrontend.hooks.addAction("frontend/element_ready/stafe-" + i + ".default", e);
            }
        );
    });
})(jQuery, window.elementorFrontend);
