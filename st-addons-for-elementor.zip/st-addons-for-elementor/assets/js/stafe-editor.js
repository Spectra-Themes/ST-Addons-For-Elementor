!(function (e) {
    "use strict";
    var t = {
        init: function () {
            elementor.channels.editor.on("section:activated", t.onAnimatedBoxSectionActivated),
                window.elementor.on("preview:loaded", function () {
                    (elementor.$preview[0].contentWindow.StAddonsForElementorEditor = t), t.onPreviewLoaded();
                }),
                elementor.channels.editor.on("staddonsForElementorProBuilderSetting:applySinglePagePostOnPreview", t.ApplyPreviewPostId),
                elementor.channels.editor.on("saved", t.savedBuilder);
        },
        savedBuilder: function () {
            t.shouldReload && ((t.shouldReload = !1), (window.location.href = window.location.href));
        },
        ApplyPreviewPostId: function () {
            (t.shouldReload = !0), e("#elementor-panel-saver-button-publish").trigger("click");
        },
        onPreviewLoaded: function () {
            e("#elementor-preview-iframe")[0].contentWindow.elementorFrontend.hooks.addAction("frontend/element_ready/widget", function (t) {
                t.find(".stafe-elementor-template-edit-link").on("click", function (t) {
                    window.open(e(this).attr("href"));
                });
            });
        },
    };
    e(window).on("elementor:init", t.init),
        (window.StAddonsForElementorEditor = t),
        elementor.hooks.addFilter("panel/elements/regionViews", function (e) {
            if (
                (jQuery(document).ready(function () {
                    jQuery("body").append("<style>.st-pro-unlock-icon:after{right: auto !important; left: 5px !important;}</style>");
                }),
                StAddonsForElementorConfigEditor.pro_license_activated || StAddonsForElementorConfigEditor.promotional_widgets <= 0)
            )
                return e;
            var t,
                o,
                i = StAddonsForElementorConfigEditor.promotional_widgets,
                n = e.elements.options.collection,
                r = e.categories.options.collection,
                l = e.categories.view,
                a = e.elements.view,
                d = [];
            return (
                _.each(i, function (e, t) {
                    n.add({ name: e.name, title: e.title, icon: e.icon, categories: e.categories, editable: !1 });
                }),
                n.each(function (e) {
                    "st-addons-for-elementor-pro-tweeks" === e.get("categories")[0] && d.push(e);
                }),
                (o = r.findIndex({ name: "st-addons-for-elementor" })) && r.add({ name: "st-addons-for-elementor-pro-tweeks", title: "ST Addons For Elementor ( Pro )", defaultActive: !1, items: d }, { at: o + 1 }),
                (t = {
                    getWedgetOption: function (e) {
                        return i.find(function (t) {
                            return t.name == e;
                        });
                    },
                    className: function () {
                        var e = "elementor-element-wrapper";
                        return this.isEditable() || (e += " elementor-element--promotion"), e;
                    },
                    onMouseDown: function () {
                        this.constructor.__super__.onMouseDown.call(this);
                        var e = this.getWedgetOption(this.model.get("name"));
                        elementor.promotion.showDialog({
                            title: sprintf(wp.i18n.__("%s", "elementor"), this.model.get("title")),
                            content: sprintf(wp.i18n.__("Use %s widget and dozens more pro features to extend your toolbox and build sites faster and better.", "elementor"), this.model.get("title")),
                            targetElement: this.el,
                            position: { blockStart: "-7" },
                            actionButton: { url: e.action_button.url, text: e.action_button.text, classes: e.action_button.classes || ["elementor-button", "elementor-button-success"] },
                        });
                    },
                }),
                (e.elements.view = a.extend({ childView: a.prototype.childView.extend(t) })),
                (e.categories.view = l.extend({ childView: l.prototype.childView.extend({ childView: l.prototype.childView.prototype.childView.extend(t) }) })),
                e
            );
        });
})(jQuery);
