(function($) {
    $(document).ready(function() {
        $(".stafe-category-image-add.button").on("click", function() {
            let UPK = wp.media({
                multiple: false
            });
            UPK.on('select', function() {
                let attachment = UPK.state().get('selection').first().toJSON();
                $("#stafe-category-image-id").val(attachment.id);
                $("#stafe-category-image-url").val(attachment.url);
                $("#stafe-category-image-wrapper").html(`<img width="150" height="150" src='${attachment.url}' />`);
            });
            UPK.open();
            return false;
        });
        $('.stafe-category-image-remove.button').on("click", function() {
            $('#stafe-category-image-id').val('');
            $('#stafe-category-image-wrapper').html('<img width=150; height=150; class="stafe-media-hidden-image" src="" style="margin:0; max-height:100px; padding:0;float:none;" />');
        })
    });
})(jQuery);