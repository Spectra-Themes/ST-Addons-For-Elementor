=== ST Addons For Elementor – (Article Layouts, Content Carousel, Story Slider, Category Showcase, Content Tabs, Event Timeline, News Ticker, Tag Matrix) ===
Tags: elementor, posts, post grid, post carousel, post archive
Stable tag: 0.0.1
Requires at least: 5.0.0
Requires PHP: 7.0.0
Tested up to: 6.5.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Elementor requires at least: 3.0.0
Elementor tested up to: 3.22.3

Best Post Addon for Elementor WordPress Plugin with 75+ Most Popular Widgets that need your everyday blog website building.

== Description ==
ST Addons is the most versatile, intuitive, and easy-to-use Popular Page Builder extension. Our goal is to empower you with the tools to achieve your vision efficiently and swiftly compared to other Elementor addons. Choosing us isn't just a choice; it's a necessity if you aim to outpace your competitors in website creation. The best part? You can design anything without needing to write a single line of code.

== Changelog ==

= 0.0.1 - 2024-06-28 =
* **Initial** -  Release.

== Upgrade Notice ==

- Click on update plugin and install the new update version of your plugin, simple.