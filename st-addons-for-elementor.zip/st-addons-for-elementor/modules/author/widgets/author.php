<?php

namespace STElementorAddon\Modules\Author\Widgets;

use STElementorAddon\Base\Module_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Css_Filter;

if (!defined('ABSPATH')) {
	exit;
} // Exit if accessed directly

class Author extends Module_Base {
	private $_query = null;

	public function get_name() {
		return 'stafe-author';
	}

	public function get_title() {
		return STAFE . esc_html__('Author', 'st-addons-for-elementor');
	}

	public function get_icon() {
		return 'stafe-widget-icon stafe-icon-author';
	}

	public function get_categories() {
		return ['st-addons-for-elementor'];
	}

	public function get_keywords() {
		return ['post', 'grid', 'blog', 'recent', 'news', 'author', 'list'];
	}

	public function get_style_depends() {
		if ($this->stafe_is_edit_mode()) {
			return ['stafe-all-styles'];
		} else {
			return ['stafe-font', 'stafe-author'];
		}
	}


	public function get_query() {
		return $this->_query;
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__('Layout', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'layout_style',
			[
				'label'   => esc_html__('Style', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid_1',
				'options' => [
					'grid_1' => esc_html__('Grid', 'st-addons-for-elementor'),
					'list' => esc_html__('List', 'st-addons-for-elementor'),
				],
			]
		);

		$this->add_responsive_control(
			'grid_columns',
			[
				'label'          => __('Columns', 'st-addons-for-elementor'),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				],
				'selectors'      => [
					'{{WRAPPER}} .stafe-author-wrapper.stafe-grid_1' => 'grid-template-columns: repeat({{SIZE}}, 1fr);',
				],
				'condition'      => [
					'layout_style' => ['grid_1']
				]
			]
		);

		$this->add_responsive_control(
			'list_columns',
			[
				'label'          => __('Columns', 'st-addons-for-elementor'),
				'type'           => Controls_Manager::SELECT,
				'default'        => '2',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
				],
				'selectors'      => [
					'{{WRAPPER}} .stafe-author-wrapper.stafe-list' => 'grid-template-columns: repeat({{SIZE}}, 1fr);',
				],
				'condition'      => [
					'layout_style' => 'list'
				]
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'     => esc_html__('Column Gap', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper' => 'grid-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => __('Alignment', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __('Left', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __('Right', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-right',
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-content' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'meta_alignment',
			[
				'label'     => __('Meta Alignment', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __('Left', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __('Right', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-right',
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'show_author_avatar',
			[
				'label'   => esc_html__('Show Avatar', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'author_avatar_size',
			[
				'label'     => __('Avatar Size', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SELECT,
				'condition' => [
					'show_author_avatar' => 'yes'
				],
				'options'   => [
					'25'  => '25 x 25',
					'35'  => '35 x 35',
					'45'  => '45 x 45',
					'60'  => '60 x 60',
					'80'  => '80 x 80',
					'100' => '100 x 100',
					'150' => '150 x 150',
					'200' => '200 x 200',
					'250' => '250 x 250',
				],
				'default'   => '250',
			]
		);

		$this->add_control(
			'show_author_name',
			[
				'label'   => esc_html__('Show Name', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_author_role',
			[
				'label'   => esc_html__('Show Role', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_author_description',
			[
				'label'   => esc_html__('Show Description', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_post_count',
			[
				'label'   => esc_html__('Show Post Count', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_author_link',
			[
				'label'   => esc_html__('Show Social Link', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'social_links',
			[
				'label'       => __('Social Links', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'label_block' => false,
				'default'     => ['email', 'url'],
				'options'     => st_addons_for_elementor_user_contact_methods([], true),
				'condition'   => [
					'show_author_link' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_post_grid_query',
			[
				'label' => esc_html__('Query', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'item_limit',
			[
				'label'   => esc_html__('Item Limit', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'default' => [
					'size' => 8,
				],
			]
		);

		$this->add_control(
			'role',
			[
				'label'   => esc_html__('Role', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT2,
				'multiple'    => true,
				'label_block' => false,
				'options' => [
					'subscriber'    => esc_html__('Subscriber', 'st-addons-for-elementor'),
					'contributor'   => esc_html__('Contributor', 'st-addons-for-elementor'),
					'author'        => esc_html__('Author', 'st-addons-for-elementor'),
					'editor'        => esc_html__('Editor', 'st-addons-for-elementor'),
					'administrator' => esc_html__('Administrator', 'st-addons-for-elementor'),
				],
			]
		);

		$this->add_control(
			'exclude',
			[
				'label'       => esc_html__('Exclude', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __('User ID: 1,2', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'   => esc_html__('Order By', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'display_name',
				'options' => [
					'display_name'   => esc_html__('Nicename', 'st-addons-for-elementor'),
					'post_count' => esc_html__('Post Count', 'st-addons-for-elementor'),
					'registered' => esc_html__('Registered', 'st-addons-for-elementor'),
					'rand'       => esc_html__('Random', 'st-addons-for-elementor'),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'   => esc_html__('Order', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc'  => esc_html__('ASC', 'st-addons-for-elementor'),
					'desc' => esc_html__('DESC', 'st-addons-for-elementor'),
				],
			]
		);

		$this->end_controls_section();

		//Style
		$this->start_controls_section(
			'stafe_section_style',
			[
				'label' => esc_html__('Item', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => __('Content Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs('tabs_item_style');

		$this->start_controls_tab(
			'tab_item_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'glassmorphism_effect',
			[
				'label' => esc_html__('Glassmorphism', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SWITCHER,
				'description' => sprintf(__('This feature will not work in the Firefox browser untill you enable browser compatibility so please %1s look here %2s', 'st-addons-for-elementor'), '<a href="https://developer.mozilla.org/en-US/docs/Web/CSS/backdrop-filter#Browser_compatibility" target="_blank">', '</a>'),

			]
		);

		$this->add_control(
			'glassmorphism_blur_level',
			[
				'label'       => __('Blur Level', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0,
						'step' => 1,
						'max'  => 50,
					]
				],
				'default'     => [
					'size' => 5
				],
				'selectors'   => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-item' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);'
				],
				'condition' => [
					'glassmorphism_effect' => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'item_background',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-item',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'           => 'item_border',
				'label'          => __('Border', 'elementor'),
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width'  => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => false,
						],
					],
					'color'  => [
						'default' => '#e9edf4',
					],
				],
				'selector'       => '{{WRAPPER}} .stafe-author-wrapper .stafe-item',
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => __('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_shadow',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-item',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_item_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'item_hover_background',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-item:hover',
			]
		);

		$this->add_control(
			'item_border_hover_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-item:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'item_border_border!' => '',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_shadow_hover',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-item:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_image',
			[
				'label'     => esc_html__('Avatar', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_author_avatar' => 'yes',
				],
			]
		);

		$this->add_control(
			'image_mask_popover',
			[
				'label'        => esc_html__('Image Mask', 'st-addons-for-elementor'),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'render_type'  => 'ui',
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_control(
			'image_mask_shape',
			[
				'label'     => esc_html__('Masking Shape', 'st-addons-for-elementor'),
				'title'     => esc_html__('Masking Shape', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'default',
				'options'   => [
					'default' => [
						'title' => esc_html__('Default Shapes', 'st-addons-for-elementor'),
						'icon'  => 'eicon-star',
					],
					'custom'  => [
						'title' => esc_html__('Custom Shape', 'st-addons-for-elementor'),
						'icon'  => 'eicon-image-bold',
					],
				],
				'toggle'    => false,
				'condition' => [
					'image_mask_popover' => 'yes',
				],
			]
		);

		$this->add_control(
			'image_mask_shape_default',
			[
				'label'          => _x('Default', 'Mask Image', 'st-addons-for-elementor'),
				'label_block'    => true,
				'show_label'     => false,
				'type'           => Controls_Manager::SELECT,
				'default'        => 0,
				'options'        => st_addons_for_elementor_mask_shapes(),
				'selectors'      => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => '-webkit-mask-image: url({{VALUE}}); mask-image: url({{VALUE}});',
				],
				'condition'      => [
					'image_mask_popover' => 'yes',
					'image_mask_shape'   => 'default',
				],
				'style_transfer' => true,
			]
		);

		$this->add_control(
			'image_mask_shape_custom',
			[
				'label'      => _x('Custom Shape', 'Mask Image', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::MEDIA,
				'show_label' => false,
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => '-webkit-mask-image: url({{URL}}); mask-image: url({{URL}});',
				],
				'condition'  => [
					'image_mask_popover' => 'yes',
					'image_mask_shape'   => 'custom',
				],
			]
		);

		$this->add_control(
			'image_mask_shape_position',
			[
				'label'                => esc_html__('Position', 'st-addons-for-elementor'),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'center-center',
				'options'              => [
					'center-center' => esc_html__('Center Center', 'st-addons-for-elementor'),
					'center-left'   => esc_html__('Center Left', 'st-addons-for-elementor'),
					'center-right'  => esc_html__('Center Right', 'st-addons-for-elementor'),
					'top-center'    => esc_html__('Top Center', 'st-addons-for-elementor'),
					'top-left'      => esc_html__('Top Left', 'st-addons-for-elementor'),
					'top-right'     => esc_html__('Top Right', 'st-addons-for-elementor'),
					'bottom-center' => esc_html__('Bottom Center', 'st-addons-for-elementor'),
					'bottom-left'   => esc_html__('Bottom Left', 'st-addons-for-elementor'),
					'bottom-right'  => esc_html__('Bottom Right', 'st-addons-for-elementor'),
				],
				'selectors_dictionary' => [
					'center-center' => 'center center',
					'center-left'   => 'center left',
					'center-right'  => 'center right',
					'top-center'    => 'top center',
					'top-left'      => 'top left',
					'top-right'     => 'top right',
					'bottom-center' => 'bottom center',
					'bottom-left'   => 'bottom left',
					'bottom-right'  => 'bottom right',
				],
				'selectors'            => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => '-webkit-mask-position: {{VALUE}}; mask-position: {{VALUE}};',
				],
				'condition'            => [
					'image_mask_popover' => 'yes',
				],
			]
		);

		$this->add_control(
			'image_mask_shape_size',
			[
				'label'     => esc_html__('Size', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'contain',
				'options'   => [
					'auto'    => esc_html__('Auto', 'st-addons-for-elementor'),
					'cover'   => esc_html__('Cover', 'st-addons-for-elementor'),
					'contain' => esc_html__('Contain', 'st-addons-for-elementor'),
					'initial' => esc_html__('Custom', 'st-addons-for-elementor'),
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => '-webkit-mask-size: {{VALUE}}; mask-size: {{VALUE}};',
				],
				'condition' => [
					'image_mask_popover' => 'yes',
				],
			]
		);

		$this->add_control(
			'image_mask_shape_custom_size',
			[
				'label'      => _x('Custom Size', 'Mask Image', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::SLIDER,
				'responsive' => true,
				'size_units' => ['px', 'em', '%', 'vw'],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'em' => [
						'min' => 0,
						'max' => 100,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
					'vw' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 100,
					'unit' => '%',
				],
				'required'   => true,
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => '-webkit-mask-size: {{SIZE}}{{UNIT}}; mask-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'image_mask_popover'    => 'yes',
					'image_mask_shape_size' => 'initial',
				],
			]
		);

		$this->add_control(
			'image_mask_shape_repeat',
			[
				'label'                => esc_html__('Repeat', 'st-addons-for-elementor'),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'no-repeat',
				'options'              => [
					'repeat'          => esc_html__('Repeat', 'st-addons-for-elementor'),
					'repeat-x'        => esc_html__('Repeat-x', 'st-addons-for-elementor'),
					'repeat-y'        => esc_html__('Repeat-y', 'st-addons-for-elementor'),
					'space'           => esc_html__('Space', 'st-addons-for-elementor'),
					'round'           => esc_html__('Round', 'st-addons-for-elementor'),
					'no-repeat'       => esc_html__('No-repeat', 'st-addons-for-elementor'),
					'repeat-space'    => esc_html__('Repeat Space', 'st-addons-for-elementor'),
					'round-space'     => esc_html__('Round Space', 'st-addons-for-elementor'),
					'no-repeat-round' => esc_html__('No-repeat Round', 'st-addons-for-elementor'),
				],
				'selectors_dictionary' => [
					'repeat'          => 'repeat',
					'repeat-x'        => 'repeat-x',
					'repeat-y'        => 'repeat-y',
					'space'           => 'space',
					'round'           => 'round',
					'no-repeat'       => 'no-repeat',
					'repeat-space'    => 'repeat space',
					'round-space'     => 'round space',
					'no-repeat-round' => 'no-repeat round',
				],
				'selectors'            => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => '-webkit-mask-repeat: {{VALUE}}; mask-repeat: {{VALUE}};',
				],
				'condition'            => [
					'image_mask_popover' => 'yes',
				],
			]
		);

		$this->end_popover();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'avatar_border',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-image a img',
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			'avatar_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'avatar_padding',
			[
				'label'      => __('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'avatar_margin',
			[
				'label'      => __('Margin', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout_style' => ['grid_1']
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'avatar_box_shadow',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-image a img',
			]
		);

		$this->add_responsive_control(
			'avatar_size',
			[
				'label'     => esc_html__('Size(px)', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 50,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image a img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout_style' => ['list']
				]
			]
		);

		$this->add_responsive_control(
			'avatar_spacing',
			[
				'label'     => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-image' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout_style' => 'list'
				]
			]
		);

		$this->start_controls_tabs('tabs_avatar_style');

		$this->start_controls_tab(
			'tab_avatar_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'css_filters',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-image a img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_avatar_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'hover_css_filters',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-item:hover .stafe-image a img',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_title',
			[
				'label'     => esc_html__('Name', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_author_name' => 'yes',
				],
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-name a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'name_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-name a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-name a',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'     => 'name_text_shadow',
				'label'    => __('Text Shadow', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-name a',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_role',
			[
				'label'     => esc_html__('Role', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_author_role' => 'yes',
				]
			]
		);

		$this->add_control(
			'role_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-role' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'role_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-role',
			]
		);

		$this->add_responsive_control(
			'role_spacing',
			[
				'label'     => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-role' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_description',
			[
				'label'     => esc_html__('Description', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_author_description' => 'yes',
				]
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-description',
			]
		);

		$this->add_responsive_control(
			'description_spacing',
			[
				'label'     => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-description' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_post_count',
			[
				'label'     => esc_html__('Post Count', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_post_count' => 'yes',
				]
			]
		);

		$this->add_control(
			'post_count_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-post-count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_count_background',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-post-count',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'           => 'post_count_border',
				'label'          => __('Border', 'st-addons-for-elementor'),
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width'  => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => false,
						],
					],
					// 'color'  => [
					// 	'default' => '#8D99AE',
					// ],
				],
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-post-count',
			]
		);

		$this->add_responsive_control(
			'post_count_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-post-count' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'post_count_padding',
			[
				'label'      => esc_html__('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-post-count' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_count_shadow',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-post-count',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'post_count_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-post-count',
			]
		);

		$this->add_responsive_control(
			'post_count_spacing',
			[
				'label'     => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-post-count' => 'top: {{SIZE}}{{UNIT}}; right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_social_link',
			[
				'label'     => esc_html__('Social Link', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_author_link' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'social_link_bottom_spacing',
			[
				'label'     => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs('tabs_social_link_style');

		$this->start_controls_tab(
			'tab_social_link_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'social_link_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'social_link_background',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-link a',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'social_link_border',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-link a',
			]
		);

		$this->add_responsive_control(
			'social_link_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_link_padding',
			[
				'label'      => esc_html__('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_link_spacing',
			[
				'label'     => esc_html__('Space Between', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link a+a' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'social_link_shadow',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-link a',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'social_link_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-link a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_social_link_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'social_link_hover_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'social_link_hover_background',
				'selector' => '{{WRAPPER}} .stafe-author-wrapper .stafe-link a:hover',
			]
		);

		$this->add_control(
			'social_link_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'social_link_border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link a:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_link_border_radius_hover',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-author-wrapper .stafe-link a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	public function render() {
		$settings = $this->get_settings_for_display();

		$users = get_users([
			'orderby'  => $settings['orderby'],
			'order'    => $settings['order'],
			'role__in' => (!empty($settings['role'])) ? $settings['role'] : null,
			'number'   => $settings['item_limit']['size'],
			'exclude'  => explode(',', esc_attr($settings["exclude"])),
		]);

		$social_links = $settings['social_links'];

?>
		<div class="stafe-author">
			<div class="stafe-author-wrapper stafe-<?php echo esc_html($settings['layout_style']) ?>">
				<?php
				foreach ($users as $author) {
				?>
					<div class="stafe-item">
						<?php if ($settings['show_author_avatar']) : ?>
							<div class="stafe-image">
								<a href="<?php echo get_bloginfo('url') . "/?author=" . esc_attr($author->ID); ?>">
									<?php echo get_avatar($author->ID, $settings['author_avatar_size']); ?>
								</a>
							</div>
						<?php endif; ?>

						<div class="stafe-content">
							<?php if ($settings['show_author_name']) : ?>
								<div class="stafe-name">
									<a href="<?php echo get_bloginfo('url') . "/?author=" . esc_attr($author->ID); ?>">
										<?php echo get_the_author_meta('display_name', $author->ID); ?>
									</a>
								</div>
							<?php endif; ?>

							<?php if ($settings['show_author_role']) : ?>
								<div class="stafe-role">
									<?php echo ucwords(get_user_role($author->ID)); ?>
								</div>
							<?php endif; ?>

							<?php if ($settings['show_author_description'] and get_the_author_meta('description', $author->ID)) : ?>
								<div class="stafe-description">
									<?php echo get_the_author_meta('description', $author->ID); ?>
								</div>
							<?php endif; ?>

							<?php if ($settings['show_author_link'] and !empty($social_links)) : ?>

								<div class="stafe-link">


									<?php foreach ($social_links as $link) : ?>

										<?php if (get_the_author_meta($link, $author->ID)) : ?>
											<?php

											$final_url = get_the_author_meta($link, $author->ID);
											$alt_title = esc_html('Click here to go ' . ucwords($link), 'st-addons-for-elementor');

											if ($link == 'email') {
												$final_url = 'mailto:' . get_the_author_meta($link, $author->ID);
												$alt_title = esc_html('Click here to ' . ucwords($link), 'st-addons-for-elementor');
											}

											?>

											<a href="<?php echo esc_url($final_url); ?>" title="<?php echo esc_html($alt_title); ?>">
												<i class="stafe-icon-<?php echo esc_attr($link); ?>" aria-hidden="true"></i>
											</a>
										<?php endif; ?>

									<?php endforeach; ?>


								</div>
							<?php endif; ?>

						</div>

						<?php if ($settings['show_post_count']) : ?>
							<div class="stafe-post-count">
								<?php

								$count = count_user_posts($author->ID);

								$total_count = sprintf(_n('Post: %s', 'Posts: %s', $count, 'st-addons-for-elementor'), $count);

								echo esc_attr($total_count);

								?>

							</div>
						<?php endif; ?>

					</div>
				<?php } ?>
			</div>
		</div>
<?php
	}
}
