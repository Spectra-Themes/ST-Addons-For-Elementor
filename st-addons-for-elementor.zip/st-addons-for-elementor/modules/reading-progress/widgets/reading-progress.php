<?php
namespace STElementorAddon\Modules\ReadingProgress\Widgets;

use STElementorAddon\Base\Module_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Class News Ticker
 */
class Reading_Progress extends Module_Base {

	public function get_name() {
		return 'stafe-reading-progress';
	}

	public function get_title() {
		return STAFE . esc_html__( 'Reading Progress Bar', 'st-addons-for-elementor' );
	}

	public function get_icon() {
		return 'stafe-widget-icon stafe-icon-reading-progress';
	}

	public function get_categories() {
		return [ 'st-addons-for-elementor' ];
	}

	public function get_keywords() {
		return [ 'bar', 'scroll', 'animate', 'line', 'scrolline', 'pop', 'reading progress' ];
	}

	public function get_script_depends() {
		if ( $this->stafe_is_edit_mode() ) {
			return [ 'stafe-all-scripts' ];
		} else {
			return [ 'scrolline', 'stafe-reading-progress' ];
		}
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_style_reading_progress',
			[
				'label'     => esc_html__( 'Reading Progress', 'st-addons-for-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'direction',
			[
				'label'   => esc_html__( 'Direction', 'st-addons-for-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => [
					'horizontal' => esc_html__( 'Horizontal', 'st-addons-for-elementor' ),
					'vertical'   => esc_html__( 'Vertical', 'st-addons-for-elementor' ),
				],
				'render_type' => 'template'
			]
		);
		
		$this->add_control(
			'horizontal_position',
			[
				'label'   => esc_html__( 'Position', 'st-addons-for-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => [
					'top'    => esc_html__( 'Top', 'st-addons-for-elementor' ),
					'bottom' => esc_html__( 'Bottom', 'st-addons-for-elementor' ),
				],
				'condition' => [
					'direction' => 'horizontal'
				],
				'render_type' => 'template'
			]
		);
		
		$this->add_control(
			'vertical_position',
			[
				'label'   => esc_html__( 'Position', 'st-addons-for-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'right',
				'options' => [
					'left'   => esc_html__( 'Left', 'st-addons-for-elementor' ),
					'right'  => esc_html__( 'Right', 'st-addons-for-elementor' ),
				],
				'condition' => [
					'direction' => 'vertical'
				],
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'back_color',
			[
				'label'     => esc_html__('Back Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'front_color',
			[
				'label'     => esc_html__('Front Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'weight',
			[
				'label'   => esc_html__( 'Weight', 'st-addons-for-elementor' ),
				'type'    => Controls_Manager::SLIDER,
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'opacity',
			[
				'label'   => esc_html__( 'Opacity', 'st-addons-for-elementor' ),
				'type'    => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.1,
					],
				],
			]
		);

		$this->add_control(
			'zindex',
			[
				'label'   => esc_html__( 'Z-index', 'st-addons-for-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'label_block' => false
			]
		);

		$this->add_control(
			'reverse',
			[
				'label'   => esc_html__( 'Reverse', 'st-addons-for-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'render_type' => 'template'
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$id       = 'stafe-reading-progress-' . $this->get_id();
		$settings = $this->get_settings_for_display();

		$position = $settings['direction'] == 'horizontal' ? $settings['horizontal_position'] : $settings['vertical_position'];

	    $this->add_render_attribute(
			[
				'reading-progress-settings' => [
					'id'			=> $id,
					'class'			=> 'stafe-reading-progress',
					'data-settings' => [
						wp_json_encode(array_filter([
							"direction"  => $settings['direction'],
							"position"   => $position,
							"backColor"  => $settings['back_color'],
							"frontColor" => $settings['front_color'],
							"weight"     => $settings['weight']['size'],
							"opacity"    => $settings['opacity']['size'],
							"zindex"     => $settings['zindex'],
							"reverse"    => ($settings["reverse"] == 'yes') ? true: false,
						]))
					],
				]
			]
		);

	    echo '<div '.$this->get_render_attribute_string( 'reading-progress-settings' ).'></div>';

	}
}
