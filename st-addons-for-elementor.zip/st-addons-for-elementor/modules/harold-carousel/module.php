<?php
namespace STElementorAddon\Modules\HaroldCarousel;

use STElementorAddon\Base\ST_Addons_For_ElementorModule_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Module extends ST_Addons_For_ElementorModule_Base {

	public function get_name() {
		return 'harold-carousel';
	}

	public function get_widgets() {

		$widgets = [
			'Harold_Carousel',
		];
		
		return $widgets;
	}
}
