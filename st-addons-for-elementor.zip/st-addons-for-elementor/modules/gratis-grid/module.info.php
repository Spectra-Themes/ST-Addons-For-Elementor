<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title'              => esc_html__( 'Gratis Grid', 'st-addons-for-elementor' ),
	'required'           => true,
	'default_activation' => false,
	'has_style'			 => true,
];
