<?php
namespace STElementorAddon\Modules\HaroldList;

use STElementorAddon\Base\ST_Addons_For_ElementorModule_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Module extends ST_Addons_For_ElementorModule_Base {

	public function get_name() {
		return 'harold-list';
	}

	public function get_widgets() {

		$widgets = [
			'Harold_List',
		];
		
		return $widgets;
	}
}
