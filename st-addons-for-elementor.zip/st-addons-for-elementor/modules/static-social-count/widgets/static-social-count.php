<?php

namespace STElementorAddon\Modules\StaticSocialCount\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Box_Shadow;
use STElementorAddon\Includes\Controls\GroupQuery\Group_Control_Query;

if (!defined('ABSPATH')) {
	exit;
}

class Static_Social_Count extends Group_Control_Query {
	public function get_name() {
		return 'stafe-static-social-count';
	}

	public function get_title() {
		return STAFE . esc_html__('Social Count (Static)', 'st-addons-for-elementor');
	}

	public function get_icon() {
		return 'stafe-widget-icon stafe-icon-static-social-count';
	}

	public function get_categories() {
		return ['st-addons-for-elementor'];
	}

	public function get_style_depends() {
		if ($this->stafe_is_edit_mode()) {
			return ['stafe-all-styles'];
		} else {
			return ['stafe-font', 'stafe-static-social-count'];
		}
	}
	public function get_script_depends() {
		if ($this->stafe_is_edit_mode()) {
			return ['stafe-all-scripts'];
		} else {
			return ['stafe-static-social-count'];
		}
	}

	public function get_keywords() {
		return ['post', 'grid', 'blog', 'recent', 'news', 'social-count', 'count'];
	}

	public function register_controls() {
		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__('Layout', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'select_style',
			[
				'label'      => esc_html__('Select Style', 'st-addons-for-elementor') . STAFE_NC,
				'type'       => Controls_Manager::SELECT,
				'default'    => '',
				'options'    => [
					''  => esc_html__('Style 1', 'st-addons-for-elementor'),
					'stafe-style-2' => esc_html__('Style 2', 'st-addons-for-elementor'),
					'stafe-style-3' => esc_html__('Style 3', 'st-addons-for-elementor'),
				],
			]
		);

		$this->add_responsive_control(
			'grid_columns',
			[
				'label' => __('Columns', 'st-addons-for-elementor'),
				'type' => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '4',
				'mobile_default' => '1',
				'options' => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count' => ' grid-template-columns: repeat({{VALUE}}, 1fr);'
				],
				// 'condition' => [
				// 	'select_layout' => 'grid'
				// ]
			]
		);

		$this->add_responsive_control(
			'social_icon_space_between',
			[
				'label'         => esc_html__('Column Gap', 'st-addons-for-elementor'),
				'type'          => Controls_Manager::SLIDER,
				'size_units'    => ['px'],
				'range'         => [
					'px'        => [
						'min'   => 0,
						'max'   => 100,
						'step'  => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count' => 'grid-gap: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'section_social_sites',
			[
				'label' => esc_html__('Social Count', 'st-addons-for-elementor'),
			]
		);
		$repeater = new Repeater();
		$repeater->start_controls_tabs(
			'social_count_tabs'
		);
		$repeater->start_controls_tab(
			'social_count_tabs_content',
			[
				'label' => esc_html__('Content', 'st-addons-for-elementor'),
			]
		);
		$repeater->add_control(
			'social_site_name',
			[
				'label'       => esc_html__('Label', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__('facebook', 'st-addons-for-elementor'),
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$repeater->add_control(
			'social_site_link',
			[
				'label'             => esc_html__('Link', 'st-addons-for-elementor'),
				'type'              => Controls_Manager::URL,
				'placeholder'       => esc_html__('https://facebook.com', 'st-addons-for-elementor'),
				'show_external'     => true,
				'default'           => [
					'url'           => 'https://spectrathemes.com',
					'is_external'   => true,
					'nofollow'      => true,
				],
			]
		);
		$repeater->add_control(
			'social_site_icon',
			[
				'label'         => esc_html__('Icon', 'st-addons-for-elementor'),
				'type'          => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-wordpress',
					'library' => 'fa-brands',
				],
				'recommended' => [
					'fa-brands' => [
						'android',
						'apple',
						'behance',
						'bitbucket',
						'codepen',
						'delicious',
						'deviantart',
						'digg',
						'dribbble',
						'elementor',
						'facebook',
						'flickr',
						'foursquare',
						'free-code-camp',
						'github',
						'gitlab',
						'globe',
						'houzz',
						'instagram',
						'jsfiddle',
						'linkedin',
						'medium',
						'meetup',
						'mix',
						'mixcloud',
						'odnoklassniki',
						'pinterest',
						'product-hunt',
						'reddit',
						'shopping-cart',
						'skype',
						'slideshare',
						'snapchat',
						'soundcloud',
						'spotify',
						'stack-overflow',
						'steam',
						'telegram',
						'thumb-tack',
						'tripadvisor',
						'tumblr',
						'twitch',
						'twitter',
						'viber',
						'vimeo',
						'vk',
						'weibo',
						'weixin',
						'whatsapp',
						'wordpress',
						'xing',
						'yelp',
						'youtube',
						'500px',
					],
					'fa-solid' => [
						'envelope',
						'link',
						'rss',
					],
				],
				'skin' => 'inline',
				'label_block' => false
			]
		);
		$repeater->add_control(
			'social_counter',
			[
				'label'     => esc_html__('Number', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$repeater->add_control(
			'social_site_meta',
			[
				'label'     => esc_html__('Meta', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$repeater->end_controls_tab();
		$repeater->start_controls_tab(
			'social_count_tabs_style',
			[
				'label' => esc_html__('Style', 'st-addons-for-elementor'),
			]
		);
		$repeater->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'social_single_item_bg',
				'label'     => esc_html__('Background', 'st-addons-for-elementor'),
				'types'     => ['classic', 'gradient'],
				'exclude' => ['image'],
				'selector'  => '{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}}.stafe-item',
			]
		);
		$repeater->add_control(
			'heading_icon_social_single',
			[
				'label'     => esc_html__('ICON NORMAL', 'ultiamte-post-kit-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'social_single_color',
			[
				'label' => esc_html__('Color', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-icon span' => 'color: {{VALUE}};',
				],
			]
		);
		$repeater->add_control(
			'social_single_bg_color',
			[
				'label' => esc_html__('Background', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-icon span' => 'background: {{VALUE}};',
				],
			]
		);
		$repeater->add_control(
			'social_single_border_color',
			[
				'label' => esc_html__('Border', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-icon span' => 'border-color: {{VALUE}};',
				],
			]
		);
		$repeater->add_control(
			'heading_icon_h_social_single',
			[
				'label'     => esc_html__('ICON HOVER', 'ultiamte-post-kit-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'social_single_h_color',
			[
				'label' => esc_html__('Color', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-icon:hover span' => 'color:{{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'social_single_h_bg_color',
			[
				'label' => esc_html__('Background', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-icon:hover span' => 'background: {{VALUE}};',
				],
			]
		);
		$repeater->add_control(
			'social_single_h_border_color',
			[
				'label' => esc_html__('Border', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-icon:hover span' => 'border-color: {{VALUE}};',
				],
			]
		);
		$repeater->add_control(
			'heading_number_social_single',
			[
				'label'     => esc_html__('N U M B E R', 'ultiamte-post-kit-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'social_single_count_color',
			[
				'label' => esc_html__('Color', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-count .counter-value' => 'color: {{VALUE}};',
				],
			]
		);

		$repeater->add_control(
			'heading_meta_social_single',
			[
				'label'     => esc_html__('M E T A', 'ultiamte-post-kit-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'social_single_meta_color',
			[
				'label' => esc_html__('Color', 'st-addons-for-elementor'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count {{CURRENT_ITEM}} .stafe-meta' => 'color: {{VALUE}};',
				],
			]
		);
		$repeater->end_controls_tab();
		$repeater->end_controls_tabs();
		$this->add_control(
			'social_counter_list',
			[
				'label'         => esc_html__('Social', 'st-addons-for-elementor'),
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'default'       => [
					[
						'social_site_name'    => esc_html__('Facebook', 'st-addons-for-elementor'),
						'social_site_icon' => [
							'value' => 'fab fa-facebook',
							'library' => 'fa-brands',
						],
						'social_counter'    => '450',
						'social_site_meta'    => esc_html__('Likes', 'st-addons-for-elementor'),
						'social_site_link' => [
							'url' => esc_html__('https://facebook.com/spectrathemes', 'st-addons-for-elementor')
						]
					],
					[
						'social_site_name'    => esc_html__('Twitter', 'st-addons-for-elementor'),
						'social_site_icon' => [
							'value' => 'fab fa-twitter',
							'library' => 'fa-brands',
						],
						'social_counter'    => '3000',
						'social_site_meta'    => esc_html__('Followers', 'st-addons-for-elementor'),
						'social_site_link' => [
							'url' => esc_html__('https://twitter.com/spectrathemescom', 'st-addons-for-elementor')
						]
					],
					[
						'social_site_name'    => esc_html__('Youtube', 'st-addons-for-elementor'),
						'social_site_icon' => [
							'value' => 'fab fa-youtube',
							'library' => 'fa-brands',
						],
						'social_counter'    => '2000000',
						'social_site_meta'    => esc_html__('Subscriber', 'st-addons-for-elementor'),
						'social_site_link' => [
							'url' => esc_html__('https://youtube.com/spectrathemes', 'st-addons-for-elementor')
						]
					],
					[
						'social_site_name'    => esc_html__('Instagram', 'st-addons-for-elementor'),
						'social_site_icon' => [
							'value' => 'fab fa-instagram',
							'library' => 'fa-brands',
						],
						'social_counter'    => '105000',
						'social_site_meta'    => esc_html__('Followers', 'st-addons-for-elementor'),
						'social_site_link' => [
							'url' => esc_html__('https://instagram.com/spectrathemes', 'st-addons-for-elementor')
						]
					],
				],
				'title_field'   => '{{{ social_site_name }}}',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'static_social_items',
			[
				'label' => esc_html__('Items', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'static_social_item_tabs'
		);
		$this->start_controls_tab(
			'static_social_tab_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'social_static_background',
				'label'     => esc_html__('Background', 'st-addons-for-elementor'),
				'types'     => ['classic', 'gradient'],
				'exclude' => ['image'],
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-item',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'social_static_border',
				'label'     => esc_html__('Border', 'st-addons-for-elementor'),
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-item',
			]
		);
		$this->add_responsive_control(
			'social_static_padding',
			[
				'label'                 => esc_html__('Padding', 'st-addons-for-elementor'),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => ['px', '%', 'em'],
				'selectors'             => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-item'    => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'social_static_border_radius',
			[
				'label'                 => esc_html__('Radius', 'st-addons-for-elementor'),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => ['px', '%', 'em'],
				'selectors'             => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-item'    => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'static_social_shadow',
				'label'     => esc_html__('Box Shadow', 'st-addons-for-elementor'),
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-item',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'static_social_tab_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'static_social_hover_bg',
				'label'     => esc_html__('Background', 'ultiamte-post-kit-pro'),
				'types'     => ['classic', 'gradient'],
				'exclude' => ['image'],
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-item:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		$this->start_controls_section(
			'section_social_count_style',
			[
				'label' => esc_html__('Icons', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'social_icons_tab'
		);
		$this->start_controls_tab(
			'social_icon_tab_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'icon_background',
				'label'     => esc_html__('Background', 'st-addons-for-elementor'),
				'types'     => ['classic', 'gradient'],
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-icon span',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'social_icons_border',
				'label'     => esc_html__('Border', 'st-addons-for-elementor'),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-icon span',
			]
		);
		$this->add_responsive_control(
			'social_icon_padding',
			[
				'label'                 => esc_html__('Padding', 'st-addons-for-elementor'),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => ['px', '%', 'em'],
				'selectors'             => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon span '    => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'social_icon_radius',
			[
				'label'                 => esc_html__('Radius', 'st-addons-for-elementor'),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => ['px', '%', 'em'],
				'selectors'             => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon span '    => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'social_icon_size',
			[
				'label'         => esc_html__('Size', 'st-addons-for-elementor'),
				'type'          => Controls_Manager::SLIDER,
				'size_units'    => ['px'],
				'range'         => [
					'px'        => [
						'min'   => 0,
						'max'   => 100,
						'step'  => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon span i' => 'font-size: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->add_responsive_control(
			'social_icon_spacing',
			[
				'label'         => esc_html__('Bottom Spacing', 'st-addons-for-elementor'),
				'type'          => Controls_Manager::SLIDER,
				'size_units'    => ['px'],
				'range'         => [
					'px'        => [
						'min'   => 0,
						'max'   => 100,
						'step'  => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'select_style' => ''
				]
			]
		);
		$this->add_responsive_control(
			'social_icon_spacing_left',
			[
				'label'         => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'          => Controls_Manager::SLIDER,
				'size_units'    => ['px'],
				'range'         => [
					'px'        => [
						'min'   => 0,
						'max'   => 100,
						'step'  => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'select_style' => 'stafe-style-2'
				]
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'social_icon_tab_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);
		$this->add_control(
			'icon_h_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon span:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'icon_h_background',
				'label'     => esc_html__('Background', 'st-addons-for-elementor'),
				'types'     => ['classic', 'gradient'],
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-icon span:hover',
			]
		);
		$this->add_control(
			'icon_h_border_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-icon span:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'social_icons_border_border!' => ''
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		$this->start_controls_section(
			'social_counter',
			[
				'label' => esc_html__('Counter', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'counter_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-count .counter-value' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'counter_typography',
				'label'     => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-count .counter-value',
			]
		);
		$this->add_responsive_control(
			'social_counter_spacing',
			[
				'label'         => esc_html__('Bottom Spacing', 'st-addons-for-elementor'),
				'type'          => Controls_Manager::SLIDER,
				'size_units'    => ['px'],
				'range'         => [
					'px'        => [
						'min'   => 0,
						'max'   => 100,
						'step'  => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-count' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'social_meta',
			[
				'label' => esc_html__('Meta', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'meta_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-static-social-count .stafe-meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'meta_typography',
				'label'     => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector'  => '{{WRAPPER}} .stafe-static-social-count .stafe-meta',
			]
		);
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute('stafe-static-social-count', 'class', ['stafe-static-social-count', $settings['select_style']], true);
		$social_links = $this->get_settings('social_counter_list'); ?>
		<div <?php $this->print_render_attribute_string('stafe-static-social-count'); ?>>
			<?php foreach ($social_links as $link_key => $social_link) {
				$this->add_render_attribute($link_key, 'class', [
					'stafe-item',
					'stafe-social-icon',
					'stafe-social-icon-' . strtolower($social_link['social_site_name']),
					'elementor-repeater-item-' . $social_link['_id'],
				]);
				if ($social_link['social_site_link']['is_external'] !== 'on') {
					$this->add_render_attribute($link_key, 'href', $social_link['social_site_link']['url']);
				} else {
					$this->add_render_attribute(
						$link_key,
						[
							'href' => [
								$social_link['social_site_link']['url']
							],
							'target' => '_blank'
						],
						null,
						true
					);
				}
			?>
				<a <?php $this->print_render_attribute_string($link_key); ?>>
					<div class="stafe-icon">
						<span title="<?php echo esc_html($social_link['social_site_name']); ?>">
							<?php Icons_Manager::render_icon($social_link['social_site_icon'], ['aria-hidden' => 'true']); ?>
						</span>
					</div>
					<div class="stafe-content">
						<div class="stafe-count">
							<?php echo '<span class="counter-value">' . esc_html($social_link['social_counter']) . '</span>'; ?>
						</div>
						<div class="stafe-meta">
							<?php printf('<span>%s</span>', esc_html($social_link['social_site_meta'])); ?>
						</div>
					</div>
				</a>
	<?php
			}
			echo '</div>';
		}
	}
