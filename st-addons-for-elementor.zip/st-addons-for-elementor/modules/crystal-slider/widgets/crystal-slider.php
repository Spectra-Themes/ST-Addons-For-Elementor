<?php

namespace STElementorAddon\Modules\CrystalSlider\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Text_Stroke;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Plugin;

use STElementorAddon\Utils;
use STElementorAddon\Traits\Global_Widget_Controls;
use STElementorAddon\Includes\Controls\GroupQuery\Group_Control_Query;
use WP_Query;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Crystal_Slider extends Group_Control_Query {

	use Global_Widget_Controls;

	private $_query = null;

	public function get_name() {
		return 'stafe-crystal-slider';
	}

	public function get_title() {
		return STAFE . esc_html__('Crystal Slider', 'st-addons-for-elementor');
	}

	public function get_icon() {
		return 'stafe-widget-icon stafe-icon-crystal-slider';
	}

	public function get_categories() {
		return ['st-addons-for-elementor'];
	}

	public function get_keywords() {
		return ['post', 'carousel', 'blog', 'recent', 'news', 'slider', 'crystal'];
	}

	public function get_style_depends() {
		if ($this->stafe_is_edit_mode()) {
			return ['stafe-all-styles'];
		} else {
			return ['stafe-font', 'stafe-crystal-slider'];
		}
	}

	public function get_script_depends() {
		if ($this->stafe_is_edit_mode()) {
			return ['stafe-all-scripts'];
		} else {
			return ['stafe-crystal-slider'];
		}
	}


	public function get_query() {
		return $this->_query;
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__('Layout', 'st-addons-for-elementor'),
			]
		);

		$this->add_responsive_control(
			'item_height',
			[
				'label' => esc_html__('Height', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'size_units' => ['px', 'vh'],
				'range' => [
					'px' => [
						'min' => 200,
						'max' => 1080,
					],
					'vh' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .stafe-crystal-slider .swiper-carousel' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'slide_spacing',
			[
				'label'      => esc_html__('Slide Bottom Spacing', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .swiper-carousel' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_alignment',
			[
				'label'     => esc_html__('Content Alignment', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::CHOOSE,
				'default' => 'center',
				'options'   => [
					'left'   => [
						'title' => esc_html__('Left', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__('Right', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-content' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'primary_thumbnail',
				'exclude'   => ['custom'],
				'default'   => 'full',
			]
		);

		$this->add_control(
			'hr_1',
			[
				'type'    => Controls_Manager::DIVIDER,
			]
		);

		//Global Title Controls
		$this->register_title_controls();

		$this->add_control(
			'show_category',
			[
				'label'   => esc_html__('Show Category', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'strip_shortcode',
			[
				'label'     => esc_html__('Strip Shortcode', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'show_excerpt' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_author',
			[
				'label'     => esc_html__('Show Author', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'separator' => 'before'
			]
		);

		$this->add_control(
			'meta_separator',
			[
				'label'       => __('Separator', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXT,
				'default'     => '//',
				'label_block' => false,
			]
		);

		//Global Date Controls
		$this->register_date_controls();

		//Global Reading Time Controls
		$this->register_reading_time_controls();

		$this->add_control(
			'show_readmore',
			[
				'label' => esc_html__('Read more', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SWITCHER,
				'default' => 'no',
				'separator' => 'before'
			]
		);

		$this->end_controls_section();

		// Query Settings
		$this->start_controls_section(
			'section_post_query_builder',
			[
				'label' => __('Query', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'item_limit',
			[
				'label' => esc_html__('Item Limit', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'default' => [
					'size' => 3,
				],
			]
		);

		$this->register_query_builder_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_carousel_settings',
			[
				'label' => __('Slider Settings', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'   => __('Autoplay', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',

			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__('Autoplay Speed', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 5000,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'pauseonhover',
			[
				'label' => esc_html__('Pause on Hover', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'grab_cursor',
			[
				'label'   => __('Grab Cursor', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'loop',
			[
				'label'   => __('Loop', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',

			]
		);


		$this->add_control(
			'speed',
			[
				'label'   => __('Animation Speed (ms)', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 500,
				],
				'range' => [
					'px' => [
						'min'  => 100,
						'max'  => 5000,
						'step' => 50,
					],
				],
			]
		);

		$this->add_control(
			'observer',
			[
				'label'       => __('Observer', 'st-addons-for-elementor'),
				'description' => __('When you use carousel in any hidden place (in tabs, accordion etc) keep it yes.', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'show_navigation',
			[
				'label' => esc_html__('Show Navigation', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'separator' => 'before'
			]
		);

		$this->add_control(
			'nav_arrows_icon',
			[
				'label'     => esc_html__('Arrows Icon', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SELECT,
				'default'   => '0',
				'options'   => [
					'0'        => esc_html__('Default', 'st-addons-for-elementor'),
					'1'        => esc_html__('Style 1', 'st-addons-for-elementor'),
					'2'        => esc_html__('Style 2', 'st-addons-for-elementor'),
					'3'        => esc_html__('Style 3', 'st-addons-for-elementor'),
					'4'        => esc_html__('Style 4', 'st-addons-for-elementor'),
					'5'        => esc_html__('Style 5', 'st-addons-for-elementor'),
					'6'        => esc_html__('Style 6', 'st-addons-for-elementor'),
					'7'        => esc_html__('Style 7', 'st-addons-for-elementor'),
					'8'        => esc_html__('Style 8', 'st-addons-for-elementor'),
					'9'        => esc_html__('Style 9', 'st-addons-for-elementor'),
					'10'       => esc_html__('Style 10', 'st-addons-for-elementor'),
					'11'       => esc_html__('Style 11', 'st-addons-for-elementor'),
					'12'       => esc_html__('Style 12', 'st-addons-for-elementor'),
					'13'       => esc_html__('Style 13', 'st-addons-for-elementor'),
					'14'       => esc_html__('Style 14', 'st-addons-for-elementor'),
					'15'       => esc_html__('Style 15', 'st-addons-for-elementor'),
					'16'       => esc_html__('Style 16', 'st-addons-for-elementor'),
					'17'       => esc_html__('Style 17', 'st-addons-for-elementor'),
					'18'       => esc_html__('Style 18', 'st-addons-for-elementor'),
					'circle-1' => esc_html__('Style 19', 'st-addons-for-elementor'),
					'circle-2' => esc_html__('Style 20', 'st-addons-for-elementor'),
					'circle-3' => esc_html__('Style 21', 'st-addons-for-elementor'),
					'circle-4' => esc_html__('Style 22', 'st-addons-for-elementor'),
					'square-1' => esc_html__('Style 23', 'st-addons-for-elementor'),
				],
				'condition' => [
					'show_navigation' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_pagination',
			[
				'label' => esc_html__('Show Pagination', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'separator' => 'before'
			]
		);

		$this->end_controls_section();

		//Style
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__('Content', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'Content_background',
				'selector'  => '{{WRAPPER}} .stafe-crystal-slider .stafe-content',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'content_border',
				'selector'    => '{{WRAPPER}} .stafe-crystal-slider .stafe-content',
			]
		);

		$this->add_responsive_control(
			'content_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label' 	 => __('Padding', 'st-addons-for-elementor'),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_max_width',
			[
				'label' => esc_html__('Max Width', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1200,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-content' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_vertical_offset',
			[
				'label'      => esc_html__('Vertical Offset', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'%' => [
					'min' => -0,
					'max' => 100,
				],
				'default' => [
					'unit' => '%',
				],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-content' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'content_shadow',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-content',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_title',
			[
				'label'     => esc_html__('Title', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-title a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label'      => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'title_typography',
				'label'     => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector'  => '{{WRAPPER}} .stafe-crystal-slider .stafe-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'label' => __('Text Shadow', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-title a',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name'      => 'title_text_stroke',
				'label'     => __('Text Stroke', 'st-addons-for-elementor') . STAFE_NC,
				'selector'  => '{{WRAPPER}} .stafe-crystal-slider .stafe-title a',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_meta',
			[
				'label'      => esc_html__('Meta', 'st-addons-for-elementor'),
				'tab'        => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'  => 'show_author',
							'value' => 'yes'
						],
						[
							'name'  => 'show_date',
							'value' => 'yes'
						],
						[
							'name'  => 'show_comments',
							'value' => 'yes'
						]
					]
				],
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-meta,
					{{WRAPPER}} .stafe-crystal-slider .stafe-meta .stafe-author a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'meta_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-meta .stafe-author a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'meta_space_between',
			[
				'label'     => esc_html__('Space Between', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-meta > div:before' => 'margin: 0 {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'meta_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-meta',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_category',
			[
				'label'     => esc_html__('Category', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_category' => 'yes'
				],
			]
		);

		$this->add_responsive_control(
			'category_bottom_spacing',
			[
				'label'   => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-category' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs('tabs_category_style');

		$this->start_controls_tab(
			'tab_category_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'category_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-category a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'category_background',
				'selector'  => '{{WRAPPER}} .stafe-crystal-slider .stafe-category a',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'category_border',
				'selector'    => '{{WRAPPER}} .stafe-crystal-slider .stafe-category a',
			]
		);

		$this->add_responsive_control(
			'category_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-category a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'category_padding',
			[
				'label'      => esc_html__('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-category a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'category_spacing',
			[
				'label'   => esc_html__('Space Between', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-category a+a' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'category_shadow',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-category a',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'category_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-category a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_category_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
				'condition' => [
					'show_category' => 'yes'
				]
			]
		);

		$this->add_control(
			'category_hover_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-category a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'category_hover_background',
				'selector'  => '{{WRAPPER}} .stafe-crystal-slider .stafe-category a:hover',
			]
		);

		$this->add_control(
			'category_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'category_border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-category a:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		//Read More Css
		$this->start_controls_section(
			'section_style_btn',
			[
				'label'     => __('Read More', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_readmore' => 'yes'
				]
			]
		);

		$this->start_controls_tabs('tabs_read_more_style');

		$this->start_controls_tab(
			'tabs_read_more_normal',
			[
				'label'     => __('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'button_icon_color',
			[
				'label'     => __('Icon Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'button_background',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn a',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn a',
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'read_more_padding',
			[
				'label' 	 => __('Padding', 'st-addons-for-elementor'),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_icon_size',
			[
				'label'     => esc_html__('Icon Size', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_responsive_control(
			'button_vertical_offset',
			[
				'label'      => esc_html__('Vertical Offset', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min'  => -1000,
						'max'  => 1000,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'%' => [
					'min' => -0,
					'max' => 100,
				],
				'default' => [
					'unit' => '%',
				],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_horizontal_offset',
			[
				'label'      => esc_html__('Horizontal Offset', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min'  => -1000,
						'max'  => 1000,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'%' => [
					'min' => -0,
					'max' => 100,
				],
				'default' => [
					'unit' => '%',
				],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_shadow',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-link-btn a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tabs_button_hover',
			[
				'label'     => __('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'button_hover_color',
			[
				'label'     => __('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-content:hover .stafe-link-btn a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'button_hover_background',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-content:hover .stafe-link-btn a',
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'arrows_border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-content:hover .stafe-link-btn a' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_hover_shadow',
				'selector' => '{{WRAPPER}}.stafe-crystal-slider .stafe-content:hover .stafe-link-btn a',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		//Navigation Css
		$this->start_controls_section(
			'section_style_navigation',
			[
				'label'     => __('Navigation', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('tabs_navigation_arrows_style');

		$this->start_controls_tab(
			'tabs_nav_arrows_normal',
			[
				'label'     => __('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'arrows_color',
			[
				'label'     => __('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrows_background',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'arrows_border',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev',
			]
		);

		$this->add_responsive_control(
			'arrows_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_size',
			[
				'label'     => esc_html__('Size', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'navigation_padding',
			[
				'label' 	 => __('Padding', 'st-addons-for-elementor'),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}}  .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider
						.stafe-navigation-wrap .stafe-navigation-prev' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrows_shadow',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev',
			]
		);

		$this->add_responsive_control(
			'vertical_offset',
			[
				'label' => esc_html__('Vertical Offset', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev' => 'top: {{SIZE}}%;',
				],
			]
		);

		$this->add_responsive_control(
			'horizontal_offset_next',
			[
				'label' => esc_html__('Horizontal Offset', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'default' => [
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next' => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tabs_nav_arrows_hover',
			[
				'label'     => __('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'arrows_hover_color',
			[
				'label'     => __('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next:hover, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrows_hover_background',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next:hover, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev:hover',
			]
		);

		$this->add_control(
			'arrows_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'arrows_border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next:hover, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrows_hover_shadow',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-next:hover, {{WRAPPER}} .stafe-crystal-slider .stafe-navigation-wrap .stafe-navigation-prev:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		//Pagination Css
		$this->start_controls_section(
			'section_style_pagination',
			[
				'label'     => __('Pagination', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_pagination' => 'yes'
				]
			]
		);

		$this->add_responsive_control(
			'dots_nny_position',
			[
				'label'          => __('Dots Vertical Offset', 'st-addons-for-elementor'),
				'type'           => Controls_Manager::SLIDER,
				'range'          => [
					'px' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'selectors'      => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap' => 'bottom: {{SIZE}}px;'
				],
			]
		);

		$this->start_controls_tabs('tabs_navigation_dots_style');

		$this->start_controls_tab(
			'tabs_nav_dots_normal',
			[
				'label'     => __('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'dots_color',
			[
				'label'     => __('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'dots_space_between',
			[
				'label'     => __('Space Between', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .stafe-pagination ' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'     => __('Size', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 5,
						'max' => 20,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => ''
				],
			]
		);

		$this->add_control(
			'advanced_dots_size',
			[
				'label'     => __('Advanced Size', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SWITCHER,
			]
		);

		$this->add_responsive_control(
			'advanced_dots_width',
			[
				'label'     => __('Width(px)', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => 'yes'
				],
			]
		);

		$this->add_responsive_control(
			'advanced_dots_height',
			[
				'label'     => __('Height(px)', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => 'yes'
				],
			]
		);

		$this->add_responsive_control(
			'advanced_dots_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => 'yes'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'dots_box_shadow',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tabs_nav_dots_active',
			[
				'label'     => __('Active', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'active_dot_color',
			[
				'label'     => __('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'active_dots_size',
			[
				'label'     => __('Size', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 5,
						'max' => 20,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet-active' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}' => '--ps-swiper-dots-active-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => ''
				],
			]
		);

		$this->add_responsive_control(
			'active_advanced_dots_width',
			[
				'label'     => __('Width(px)', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet-active' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => 'yes'
				],
			]
		);

		$this->add_responsive_control(
			'active_advanced_dots_height',
			[
				'label'     => __('Height(px)', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet-active' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}' => '--ps-swiper-dots-active-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => 'yes'
				],
			]
		);

		$this->add_responsive_control(
			'active_advanced_dots_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet-active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'advanced_dots_size' => 'yes'
				],
			]
		);

		$this->add_responsive_control(
			'active_advanced_dots_align',
			[
				'label'   => __('Alignment', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __('Top', 'st-addons-for-elementor'),
						'icon'  => 'eicon-v-align-top',
					],
					'center' => [
						'title' => __('Center', 'st-addons-for-elementor'),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => __('Bottom', 'st-addons-for-elementor'),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => '--ps-swiper-dots-align: {{VALUE}};',
				],
				'condition' => [
					'advanced_dots_size' => 'yes'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'dots_active_box_shadow',
				'selector' => '{{WRAPPER}} .stafe-crystal-slider .stafe-pagination-wrap .swiper-pagination-bullet-active',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Main query render for this widget
	 * @param $posts_per_page number item query limit
	 */
	public function query_posts($posts_per_page) {

		$default = $this->getGroupControlQueryArgs();
		if ($posts_per_page) {
			$args['posts_per_page'] = $posts_per_page;
			$args['paged']  = max(1, get_query_var('paged'), get_query_var('page'));
		}
		$args         = array_merge($default, $args);
		$this->_query = new WP_Query($args);
	}

	public function render_image($image_id, $size) {
		$placeholder_image_src = Utils::get_placeholder_image_src();

		$image_src = wp_get_attachment_image_src($image_id, $size);

		if (!$image_src) {
			$image_src = $placeholder_image_src;
		} else {
			$image_src = $image_src[0];
		}

?>

		<img class="stafe-img swiper-lazy" src="<?php echo esc_url($image_src); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">

	<?php
	}

	public function render_title() {
		$settings = $this->get_settings_for_display();

		if (!$this->get_settings('show_title')) {
			return;
		}

		printf('<%1$s class="stafe-title"><a href="%2$s" title="%3$s">%4$s</a></%1$s>', esc_attr(Utils::get_valid_html_tag($settings['title_tags'])), esc_url(get_permalink()), esc_attr(get_the_title()), esc_html(get_the_title()));
	}

	public function render_category() {

		if (!$this->get_settings('show_category')) {
			return;
		}
	?>
		<div class="stafe-category" data-swiper-parallax-x="-150" data-swiper-parallax-duration="1000">
			<?php echo esc_html(stafe_get_category($this->get_settings('posts_source'))); ?>
		</div>
	<?php
	}

	public function render_date() {
		$settings = $this->get_settings_for_display();


		if (!$this->get_settings('show_date')) {
			return;
		}

	?>
		<div class="stafe-date-and-time stafe-flex stafe-flex-middle">
			<div class="stafe-date">
				<i class="stafe-icon-calendar" aria-hidden="true"></i>
				<span><?php if ($settings['human_diff_time'] == 'yes') {
							echo esc_html(st_addons_for_elementor_post_time_diff(($settings['human_diff_time_short'] == 'yes') ? 'short' : ''));
						} else {
							echo get_the_date();
						} ?>
				</span>

			</div>
			<?php if ($settings['show_time']) : ?>
				<div class="stafe-post-time">
					<i class="stafe-icon-clock" aria-hidden="true"></i>
					<?php echo esc_html(get_the_time()); ?>
				</div>
			<?php endif; ?>
		</div>

	<?php
	}

	public function render_author() {

		if (!$this->get_settings('show_author')) {
			return;
		}
	?>
		<div class="stafe-author">
			<i class="stafe-icon-user" aria-hidden="true"></i>
			<a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))) ?>">
				<?php echo get_the_author() ?>
			</a>
		</div>
	<?php
	}

	public function render_header() {
		$id              = 'stafe-crystal-slider-' . $this->get_id();
		$settings        = $this->get_settings_for_display();

		$this->add_render_attribute('crystal-slider', 'id', $id);
		$this->add_render_attribute('crystal-slider', 'class', ['stafe-crystal-slider']);

		$this->add_render_attribute(
			[
				'crystal-slider' => [
					'data-settings' => [
						wp_json_encode(array_filter([
							"autoplay"       => ("yes" == $settings["autoplay"]) ? ["delay" => $settings["autoplay_speed"]] : false,
							"loop"           => ($settings["loop"] == "yes") ? true : false,
							"speed"          => $settings["speed"]["size"],
							"effect"         => 'slide',
							"lazy"           => true,
							"parallax"       => true,
							"grabCursor"     => ($settings["grab_cursor"] === "yes") ? true : false,
							"pauseOnHover"   => ("yes" == $settings["pauseonhover"]) ? true : false,
							"slidesPerView"  => 1,
							"observer"       => ($settings["observer"]) ? true : false,
							"observeParents" => ($settings["observer"]) ? true : false,
							"navigation" => [
								"nextEl" => "#" . $id . " .stafe-navigation-next",
								"prevEl" => "#" . $id . " .stafe-navigation-prev",
							],
							"pagination" => [
								"el"             => "#" . $id . " .stafe-pagination",
								"clickable"      => "true",
							],
							"lazy" => [
								"loadPrevNext"  => "true",
							],
						]))
					]
				]
			]
		);

		$swiper_class = Plugin::$instance->experiments->is_feature_active( 'e_swiper_latest' ) ? 'swiper' : 'swiper-container';
		$this->add_render_attribute('swiper', 'class', 'swiper-carousel ' . $swiper_class);

	?>
		<div <?php $this->print_render_attribute_string('crystal-slider'); ?>>
			<div <?php echo wp_kses($this->get_render_attribute_string('swiper'), array('class', 'id', 'data-*')); ?>>
				<div class="swiper-wrapper">
				<?php
			}

			public function render_footer() {
				$settings = $this->get_settings_for_display();

				?>
				</div>
				<?php if ($settings['show_navigation']) : ?>
					<div class="stafe-navigation-wrap">
						<div class="stafe-navigation-prev">
							<i class="stafe-icon-arrow-right-<?php echo esc_html($settings['nav_arrows_icon']); ?>" aria-hidden="true"></i>
						</div>
						<div class="stafe-navigation-next">
							<i class="stafe-icon-arrow-left-<?php echo esc_html($settings['nav_arrows_icon']); ?>" aria-hidden="true"></i>
						</div>
					</div>
				<?php endif; ?>

				<?php if ($settings['show_pagination']) : ?>
					<div class="stafe-pagination-wrap">
						<div class="stafe-pagination"></div>
					</div>
				<?php endif; ?>
			</div>
		</div>

	<?php
			}

			public function render_post_grid_item($post_id, $image_size) {
				$settings = $this->get_settings_for_display();

				$this->add_render_attribute('slider-item', 'class', 'stafe-item swiper-slide', true);

	?>

		<div <?php $this->print_render_attribute_string('slider-item'); ?>>
			<div class="stafe-img-wrap">
				<?php $this->render_image(get_post_thumbnail_id($post_id), $image_size); ?>
			</div>
			<div class="stafe-content">
				<div class="st-inner-content" data-swiper-parallax-x="-250" data-swiper-parallax-duration="1000">
					<?php $this->render_category(); ?>

					<div data-swiper-parallax-x="-250" data-swiper-parallax-duration="1200">
						<?php $this->render_title(substr($this->get_name(), 4)); ?>
					</div>

					<?php if ($settings['show_author'] or $settings['show_date'] or $settings['show_reading_time']) : ?>
						<div class="stafe-meta stafe-flex stafe-flex-middle" data-swiper-parallax-x="-300" data-swiper-parallax-duration="1400">
							<?php if ($settings['show_author']) : ?>
								<?php $this->render_author(); ?>
							<?php endif; ?>
							<?php if ($settings['show_date']) : ?>
							<div data-separator="<?php echo esc_html($settings['meta_separator']); ?>">
								<?php $this->render_date(); ?>
							</div>
							<?php endif; ?>
							<?php if (_is_stafe_pro_activated()) :
							if ('yes' === $settings['show_reading_time']) : ?>
								<div class="stafe-reading-time" data-separator="<?php echo esc_html($settings['meta_separator']); ?>">
									<?php echo esc_html(st_addons_for_elementor_reading_time(get_the_content(), $settings['avg_reading_speed'])); ?>
								</div>
							<?php endif; ?>
						<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php if ($settings['show_readmore'] === 'yes') : ?>
						<div class="stafe-link-btn">
							<a href="<?php echo esc_url(get_permalink()); ?>">
								<i class="stafe-icon-plus"></i>
							</a>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
<?php
			}

			public function render() {
				$settings = $this->get_settings_for_display();

				$this->query_posts($settings['item_limit']['size']);
				$wp_query = $this->get_query();

				if (!$wp_query->found_posts) {
					return;
				}

				$this->render_header();

				while ($wp_query->have_posts()) {
					$wp_query->the_post();
					$thumbnail_size = $settings['primary_thumbnail_size'];

					$this->render_post_grid_item(get_the_ID(), $thumbnail_size);
				}

				$this->render_footer();

				wp_reset_postdata();
			}
		}
