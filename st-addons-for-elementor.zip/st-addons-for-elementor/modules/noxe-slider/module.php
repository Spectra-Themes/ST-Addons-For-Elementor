<?php
namespace STElementorAddon\Modules\NoxeSlider;

use STElementorAddon\Base\ST_Addons_For_ElementorModule_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Module extends ST_Addons_For_ElementorModule_Base {

	public function get_name() {
		return 'noxe-slider';
	}

	public function get_widgets() {

		$widgets = [
			'Noxe_Slider',
		];
		
		return $widgets;
	}
}
