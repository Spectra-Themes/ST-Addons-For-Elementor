<?php
namespace STElementorAddon\Modules\TagCloud;

use STElementorAddon\Base\ST_Addons_For_ElementorModule_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Module extends ST_Addons_For_ElementorModule_Base {

	public function get_name() {
		return 'tag-cloud';
	}

	public function get_widgets() {

		$widgets = [
			'Tag_Cloud',
		];
		
		return $widgets;
	}
}
