<?php

namespace STElementorAddon\Modules\TagCloud\Widgets;

use STElementorAddon\Base\Module_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;

if (!defined('ABSPATH')) {
	exit;
} // Exit if accessed directly

class Tag_Cloud extends Module_Base {
	private $_query = null;

	public function get_name() {
		return 'stafe-tag-cloud';
	}

	public function get_title() {
		return STAFE . esc_html__('Tag Cloud', 'st-addons-for-elementor');
	}

	public function get_icon() {
		return 'stafe-widget-icon stafe-icon-tag-cloud';
	}

	public function get_categories() {
		return ['st-addons-for-elementor'];
	}

	public function get_keywords() {
		return ['post', 'list', 'blog', 'recent', 'news', 'category', 'tag', 'cloud', 'tags'];
	}

	public function get_style_depends() {
		if ($this->stafe_is_edit_mode()) {
			return ['stafe-all-styles'];
		} else {
			return ['stafe-tag-cloud'];
		}
	}

	public function get_query() {
		return $this->_query;
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__('Layout', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'layout_style',
			[
				'label'   => esc_html__('Style', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'inline',
				'options' => [
					'inline' => esc_html__('Inline', 'st-addons-for-elementor'),
					'grid'   => esc_html__('Grid', 'st-addons-for-elementor'),
				],
				'prefix_class' => 'stafe-layout-style--',
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'          => __('Columns', 'st-addons-for-elementor'),
				'type'           => Controls_Manager::SELECT,
				'default'        => '3',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				],
				'selectors'      => [
					'{{WRAPPER}} .stafe-tag-cloud' => 'grid-template-columns: repeat({{SIZE}}, 1fr);',
				],
				'condition' => [
					'layout_style' => 'grid'
				]
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'     => esc_html__('Row Gap', 'st-addons-for-elementor') . STAFE_NC,
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout_style' => 'grid'
				]
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'     => esc_html__('Column Gap', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout_style' => 'grid'
				]
			]
		);

		$this->add_responsive_control(
			'item_gap',
			[
				'label'     => esc_html__('Item Gap', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout_style' => 'inline'
				]
			]
		);

		$this->add_responsive_control(
			'item_height',
			[
				'label'     => esc_html__('Item Height(px)', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 50,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout_style' => 'grid'
				]
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => __('Alignment', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __('Left', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __('Right', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-right',
					],
					'space-between'  => [
						'title' => __('justify', 'st-addons-for-elementor'),
						'icon'  => 'eicon-text-align-justify',
					]
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item' => 'justify-content: {{VALUE}};',
				],
				'condition' => [
					'layout_style' => 'grid'
				]
			]
		);

		$this->add_control(
			'show_count',
			[
				'label'     => esc_html__('Show Count', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'separator' => 'before'
			]
		);

		$this->add_control(
			'show_text',
			[
				'label'   => esc_html__('Show Description as Tooltip', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'tooltip_position',
			[
				'label'   => esc_html__('Tooltip Position', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => [
					'top'          => esc_html__('Top', 'st-addons-for-elementor'),
					'top-left'     => esc_html__('Top Left', 'st-addons-for-elementor'),
					'top-right'    => esc_html__('Top Right', 'st-addons-for-elementor'),
					'bottom'       => esc_html__('Bottom', 'st-addons-for-elementor'),
					'bottom-left'  => esc_html__('Bottom Left', 'st-addons-for-elementor'),
					'bottom-right' => esc_html__('Bottom Right', 'st-addons-for-elementor'),
					'left'         => esc_html__('Left', 'st-addons-for-elementor'),
					'right'        => esc_html__('Right', 'st-addons-for-elementor'),
				],
				'condition' => [
					'show_text' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_post_grid_query',
			[
				'label' => esc_html__('Query', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'item_limit',
			[
				'label' => esc_html__('Item Limit', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 50,
					],
				],
			]
		);

		$this->add_control(
			'taxonomy',
			[
				'label'   => esc_html__('Taxonomy', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post_tag',
				'options' => st_addons_for_elementor_get_taxonomies(),
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'   => esc_html__('Order By', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'name',
				'options' => [
					'name'       => esc_html__('Name', 'st-addons-for-elementor'),
					'post_date'  => esc_html__('Date', 'st-addons-for-elementor'),
					'post_title' => esc_html__('Title', 'st-addons-for-elementor'),
					'menu_order' => esc_html__('Menu Order', 'st-addons-for-elementor'),
					'rand'       => esc_html__('Random', 'st-addons-for-elementor'),
				],
			]
		);



		$this->add_control(
			'order',
			[
				'label'   => esc_html__('Order', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'asc',
				'options' => [
					'asc'  => esc_html__('ASC', 'st-addons-for-elementor'),
					'desc' => esc_html__('DESC', 'st-addons-for-elementor'),
				],
			]
		);

		$this->add_control(
			'exclude',
			[
				'label'       => esc_html__('Exclude', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __('Tag ID: 12,3,1', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'parent',
			[
				'label'       => esc_html__('Parent', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __('Tag ID: 12', 'st-addons-for-elementor'),
			]
		);

		$this->end_controls_section();

		//Style
		$this->start_controls_section(
			'stafe_section_style',
			[
				'label' => esc_html__('Items', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('tabs_item_style');

		$this->start_controls_tab(
			'tab_item_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'single_background',
			[
				'label'   => esc_html__('Single Background', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'item_background',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item',
				'condition' => [
					'single_background' => 'yes'
				]
			]
		);

		$this->add_control(
			'multiple_background',
			[
				'label'       => esc_html__('Multiple Background', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => '#000000, #f5f5f5, #999999',
				'condition' => [
					'single_background' => ''
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item',
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => __('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_shadow',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_item_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'itam_background_hover',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item:hover',
			]
		);

		$this->add_control(
			'item_border_color_hover',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item:hover' => 'border-color: {{VALUE}};'
				],
				'condition' => [
					'item_border_border!' => ''
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_shadow_hover',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item:hover',
			]
		);

		// $this->add_control(
		// 	'hover_animation',
		// 	[
		// 		'label' => esc_html__( 'Hover Animation', 'st-addons-for-elementor' ),
		// 		'type' => Controls_Manager::HOVER_ANIMATION,
		// 		'separator' => 'before'
		// 	]
		// );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_category_name',
			[
				'label' => esc_html__('Name', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'category_name_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'category_name_color_hover',
			[
				'label'     => esc_html__('Hover Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item:hover .stafe-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'category_name_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-name',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_count',
			[
				'label' => esc_html__('Count', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'count_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'count_color_hover',
			[
				'label'     => esc_html__('Hover Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item:hover .stafe-count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'count_background',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'count_border',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count',
			]
		);

		$this->add_responsive_control(
			'count_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'count_padding',
			[
				'label'      => __('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'count_box_shadow',
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'count_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count',
			]
		);

		$this->add_responsive_control(
			'count_spacing',
			[
				'label'     => __('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-tag-cloud .stafe-item .stafe-count' => 'margin-left: {{SIZE}}px;'
				],
			]
		);

		$this->end_controls_section();
	}

	public function render() {
		$settings = $this->get_settings_for_display();

		$categories = get_categories([
			'taxonomy'   => $settings["taxonomy"],
			'orderby'    => $settings["orderby"],
			'order'      => $settings["order"],
			'hide_empty' => 0,
			'exclude'    => explode(',', esc_attr($settings["exclude"])),
			'parent'     => $settings["parent"],
		]);


		if (!empty($categories)) :

			if ( 'rand' == $settings["orderby"] ) {
				shuffle($categories);
			}
			
			?>
			<div class="stafe-tag-cloud">
				<?php
				$multiple_bg = explode(',', rtrim($settings['multiple_background'], ','));
				$total_category = count($categories);

				// re-creating array for the multiple colors
				$jCount = count($multiple_bg);
				$j = 0;
				for ($i = 0; $i < $total_category; $i++) {
					if ($j == $jCount) {
						$j = 0;
					}
					$multiple_bg_create[$i] = $multiple_bg[$j];
					$j++;
				}


				foreach ($categories as $index => $cat) :
					$output = '';

					$this->add_render_attribute('category-item', 'class', 'stafe-item', true);

					$this->add_render_attribute('category-item', 'href', get_category_link($cat->cat_ID), true);

					$bg_color = strToHex($cat->cat_name);

					if (!empty($settings['multiple_background'])) {
						$bg_color =  $multiple_bg_create[$index];
						if (!preg_match('/#([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?\b/', $multiple_bg_create[$index])) {
							$bg_color = strToHex($cat->cat_name);
						}
					}

					if ($settings['single_background'] == '') {
						$this->add_render_attribute('category-item', 'style', "background-color: $bg_color", true);
					}

					if (!empty($cat->category_description) and $settings['show_text'] == 'yes') {
						$this->add_render_attribute('category-item', 'aria-label', $cat->category_description, true);
						$this->add_render_attribute('category-item', 'role', 'tooltip', true);
						$this->add_render_attribute('category-item', 'data-microtip-position', $settings['tooltip_position'], true);
					}

				?>

					<a <?php $this->print_render_attribute_string('category-item'); ?>>
						<span class="stafe-name"><?php echo esc_html($cat->cat_name); ?></span>

						<?php if ($settings['show_count'] == 'yes') : ?>
							<span class="stafe-count"><?php echo esc_html($cat->category_count); ?></span>
						<?php endif; ?>
					</a>
				<?php

					if (!empty($settings['item_limit']['size'])) {
						if ($index == ($settings['item_limit']['size'] - 1)) break;
					}

				endforeach;
				?>
			</div>
<?php
		else :

			echo '<div class="stafe-alert">' . esc_html__('Category Not Found!', 'st-addons-for-elementor') . '</div>';

		endif;
	}
}
