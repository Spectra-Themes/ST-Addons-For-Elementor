<?php

namespace STElementorAddon\Modules\AlterGrid\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Icons_Manager;

use STElementorAddon\Traits\Global_Widget_Controls;
use STElementorAddon\Traits\Global_Widget_Functions;
use STElementorAddon\Includes\Controls\GroupQuery\Group_Control_Query;
use WP_Query;

if (!defined('ABSPATH')) {
	exit;
} // Exit if accessed directly

class Alter_Grid extends Group_Control_Query {

	use Global_Widget_Controls;
	use Global_Widget_Functions;

	private $_query = null;

	public function get_name() {
		return 'stafe-alter-grid';
	}

	public function get_title() {
		return STAFE . esc_html__('Alter Grid', 'st-addons-for-elementor');
	}

	public function get_icon() {
		return 'stafe-widget-icon stafe-icon-alter-grid';
	}

	public function get_categories() {
		return ['st-addons-for-elementor'];
	}

	public function get_keywords() {
		return ['post', 'grid', 'blog', 'recent', 'news', 'alter'];
	}

	public function get_style_depends() {
		if ($this->stafe_is_edit_mode()) {
			return ['stafe-all-styles'];
		} else {
			return ['stafe-font', 'stafe-alter-grid'];
		}
	}

	public function get_query() {
		return $this->_query;
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__('Layout', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'grid_style',
			[
				'label'   => esc_html__('Layout Style', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => esc_html__('Style 01', 'st-addons-for-elementor'),
					'2' => esc_html__('Style 02', 'st-addons-for-elementor'),
					'3' => esc_html__('Style 03', 'st-addons-for-elementor'),
				],
			]
		);

		$column_size = apply_filters('stafe_column_size', '');

		$this->add_responsive_control(
			'columns',
			[
				'label' => __('Columns', 'st-addons-for-elementor') . STAFE_PC,
				'type' => Controls_Manager::SELECT,
				'default'        => '3',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options' => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-style-1' => $column_size,
				],
				'condition' => [
					'grid_style' => ['1']
				],
				'classes' => STAFE_IS_PC
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'     => esc_html__('Row Gap', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-grid' => 'grid-row-gap: {{SIZE}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'     => esc_html__('Column Gap', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-grid' => 'grid-column-gap: {{SIZE}}{{UNIT}};',
				]
			]
		);
		
		$this->add_responsive_control(
			'image_height',
			[
				'label'     => esc_html__('Image Height', 'st-addons-for-elementor') . STAFE_NC,
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 100,
						'max' => 800,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-img-wrap .stafe-main-img .stafe-img' => 'height: {{SIZE}}px;',
				],
				'condition' => [
					'grid_style' => ['1']
				]
			]
		);

		$this->add_responsive_control(
			'secondary_image_height',
			[
				'label'     => esc_html__('Secondary Image Height', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 100,
						'max' => 800,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+2), {{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+3), {{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+4), {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+2) .stafe-img-wrap .stafe-main-img .stafe-img, {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+3) .stafe-img-wrap .stafe-main-img .stafe-img, {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+4) .stafe-img-wrap .stafe-main-img .stafe-img, {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+5) .stafe-img-wrap .stafe-main-img .stafe-img' => 'height: {{SIZE}}px;',
				],
				'condition' => [
					'grid_style' => ['2', '3']
				]
			]
		);

		$this->add_responsive_control(
			'secondary_image_width',
			[
				'label'     => esc_html__('Secondary Image Width', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 100,
						'max' => 800,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+2) .stafe-img-wrap .stafe-main-img, {{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+3) .stafe-img-wrap .stafe-main-img, {{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+4) .stafe-img-wrap .stafe-main-img' => 'width: {{SIZE}}px;',
				],
				'condition' => [
					'grid_style' => ['2']
				]
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'primary_thumbnail',
				'exclude' => ['custom'],
				'default' => 'medium',
			]
		);

		$this->add_control(
			'content_on_image',
			[
				'label'        => esc_html__('Content on Image', 'st-addons-for-elementor') . STAFE_NC . STAFE_PC,
				'type'         => Controls_Manager::SWITCHER,
				'description'  => esc_html__('If you enable this feature, Read more type "on image" will not work.', 'st-addons-for-elementor'),
				'prefix_class' => 'stafe-content-on-image-',
				'separator'    => 'before',
				'classes'   => STAFE_IS_PC,
				'render_type'  => 'template',
				'condition'    => [
					'grid_style' => ['1']
				]
			]
		);

		$this->add_responsive_control(
			'item_height',
			[
				'label'     => esc_html__('Item Height', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 100,
						'max' => 800,
					],
				],
				'selectors' => [
					'{{WRAPPER}}.stafe-content-on-image-yes .stafe-alter-grid .stafe-item' => 'height: {{SIZE}}px;',
				],
				'condition' => [
					'content_on_image' => 'yes'
				]
			]
		);
		
		$this->add_responsive_control(
			'content_height',
			[
				'label'     => esc_html__('Content Height', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 50,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}}.stafe-content-on-image-yes .stafe-alter-grid .stafe-item .stafe-content' => 'height: {{SIZE}}px;',
				],
				'condition' => [
					'content_on_image' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		// Query Settings
		$this->start_controls_section(
			'section_post_query_builder',
			[
				'label' => __('Query', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'item_limit',
			[
				'label'   => esc_html__('Item Limit', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'px' => [
						'min' => 0,
						'max' => 21,
						'step' => 3
					],
				],
				'default' => [
					'size' => 6,
				],
				'condition' => [
					'grid_style' => ['1']
				]
			]
		);

		$this->add_control(
			'item_limit_2',
			[
				'label' => esc_html__('Item Limit', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 4
					],
				],
				'default' => [
					'size' => 4,
				],
				'condition' => [
					'grid_style' => ['2']
				]
			]
		);

		$this->add_control(
			'item_limit_3',
			[
				'label' => esc_html__('Item Limit', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 5
					],
				],
				'default' => [
					'size' => 5,
				],
				'condition' => [
					'grid_style' => ['3']
				]
			]
		);

		$this->register_query_builder_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_additional',
			[
				'label' => esc_html__('Additional', 'st-addons-for-elementor'),
			]
		);

		//Global Title Controls
		$this->register_title_controls();

		$this->add_control(
			'show_excerpt',
			[
				'label'   => esc_html__('Show Text', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'excerpt_length',
			[
				'label'       => esc_html__('Text Limit', 'st-addons-for-elementor'),
				'description' => esc_html__('It\'s just work for main content, but not working with excerpt. If you set 0 so you will get full main content.', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 30,
				'condition'   => [
					'show_excerpt' => 'yes'
				],
			]
		);

		$this->add_control(
			'strip_shortcode',
			[
				'label'     => esc_html__('Strip Shortcode', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'show_excerpt' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_author',
			[
				'label'   => esc_html__('Show Author', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'separator' => 'before'
			]
		);

		$this->add_control(
			'meta_separator',
			[
				'label'       => __('Separator', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXT,
				'default'     => '|',
				'label_block' => false,
			]
		);

		//Global Date Controls
		$this->register_date_controls();

		// if (_is_stafe_pro_activated()) :
		// endif;
		//Global Reading Time Controls
		$this->register_reading_time_controls();

		$this->add_control(
			'show_category',
			[
				'label'   => esc_html__('Show Category', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'separator' => 'before'
			]
		);

		$this->add_control(
			'primary_meta_end_position',
			[
				'label'   => esc_html__('Primary Meta End Position', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'prefix_class' => 'stafe-primary-meta-end-position--',
			]
		);

		$this->add_control(
			'secondary_meta_end_position',
			[
				'label'   => esc_html__('Secondary Meta End Position', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'prefix_class' => 'stafe-secondary-meta-end-position--',
				'condition' => [
					'grid_style!' => '1'
				]
			]
		);

		$this->add_control(
			'readmore_type',
			[
				'label'   => esc_html__('Read More Type', 'st-addons-for-elementor') . STAFE_PC,
				'type'    => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'     => esc_html__('None', 'st-addons-for-elementor'),
					'classic'  => esc_html__('Classic', 'st-addons-for-elementor'),
					'on_image' => esc_html__('On Image', 'st-addons-for-elementor'),
				],
				'separator' => 'before',
				'classes'   => STAFE_IS_PC,
			]
		);

		$this->add_control(
			'show_post_format',
			[
				'label'   => esc_html__('Post Format', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SWITCHER,
				'separator' => 'before'
			]
		);

		$this->add_control(
			'show_pagination',
			[
				'label' => esc_html__('Pagination', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SWITCHER,
				'separator' => 'before'
			]
		);

		$this->add_control(
			'global_link',
			[
				'label'        => __('Item Wrapper Link', 'st-addons-for-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'stafe-global-link-',
				'description'  => __('Be aware! When Item Wrapper Link activated then title link and read more link will not work', 'st-addons-for-elementor'),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_readmore',
			[
				'label' => esc_html__('Read More', 'st-addons-for-elementor'),
				'condition'   => [
					'readmore_type' => 'classic',
				],
			]
		);

		$this->add_control(
			'readmore_text',
			[
				'label'       => esc_html__('Read More Text', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__('Read More', 'st-addons-for-elementor'),
				'placeholder' => esc_html__('Read More', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'readmore_icon',
			[
				'label'       => esc_html__('Icon', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::ICONS,
				'label_block' => false,
				'skin'        => 'inline'
			]
		);

		$this->add_control(
			'readmore_icon_align',
			[
				'label'   => esc_html__('Icon Position', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'right',
				'toggle' => false,
				'options' => [
					'left' => [
						'title' => esc_html__('Left', 'st-addons-for-elementor'),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__('Right', 'st-addons-for-elementor'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'condition' => [
					'readmore_icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'readmore_icon_indent',
			[
				'label'   => esc_html__('Icon Spacing', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 8,
				],
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'condition' => [
					'readmore_icon[value]!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-button-icon-align-right' => is_rtl() ? 'margin-right: {{SIZE}}{{UNIT}};' : 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .stafe-alter-grid .stafe-button-icon-align-left'  => is_rtl() ? 'margin-left: {{SIZE}}{{UNIT}};' : 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		//Style
		$this->start_controls_section(
			'stafe_section_style',
			[
				'label' => esc_html__('Items', 'st-addons-for-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_blur_effect',
			[
				'label'       => esc_html__('Glassmorphism', 'st-addons-for-elementor'),
				'type'        => Controls_Manager::SWITCHER,
				'description' => sprintf(__('This feature will not work in the Firefox browser untill you enable browser compatibility so please %1s look here %2s', 'st-addons-for-elementor'), '<a href="https://developer.mozilla.org/en-US/docs/Web/CSS/backdrop-filter#Browser_compatibility" target="_blank">', '</a>'),
				'default'     => 'yes',
				'condition'   => [
					'content_on_image' => 'yes'
				]
			]
		);

		$this->add_control(
			'overlay_blur_level',
			[
				'label'     => __('Blur Level', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'step' => 1,
						'max'  => 50,
					]
				],
				'default'   => [
					'size' => 10
				],
				'selectors' => [
					'{{WRAPPER}}.stafe-content-on-image-yes .stafe-alter-grid .stafe-content' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);'
				],
				'condition' => [
					'overlay_blur_effect' => 'yes',
					'content_on_image' => 'yes'
				]
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => __('Content Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs('tabs_item_style');

		$this->start_controls_tab(
			'tab_item_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'itam_background',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item',
				'condition' => [
					'content_on_image!' => 'yes'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'itam_content_background',
				'selector' => '{{WRAPPER}}.stafe-content-on-image-yes .stafe-alter-grid .stafe-content',
				'exclude'  => ['image'],
				'condition' => [
					'content_on_image' => 'yes'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'item_border',
				'label'       => __('Border', 'st-addons-for-elementor'),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .stafe-alter-grid .stafe-item',
				'separator'   => 'before'
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_shadow',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_item_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'itam_background_color_hover',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item:hover',
				'condition' => [
					'content_on_image!' => 'yes'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'itam_content_hover_background',
				'selector' => '{{WRAPPER}}.stafe-content-on-image-yes .stafe-alter-grid .stafe-item:hover .stafe-content',
				'exclude'  => ['image'],
				'condition' => [
					'content_on_image' => 'yes'
				]
			]
		);

		$this->add_control(
			'item_border_color_hover',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item:hover' => 'border-color: {{VALUE}};'
				],
				'condition' => [
					'item_border_border!' => ''
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_shadow_hover',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_title',
			[
				'label'     => esc_html__('Title', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_style',
			[
				'label'   => esc_html__('Style', 'st-addons-for-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'underline',
				'options' => [
					'underline'        => esc_html__('Underline', 'st-addons-for-elementor'),
					'middle-underline' => esc_html__('Middle Underline', 'st-addons-for-elementor'),
					'overline'         => esc_html__('Overline', 'st-addons-for-elementor'),
					'middle-overline'  => esc_html__('Middle Overline', 'st-addons-for-elementor'),
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label'     => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'secondary_title_typography',
				'label'     => esc_html__('Secondary Typography', 'st-addons-for-elementor'),
				'selector'  => '{{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+2) .stafe-title, {{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+3) .stafe-title, {{WRAPPER}} .stafe-alter-grid .stafe-style-2 .stafe-item:nth-child(4n+4) .stafe-title, {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+2) .stafe-title, {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+3) .stafe-title, {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+4) .stafe-title, {{WRAPPER}} .stafe-alter-grid .stafe-style-3 .stafe-item:nth-child(5n+5) .stafe-title',
				'condition' => [
					'grid_style' => ['2', '3']
				]
			]
		);

		$this->add_control(
			'title_advanced_style',
			[
				'label' => esc_html__('Advanced Style', 'st-addons-for-elementor'),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'title_background',
			[
				'label'     => esc_html__('Background Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'title_advanced_style' => 'yes'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'      => 'title_text_shadow',
				'label'     => __('Text Shadow', 'st-addons-for-elementor'),
				'selector'  => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a',
				'condition' => [
					'title_advanced_style' => 'yes'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'title_border',
				'selector'  => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a',
				'condition' => [
					'title_advanced_style' => 'yes'
				]
			]
		);

		$this->add_responsive_control(
			'title_border_radius',
			[
				'label'      => __('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'title_advanced_style' => 'yes'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'title_box_shadow',
				'selector'  => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a',
				'condition' => [
					'title_advanced_style' => 'yes'
				]
			]
		);

		$this->add_responsive_control(
			'title_text_padding',
			[
				'label'      => __('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'title_advanced_style' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_text',
			[
				'label'     => esc_html__('Text', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_excerpt' => 'yes',
				],
			]
		);

		$this->add_control(
			'text_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-text-wrap .stafe-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'text_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-text-wrap .stafe-text',
			]
		);

		$this->add_responsive_control(
			'text_margin',
			[
				'label'      => __('Margin', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-text-wrap .stafe-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_meta',
			[
				'label'     => esc_html__('Meta', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'  => 'show_author',
							'value' => 'yes'
						],
						[
							'name'  => 'show_date',
							'value' => 'yes'
						]
					]
				],
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-meta .stafe-blog-author a, {{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-meta' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'meta_hover_color',
			[
				'label'     => esc_html__('Hover Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-meta .stafe-blog-author a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'meta_spacing',
			[
				'label'     => esc_html__('Space Between', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-meta > div:before' => 'margin: 0 {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'meta_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-meta',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_category',
			[
				'label'     => esc_html__('Category', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_category' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'category_spacing',
			[
				'label'     => esc_html__('Spacing', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs('tabs_category_style');

		$this->start_controls_tab(
			'tab_category_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'category_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'category_background',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'category_border',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a',
			]
		);

		$this->add_responsive_control(
			'category_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'category_padding',
			[
				'label'      => esc_html__('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'category_margin',
			[
				'label'      => esc_html__('Margin', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'category_spacing_between',
			[
				'label'     => esc_html__('Space Between', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a+a' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'category_shadow',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'category_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_category_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'category_hover_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'category_hover_background',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a:hover',
			]
		);

		$this->add_control(
			'category_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'category_border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-category a:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		if (_is_stafe_pro_activated()) {
			$this->start_controls_section(
				'section_style_readmore',
				[
					'label'     => esc_html__('Read More', 'st-addons-for-elementor'),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => [
						'readmore_type' => 'classic',
					],
				]
			);

			$this->start_controls_tabs('tabs_readmore_style');

			$this->start_controls_tab(
				'tab_readmore_normal',
				[
					'label' => esc_html__('Normal', 'st-addons-for-elementor'),
				]
			);

			$this->add_control(
				'readmore_color',
				[
					'label'     => esc_html__('Color', 'st-addons-for-elementor'),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore' => 'color: {{VALUE}};',
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore svg *' => 'fill: {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Background::get_type(),
				[
					'name'     => 'readmore_background',
					'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore',
				]
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name'        => 'readmore_border',
					'label'       => esc_html__('Border', 'st-addons-for-elementor'),
					'placeholder' => '1px',
					'default'     => '1px',
					'selector'    => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore',
				]
			);

			$this->add_responsive_control(
				'readmore_border_radius',
				[
					'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => ['px', '%'],
					'selectors'  => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'readmore_padding',
				[
					'label'      => esc_html__('Padding', 'st-addons-for-elementor'),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => ['px', 'em', '%'],
					'selectors'  => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'readmore_margin',
				[
					'label'      => __('Margin', 'st-addons-for-elementor'),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => ['px', 'em', '%'],
					'selectors'  => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					]
				]
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				[
					'name'     => 'readmore_shadow',
					'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore',
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'readmore_typography',
					'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
					'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore',
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_readmore_hover',
				[
					'label' => esc_html__('Hover', 'st-addons-for-elementor'),
				]
			);

			$this->add_control(
				'readmore_hover_color',
				[
					'label'     => esc_html__('Color', 'st-addons-for-elementor'),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore:hover' => 'color: {{VALUE}};',
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore:hover svg *' => 'fill: {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Background::get_type(),
				[
					'name'     => 'readmore_hover_background',
					'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore:hover',
				]
			);

			$this->add_control(
				'readmore_hover_border_color',
				[
					'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
					'type'      => Controls_Manager::COLOR,
					'condition' => [
						'readmore_border_border!' => '',
					],
					'selectors' => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-item .stafe-readmore:hover' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'readmore_hover_animation',
				[
					'label' => esc_html__('Animation', 'st-addons-for-elementor'),
					'type'  => Controls_Manager::HOVER_ANIMATION,
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->end_controls_section();

			$this->start_controls_section(
				'section_style_readmore_on_image',
				[
					'label'     => esc_html__('Read More On Image', 'st-addons-for-elementor'),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => [
						'readmore_type' => 'on_image',
					],
				]
			);

			$this->add_control(
				'readmore_on_image_color',
				[
					'label'     => __('Color', 'st-addons-for-elementor'),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-readmore-on-image .stafe-readmore-icon:before, {{WRAPPER}} .stafe-alter-grid .stafe-item:hover .stafe-readmore-on-image .stafe-readmore-icon span:before, {{WRAPPER}} .stafe-alter-grid .stafe-item:hover .stafe-readmore-on-image .stafe-readmore-icon span:after' => 'background: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'item_image_overlay_color',
				[
					'label'     => esc_html__('Overlay Color', 'st-addons-for-elementor'),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .stafe-alter-grid .stafe-readmore-on-image:before' => 'background: linear-gradient(0deg, {{VALUE}} 0, rgba(141, 153, 174, 0.1) 100%);',
					],
				]
			);

			$this->end_controls_section();
		}

		$this->start_controls_section(
			'section_style_post_format',
			[
				'label'     => esc_html__('Post Format', 'st-addons-for-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_post_format' => 'yes',
				],
			]
		);

		$this->start_controls_tabs('tabs_post_format_style');

		$this->start_controls_tab(
			'tab_post_format_normal',
			[
				'label' => esc_html__('Normal', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'post_format_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-format a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_format_background',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-post-format a',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'post_format_border',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-post-format a',
			]
		);

		$this->add_responsive_control(
			'post_format_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-format a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'post_format_padding',
			[
				'label'      => esc_html__('Padding', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-format a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'post_format_margin',
			[
				'label'      => esc_html__('Margin', 'st-addons-for-elementor'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-format a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_format_shadow',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-post-format a',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'post_format_typography',
				'label'    => esc_html__('Typography', 'st-addons-for-elementor'),
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-post-format a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_post_format_hover',
			[
				'label' => esc_html__('Hover', 'st-addons-for-elementor'),
			]
		);

		$this->add_control(
			'post_format_hover_color',
			[
				'label'     => esc_html__('Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-format a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_format_hover_background',
				'selector' => '{{WRAPPER}} .stafe-alter-grid .stafe-post-format a:hover',
			]
		);

		$this->add_control(
			'post_format_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'st-addons-for-elementor'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'post_format_border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .stafe-alter-grid .stafe-post-format a:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		//Global Pagination Controls
		$this->register_pagination_controls();
	}

	/**
	 * Main query render for this widget
	 * @param $posts_per_page number item query limit
	 */
	public function query_posts($posts_per_page) {

		$default = $this->getGroupControlQueryArgs();
		if ($posts_per_page) {
			$args['posts_per_page'] = $posts_per_page;
			$args['paged']  = max(1, get_query_var('paged'), get_query_var('page'));
		}
		$args         = array_merge($default, $args);
		$this->_query = new WP_Query($args);
	}

	public function render_readmore() {
		$settings = $this->get_settings_for_display();

		$animation = ($this->get_settings('readmore_hover_animation')) ? ' elementor-animation-' . $this->get_settings('readmore_hover_animation') : '';

?>

		<a href="<?php echo esc_url(get_permalink()); ?>" class="stafe-readmore stafe-display-inline-block <?php echo esc_attr($animation); ?>">
			<?php echo esc_html($this->get_settings('readmore_text')); ?>

			<?php if ($settings['readmore_icon']['value']) : ?>
				<span class="stafe-button-icon-align-<?php echo esc_attr($this->get_settings('readmore_icon_align')); ?>">
					<?php Icons_Manager::render_icon($settings['readmore_icon'], ['aria-hidden' => 'true', 'class' => 'fa-fw']); ?>
				</span>
			<?php endif; ?>
		</a>
	<?php
	}

	public function render_readmore_on_image() {

	?>
		<a href="<?php echo esc_url(get_permalink()); ?>" class="stafe-readmore-on-image">
			<span class="stafe-readmore-icon"><span></span></span>
		</a>
	<?php
	}

	public function render_post_grid_item($post_id, $image_size, $excerpt_length) {
		$settings = $this->get_settings_for_display();

		if ('yes' == $settings['global_link']) {

			$this->add_render_attribute('grid-item', 'onclick', "window.open('" . esc_url(get_permalink()) . "', '_self')", true);
		}
		$this->add_render_attribute('grid-item', 'class', 'stafe-item', true);

	?>
		<div <?php $this->print_render_attribute_string('grid-item'); ?>>
			<div class="stafe-item-box">
				<div class="stafe-img-wrap">
					<div class="stafe-main-img">
						<?php $this->render_image(get_post_thumbnail_id($post_id), $image_size); ?>
						<?php if (_is_stafe_pro_activated()) : ?>
							<?php if ($settings['readmore_type'] == 'on_image') : ?>
								<?php $this->render_readmore_on_image(); ?>
							<?php endif; ?>
						<?php endif; ?>
						<?php $this->render_post_format(); ?>
					</div>
				</div>

				<div class="stafe-content">
					<div>

						<?php $this->render_category(); ?>

						<?php $this->render_title(substr($this->get_name(), 4)); ?>
						<div class="stafe-text-wrap">
							<?php $this->render_excerpt($excerpt_length); ?>
							<?php if (_is_stafe_pro_activated()) : ?>
								<?php if ($settings['readmore_type'] == 'classic') : ?>
									<?php $this->render_readmore(); ?>
								<?php endif; ?>
							<?php endif; ?>
						</div>

						<?php if ($settings['show_author'] or $settings['show_date'] or $settings['show_reading_time']) : ?>
							<div class="stafe-meta">
								<?php if ($settings['show_author']) : ?>
									<div class="stafe-blog-author" data-separator="<?php echo esc_html($settings['meta_separator']); ?>">
										<a class="author-name" href="<?php echo get_author_posts_url(get_the_author_meta('ID')) ?>">
											<?php echo get_the_author() ?>
										</a>
									</div>
								<?php endif; ?>

								<?php if ('yes' === $settings['show_date']) : ?>
									<div data-separator="<?php echo esc_html($settings['meta_separator']); ?>">
										<?php $this->render_date(); ?>
									</div>
								<?php endif; ?>

								<?php if (_is_stafe_pro_activated()) :
									if ('yes' === $settings['show_reading_time']) : ?>
										<div class="stafe-reading-time" data-separator="<?php echo esc_html($settings['meta_separator']); ?>">
											<?php echo st_addons_for_elementor_reading_time(get_the_content(), $settings['avg_reading_speed']); ?>
										</div>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						<?php endif; ?>

					</div>
				</div>

			</div>
		</div>
	<?php
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ($settings['grid_style'] == '2') {
			$this->query_posts($settings['item_limit_2']['size']);
		} elseif ($settings['grid_style'] == '3') {
			$this->query_posts($settings['item_limit_3']['size']);
		} else {
			$this->query_posts($settings['item_limit']['size']);
		}

		$wp_query = $this->get_query();

		if (!$wp_query->found_posts) {
			return;
		}

		$this->add_render_attribute('grid-wrap', 'class', 'stafe-post-grid');
		$this->add_render_attribute('grid-wrap', 'class', 'stafe-style-' . $settings['grid_style']);

		if (isset($settings['stafe_in_animation_show']) && ($settings['stafe_in_animation_show'] == 'yes')) {
			$this->add_render_attribute('grid-wrap', 'class', 'stafe-in-animation');
			if (isset($settings['stafe_in_animation_delay']['size'])) {
				$this->add_render_attribute('grid-wrap', 'data-in-animation-delay', $settings['stafe_in_animation_delay']['size']);
			}
		}

	?>

		<div class="stafe-alter-grid">
			<div <?php $this->print_render_attribute_string('grid-wrap'); ?>>

				<?php while ($wp_query->have_posts()) :
					$wp_query->the_post();

					$thumbnail_size = $settings['primary_thumbnail_size'];

				?>

					<?php $this->render_post_grid_item(get_the_ID(), $thumbnail_size, $settings['excerpt_length']); ?>

				<?php endwhile; ?>
			</div>
		</div>

		<?php

		if ($settings['show_pagination']) { ?>
			<div class="ep-pagination">
				<?php st_addons_for_elementor_post_pagination($wp_query, $this->get_id()); ?>
			</div>
<?php
		}
		wp_reset_postdata();
	}
}
