<?php

namespace STElementorAddon;

if (!defined('ABSPATH')) {
	exit;
} // Exit if accessed directly


require_once STAFE_ADMIN_PATH . 'class-settings-api.php';

if (current_user_can('manage_options')) {
	require_once STAFE_ADMIN_PATH . 'admin-feeds.php';
}

// element pack admin settings here
require_once STAFE_ADMIN_PATH . 'admin-settings.php';

/**
 * Admin class
 */

class Admin
{

	public function __construct()
	{

		// Embed the Script on our Plugin's Option Page Only
		if (isset($_GET['page']) && ($_GET['page'] == 'st_addons_for_elementor_options')) {
			add_action('admin_enqueue_scripts', [$this, 'enqueue_styles']);
		}
		add_action('admin_init', [$this, 'enqueue_admin_script']);

		// Admin settings controller
		require_once STAFE_ADMIN_PATH . 'module-settings.php';

		// register_activation_hook(STAFE__FILE__, 'install_and_activate');

		add_action('admin_init', [$this, 'admin_notice_styles']);


	}

	public function admin_notice_styles(){
		wp_enqueue_style('stafe-admin-notice', STAFE_ADMIN_ASSETS_URL . 'css/stafe-admin-notice.css', [], STAFE_VER);
	}


	function install_and_activate()
	{

		// I don't know of any other redirect function, so this'll have to do.
		wp_redirect(admin_url('admin.php?page=st_addons_for_elementor_options'));
		// You could use a header(sprintf('Location: %s', admin_url(...)); here instead too.
	}

	/**
	 * Enqueue styles
	 * @access public
	 */

	public function enqueue_styles()
	{

		$direction_suffix = is_rtl() ? '.rtl' : '';
		// $suffix           = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style('stafe-admin', STAFE_ADMIN_ASSETS_URL . 'css/stafe-admin' . $direction_suffix . '.css', [], STAFE_VER);
		wp_enqueue_script('stafe-admin', STAFE_ASSETS_URL . 'js/stafe-admin.min.js', ['jquery'], STAFE_VER, true);
		wp_enqueue_style('stafe-editor', STAFE_ASSETS_URL . 'css/stafe-editor' . $direction_suffix . '.css', [], STAFE_VER);

		wp_enqueue_style('st-spectraafe', STAFE_ADMIN_ASSETS_URL . 'css/st-spectraafe' . $direction_suffix . '.css', [], '3.17.0');
		wp_enqueue_style('stafe-font', STAFE_ASSETS_URL . 'css/stafe-font' . $direction_suffix . '.css', [], STAFE_VER);

		wp_enqueue_script('st-spectraafe', STAFE_ADMIN_ASSETS_URL . 'js/st-spectraafe.min.js', ['jquery'], '3.17.0');
	}

	/**
	 * Row meta
	 * @access public
	 * @return array
	 */

	public function plugin_row_meta($plugin_meta, $plugin_file)
	{
		if (STAFE_PBNAME === $plugin_file) {
			$row_meta = [
				'docs'  => '<a href="https://spectrathemes.com/contact/" aria-label="' . esc_attr(__('Go for Get Support', 'st-addons-for-elementor')) . '" target="_blank">' . __('Get Support', 'st-addons-for-elementor') . '</a>',
				'video' => '<a href="https://www.youtube.com/playlist?list=PLP0S85GEw7DOJf_cbgUIL20qqwqb5x8KA" aria-label="' . esc_attr(__('View ST Addons For Elementor Video Tutorials', 'st-addons-for-elementor')) . '" target="_blank">' . __('Video Tutorials', 'st-addons-for-elementor') . '</a>',
			];

			$plugin_meta = array_merge($plugin_meta, $row_meta);
		}

		return $plugin_meta;
	}

	/**
	 * Action meta
	 * @access public
	 * @return array
	 */


	public function plugin_action_meta($links)
	{

		$links = array_merge([sprintf('<a href="%s">%s</a>', st_addons_for_elementor_dashboard_link('#st_addons_for_elementor_welcome'), esc_html__('Settings', 'st-addons-for-elementor'))], $links);

		$links = array_merge($links, [
			sprintf(
				'<a href="%s">%s</a>',
				st_addons_for_elementor_dashboard_link('#license'),
				esc_html__('License', 'st-addons-for-elementor')
			)
		]);

		return $links;
	}

	/**
	 * Change ST Addons For Elementor Name
	 * @access public
	 * @return string
	 */

	public function st_addons_for_elementor_name_change($translated_text, $text, $domain)
	{
		switch ($translated_text) {
			case 'ST Addons For Elementor Pro':
				$translated_text = STAFE_TITLE;
				break;
		}

		return $translated_text;
	}

	/**
	 * Hiding plugins //still in testing purpose
	 * @access public
	 */

	public function hide_st_addons_for_elementor()
	{
		global $wp_list_table;
		$hide_plg_array = array('st-addons-for-elementor/st-addons-for-elementor.php');
		$all_plugins    = $wp_list_table->items;

		foreach ($all_plugins as $key => $val) {
			if (in_array($key, $hide_plg_array)) {
				unset($wp_list_table->items[$key]);
			}
		}
	}

	/**
	 * Register admin script
	 * @access public
	 */

	public function enqueue_admin_script()
	{
		
		// $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-form');
		wp_enqueue_script('stafe-notice', STAFE_ADMIN_ASSETS_URL . 'js/stafe-notice.min.js', ['jquery'], STAFE_VER,  true);

		$script_config = [
			'ajaxurl'	=> admin_url('admin-ajax.php'),
			'nonce'		=> wp_create_nonce('st-addons-for-elementor'),
		];
		wp_localize_script('stafe-notice', 'StAddonsForElementorNoticeConfig', $script_config);

		if (isset($_GET['page']) && ($_GET['page'] == 'st_addons_for_elementor_options')) {
			wp_enqueue_script('chart', STAFE_ADMIN_ASSETS_URL . 'js/chart.min.js', ['jquery'], '4.4.1', true);
			wp_enqueue_script('stafe-admin', STAFE_ADMIN_ASSETS_URL  . 'js/stafe-admin.min.js', ['jquery', 'chart'], STAFE_VER, true);
		}else{
			wp_enqueue_script('stafe-admin', STAFE_ADMIN_ASSETS_URL  . 'js/stafe-admin.min.js', ['jquery'], STAFE_VER, true);
		}

	}
}
