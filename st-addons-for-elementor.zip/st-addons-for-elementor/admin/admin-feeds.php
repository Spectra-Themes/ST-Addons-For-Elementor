<?php

namespace STElementorAddon;

if (!defined('ABSPATH')) {
	exit;
} // Exit if accessed directly

/**
 * Admin_Feeds class
 */

class ST_Addons_For_ElementorAdmin_Feeds {

	public function __construct() {
		add_action('admin_enqueue_scripts', [$this, 'enqueue_product_feeds_styles']);
		add_action('wp_dashboard_setup', [$this, 'st_addons_for_elementor_register_rss_feeds']);
	}

	/**
	 * Enqueue Admin Style Files
	 */
	function enqueue_product_feeds_styles($hook) {
		if ('index.php' != $hook) {
			return;
		}
		$direction_suffix = is_rtl() ? '.rtl' : '';
		wp_enqueue_style('stafe-product-feed', STAFE_ADMIN_URL . 'assets/css/stafe-product-feed' . $direction_suffix . '.css', [], STAFE_VER);
	}


	/**
	 * ST Addons For Elementor Feeds Register
	 */

	public function st_addons_for_elementor_register_rss_feeds() {
		wp_add_dashboard_widget('st-stafe-dashboard-overview', esc_html__('ST Addons For Elementor News &amp; Updates', 'st-addons-for-elementor'), [
			$this,
			'st_addons_for_elementor_rss_feeds_content_data'
		], null, null, 'column4', 'core');
	}

	/**
	 * ST Addons For Elementor dashboard overview fetch content data
	 */
	public function st_addons_for_elementor_rss_feeds_content_data() {
		echo '<div class="st-stafe-dashboard-widget">';
		$feeds = array();
		$feeds = $this->st_addons_for_elementor_get_feeds_remote_data();
		if (is_array($feeds)) :
			foreach ($feeds as $key => $feed) {
				printf('<div class="st-product-feeds-content activity-block"><a href="%s" target="_blank"><img class="st-stafe-promo-image" src="%s"></a> <p>%s</p></div>', $feed->demo_link, $feed->image, $feed->content);
			}
		endif;
		echo $this->st_addons_for_elementor_get_feeds_posts_data();
	}

	/**
	 * ST Addons For Elementor dashboard overview fetch remote data
	 */
	public function st_addons_for_elementor_get_feeds_remote_data() {
		$source      = wp_remote_get('https://dashboard.spectrathemes.io/wp-json/spectrathemes/v1/product-feed/?product_category=st-addons-for-elementor');
		$reponse_raw = wp_remote_retrieve_body($source);
		$reponse     = json_decode($reponse_raw);

		return $reponse;
	}

	/**
	 * ST Addons For Elementor dashboard overview fetch posts data
	 */
	public function st_addons_for_elementor_get_feeds_posts_data() {
		// Get RSS Feed(s)
		include_once(ABSPATH . WPINC . '/feed.php');
		$rss = fetch_feed('https://spectrathemes.com/feed');
		if (!is_wp_error($rss)) {
			$maxitems  = $rss->get_item_quantity(5);
			$rss_items = $rss->get_items(0, $maxitems);
		} else {
			$maxitems = 0;
		}
		?>
		<!-- // Display the container -->
		<div class="st-stafe-overview__feed">
			<ul class="st-stafe-overview__posts">
				<?php
				// Check items
				if ($maxitems == 0) {
					echo '<li class="st-stafe-overview__post">' . esc_html__('No item', 'st-addons-for-elementor') . '.</li>';
				} else {
					foreach ($rss_items as $item) :
						$feed_url = $item->get_permalink();
						$feed_title = $item->get_title();
						$feed_date = human_time_diff($item->get_date('U'), current_time('timestamp')) . ' ' . esc_html__('ago', 'st-addons-for-elementor');
						$content = $item->get_content();
						$feed_content = wp_html_excerpt($content, 120) . ' [...]';
				?>
						<li class="st-stafe-overview__post">
							<?php printf('<a class="st-stafe-overview__post-link" href="%1$s" title="%2$s">%3$s</a>', $feed_url, $feed_date, $feed_title);
							printf('<span class="st-stafe-overview__post-date">%1$s</span>', $feed_date);
							printf('<p class="st-stafe-overview__post-description">%1$s</p>', $feed_content); ?>

						</li>
				<?php
					endforeach;
				}
				?>
			</ul>
			<div class="st-stafe-overview__footer st-stafe-divider_top">
				<ul>
					<?php
					$footer_link = [
						[
							'url'   => 'https://spectrathemes.com/blog/',
							'title' => esc_html__('Blog', 'st-addons-for-elementor'),
						],
						[
							'url'   => 'https://spectrathemes.com/knowledge-base/',
							'title' => esc_html__('Docs', 'st-addons-for-elementor'),
						],
						[
							'url'   => 'https://spectrathemes.com/pricing/',
							'title' => esc_html__('Get Pro', 'st-addons-for-elementor'),
						],
						[
							'url'   => 'https://spectrathemes.com/announcements/',
							'title' => esc_html__('Changelog', 'st-addons-for-elementor'),
						],
					];
					foreach ($footer_link as $key => $link) {
						printf('<li><a href="%1$s" target="_blank">%2$s<span aria-hidden="true" class="dashicons dashicons-external"></span></a></li>', esc_url($link['url']), esc_html($link['title']));
					}
					?>
				</ul>
			</div>
		</div>
		</div>
<?php
	}
}

new ST_Addons_For_ElementorAdmin_Feeds();
