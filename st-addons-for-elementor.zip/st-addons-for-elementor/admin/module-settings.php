<?php

namespace STElementorAddon\Admin;



if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

if (!function_exists('is_plugin_active')) {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

class ModuleService {

    public static function get_widget_settings($callable) {

        $settings_fields = [
            'st_addons_for_elementor_active_modules' => [
                [
                    'name'         => 'alex-grid',
                    'label'        => esc_html__('Alex Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'alex-carousel',
                    'label'        => esc_html__('Alex Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'alice-grid',
                    'label'        => esc_html__('Alice Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'alice-carousel',
                    'label'        => esc_html__('Alice Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'alter-grid',
                    'label'        => esc_html__('Alter Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'alter-carousel',
                    'label'        => esc_html__('Alter Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'amox-grid',
                    'label'        => esc_html__('Amox Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'amox-carousel',
                    'label'        => esc_html__('Amox Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'author',
                    'label'        => esc_html__('Author', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],

                [
                    'name'         => 'banner',
                    'label'        => esc_html__('Banner', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "off",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'buzz-list',
                    'label'        => esc_html__('Buzz List', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'list',
                ],
                [
                    'name'         => 'buzz-list-carousel',
                    'label'        => esc_html__('Buzz List Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'camux-slider',
                    'label'        => esc_html__('Camux Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'crystal-slider',
                    'label'        => esc_html__('Crystal Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'carbon-slider',
                    'label'        => esc_html__('Carbon Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'elite-grid',
                    'label'        => esc_html__('Elite Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'elite-carousel',
                    'label'        => esc_html__('Elite Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'exotic-list',
                    'label'        => esc_html__('Exotic List', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'list',
                ],
                [
                    'name'         => 'fanel-list',
                    'label'        => esc_html__('Fanel List', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'list',
                ],
                [
                    'name'         => 'featured-list',
                    'label'        => esc_html__('Featured List', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'list',
                ],
                [
                    'name'         => 'gratis-grid',
                    'label'        => esc_html__('Gratis Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "off",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'harold-list',
                    'label'        => esc_html__('Harold List', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'list',
                ],
                [
                    'name'         => 'harold-carousel',
                    'label'        => esc_html__('Harold List carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'hazel-grid',
                    'label'        => esc_html__('Hazel Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'hazel-carousel',
                    'label'        => esc_html__('Hazel Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'maple-grid',
                    'label'        => esc_html__('Maple Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                ],
                [
                    'name'         => 'maple-carousel',
                    'label'        => esc_html__('Maple Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'news-ticker',
                    'label'        => esc_html__('News Ticker', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'newsletter',
                    'label'        => esc_html__('Newsletter', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'noxe-slider',
                    'label'        => esc_html__('Noxe Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'timeline',
                    'label'        => esc_html__('Oras Timeline', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'timeline',
                ],
                [
                    'name'         => 'paradox-slider',
                    'label'        => esc_html__('Paradox Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'pholox-slider',
                    'label'        => esc_html__('Pholox Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'post-accordion',
                    'label'        => esc_html__('Accordion', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'post-category',
                    'label'        => esc_html__('Category', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'category-carousel',
                    'label'        => esc_html__('Category Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'ramble-grid',
                    'label'        => esc_html__('Ramble Grid', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'grid',
                ],
                [
                    'name'         => 'ramble-carousel',
                    'label'        => esc_html__('Ramble Carousel', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'carousel',
                ],
                [
                    'name'         => 'reading-progress',
                    'label'        => esc_html__('Reading Progress Bar', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'recent-comments',
                    'label'        => esc_html__('Recent Comments', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'scott-list',
                    'label'        => esc_html__('Scott List', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'list',
                ],
                [
                    'name'         => 'skide-slider',
                    'label'        => esc_html__('Skide Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'snog-slider',
                    'label'        => esc_html__('Snog Slider', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "off",
                    'widget_type'  => 'free',
                    'content_type' => 'slider',
                ],
                [
                    'name'         => 'static-social-count',
                    'label'        => esc_html__('Social Count(Static)', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'social-share',
                    'label'        => esc_html__('Social Share', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'tag-cloud',
                    'label'        => esc_html__('Tag Cloud', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'others',
                ],
                [
                    'name'         => 'tiny-list',
                    'label'        => esc_html__('Tiny List', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                    'content_type' => 'list',
                ]
            ],

            'st_addons_for_elementor_elementor_extend' => [
                [
                    'name'         => 'animations',
                    'label'        => esc_html__('Animations', 'st-addons-for-elementor'),
                    'type'         => 'checkbox',
                    'default'      => "on",
                    'widget_type'  => 'free',
                ]
            ],
            'st_addons_for_elementor_api_settings'     => [
                [
                    'name'  => 'mailchimp_group_start',
                    'label' => esc_html__('Mailchimp Access', 'st-addons-for-elementor'),
                    'desc'  => __('Go to your Mailchimp > Website > Domains > Extras > API Keys (<a href="http://prntscr.com/xqo78x" target="_blank">http://prntscr.com/xqo78x</a>) then create a key and paste here. You will get the audience ID here: <a href="http://prntscr.com/xqnt5z" target="_blank">http://prntscr.com/xqnt5z</a>', 'st-addons-for-elementor'),
                    'type'  => 'start_group',

                ],
                [
                    'name'              => 'mailchimp_api_key',
                    'label'             => esc_html__('Mailchimp API Key', 'st-addons-for-elementor'),
                    'placeholder'       => '',
                    'type'              => 'text',
                    'sanitize_callback' => 'sanitize_text_field'

                ],
                [
                    'name'              => 'mailchimp_list_id',
                    'label'             => esc_html__('Audience ID', 'st-addons-for-elementor'),
                    'placeholder'       => '',
                    'type'              => 'text',
                    'sanitize_callback' => 'sanitize_text_field'

                ],
                [
                    'name' => 'mailchimp_group_end',
                    'type' => 'end_group',
                ],


                [
                    'name'      => 'instagram_group_start',
                    'label'     => esc_html__('Instagram Access', 'st-addons-for-elementor'),
                    'desc'      => __('Go to <a href="https://developers.facebook.com/docs/instagram-basic-display-api/getting-started" target="_blank">https://developers.facebook.com/docs/instagram-basic-display-api/getting-started</a> for create your Consumer key and Access Token.', 'st-addons-for-elementor'),
                    'type'      => 'start_group',
                ],

                [
                    'name'              => 'instagram_app_id',
                    'label'             => esc_html__('Instagram App ID', 'st-addons-for-elementor'),
                    'placeholder'       => '---------------',
                    'type'              => 'text',
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                [
                    'name'              => 'instagram_app_secret',
                    'label'             => esc_html__('Instagram App Secret', 'st-addons-for-elementor'),
                    'placeholder'       => '---------------',
                    'type'              => 'text',
                    'sanitize_callback' => 'sanitize_text_field'
                ],

                [
                    'name'              => 'instagram_access_token',
                    'label'             => esc_html__('Instagram Access Token', 'st-addons-for-elementor'),
                    'desc'              => __('Go to <a href="https://developers.facebook.com/docs/instagram-basic-display-api/getting-started" target="_blank">This Link</a> and Generate the access token then copy and paste here.', 'st-addons-for-elementor'),
                    'placeholder'       => '---------------',
                    'type'              => 'text',
                    'sanitize_callback' => 'sanitize_text_field'
                ],

                [
                    'name' => 'instagram_group_end',
                    'type' => 'end_group',
                ],

            ],
            'st_addons_for_elementor_other_settings'   => [

                [
                    'name'  => 'enable_category_image_group_start',
                    'label' => esc_html__('Category Image', 'st-addons-for-elementor'),
                    'desc'  => __('Display exclusive category avatar by turning on this switcher. The Category image will be visible for all post widgets if the category is turned on from the widget controls.', 'st-addons-for-elementor'),
                    'type'  => 'start_group',
                    // 'content_type' => 'new',
                ],

                [
                    'name'    => 'category_image',
                    'label'   => esc_html__('Category Image', 'st-addons-for-elementor'),
                    'type'    => 'checkbox',
                    'default' => "off",
                    'widget_type' => 'free',
                ],

                [
                    'name' => 'category_image_group_end',
                    'type' => 'end_group',
                ],

                [
                    'name'         => 'duplicator_group_start',
                    'label'        => esc_html__('Duplicator', 'st-addons-for-elementor'),
                    'desc'         => __('Just hit the button below to enable the duplicator. It can duplicate anything like posts,pages and elementor templates. A masterclass duplication with just one click.', 'st-addons-for-elementor'),
                    'type'         => 'start_group',
                    // 'content_type' => 'new',
                ],

                [
                    'name'        => 'duplicator',
                    'label'       => esc_html__('Duplicator', 'st-addons-for-elementor'),
                    'type'        => 'checkbox',
                    'default'     => 'off',
                    'widget_type' => 'free',
                ],

                [
                    'name' => 'duplicator_group_end',
                    'type' => 'end_group',
                ],

                [
                    'name'  => 'live_copy_group_start',
                    'label' => esc_html__('Live Copy or Paste', 'st-addons-for-elementor'),
                    'desc'  => __('Live copy is a copy feature that allow you to copy and paste content from one domain to another. For example you can copy demo content directly from our demo website.', 'st-addons-for-elementor'),
                    'type'  => 'start_group',
                    // 'content_type' => 'new',
                ],

                [
                    'name'      => 'live-copy',
                    'label'     => esc_html__('Live Copy/Paste', 'st-addons-for-elementor'),
                    'type'      => 'checkbox',
                    'default'   => 'off',
                    'widget_type' => 'free',
                    'demo_url'  => 'https://spectrathemes.com/knowledge-base/how-to-use-live-copy-option/',

                ],

                [
                    'name' => 'live_copy_group_end',
                    'type' => 'end_group',
                ],
                [
                    'name'  => 'enable_audio_link_group_start',
                    'label' => esc_html__('Audio Link Meta', 'st-addons-for-elementor'),
                    'desc'  => __('If you need to display Audio features in your website so please enable this option.', 'st-addons-for-elementor'),
                    'type'  => 'start_group',
                    'content_type' => 'new',
                ],

                [
                    'name'    => 'audio_link',
                    'label'   => esc_html__('Audio Link', 'st-addons-for-elementor'),
                    'type'    => 'checkbox',
                    'default' => "off",
                    'widget_type' => 'free',
                ],

                [
                    'name' => 'audio_link_group_end',
                    'type' => 'end_group',
                ],
                [
                    'name'  => 'enable_video_link_group_start',
                    'label' => esc_html__('Video Link Meta', 'st-addons-for-elementor'),
                    'desc'  => __('If you need to display video features in your website so please enable this option.', 'st-addons-for-elementor'),
                    'type'  => 'start_group',
                    // 'content_type' => 'new',
                ],

                [
                    'name'    => 'video_link',
                    'label'   => esc_html__('Video Link', 'st-addons-for-elementor'),
                    'type'    => 'checkbox',
                    'default' => "off",
                    'widget_type' => 'free',
                ],

                [
                    'name' => 'video_link_group_end',
                    'type' => 'end_group',
                ],
            ]
        ];

        $settings                    = [];
        $settings['settings_fields'] = $settings_fields;

        return $callable($settings);
    }

    private static function _is_plugin_installed($plugin, $plugin_path) {
        $installed_plugins = get_plugins();
        return isset($installed_plugins[$plugin_path]);
    }

    public static function is_module_active($module_id, $options, $module_path = STAFE_MODULES_PATH) {
        if (!isset($options[$module_id])) {
            if (file_exists($module_path . $module_id . '/module.info.php')) {
                $module_data = require $module_path . $module_id . '/module.info.php';
                return $module_data['default_activation'];
            }
        } else {
            return $options[$module_id] == 'on';
        }
    }

    public static function is_plugin_active($plugin_path) {
        if ($plugin_path) {
            return is_plugin_active($plugin_path);
        }
    }

    public static function has_module_style($module_id, $module_path = STAFE_MODULES_PATH) {
        if (file_exists($module_path . $module_id . '/module.info.php')) {
            $module_data = require $module_path . $module_id . '/module.info.php';

            if (isset($module_data['has_style'])) {
                return $module_data['has_style'];
            }
        }
    }

    public static function has_module_script($module_id, $module_path = STAFE_MODULES_PATH) {
        if (file_exists($module_path . $module_id . '/module.info.php')) {
            $module_data = require $module_path . $module_id . '/module.info.php';

            if (isset($module_data['has_script'])) {
                return $module_data['has_script'];
            }
        }
    }
}
