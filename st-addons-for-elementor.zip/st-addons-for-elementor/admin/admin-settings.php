<?php

use STElementorAddon\Notices;
use STElementorAddon\Utils;
use STElementorAddon\Admin\ModuleService;
use Elementor\Modules\Usage\Module;
use Elementor\Tracker;

/**
 * ST Addons For Elementor Admin Settings Class
 */

class StAddonsForElementor_Admin_Settings {

    public static $modules_list  = null;
    public static $modules_names = null;

    public static $modules_list_only_widgets  = null;
    public static $modules_names_only_widgets = null;

    public static $modules_list_only_3rdparty  = null;
    public static $modules_names_only_3rdparty = null;

    const PAGE_ID = 'st_addons_for_elementor_options';

    private $settings_api;

    public  $responseObj;
    public  $licenseMessage;
    public  $showMessage  = false;
    private $is_activated = false;

    function __construct() {
        $this->settings_api = new StAddonsForElementor_Settings_API;

        if (!defined('STAFE_HIDE')) {
            add_action('admin_init', [$this, 'admin_init']);
            add_action('admin_menu', [$this, 'admin_menu'], 201);
            add_action('admin_enqueue_scripts', [$this, 'load_media_files']);
        }

        /**
         * Mini-Cart issue fixed
         * Check if MiniCart activate in EP and Elementor
         * If both is activated then Show Notice
         */

        $stafe_3rdPartyOption = get_option('st_addons_for_elementor_third_party_widget');

        $el_use_mini_cart = get_option('elementor_use_mini_cart_template');

        if ($el_use_mini_cart !== false && $stafe_3rdPartyOption !== false) {
            if ($stafe_3rdPartyOption) {
                if ('yes' == $el_use_mini_cart && isset($stafe_3rdPartyOption['wc-mini-cart']) && 'off' !== trim($stafe_3rdPartyOption['wc-mini-cart'])) {
                    add_action('admin_notices', [$this, 'el_use_mini_cart'], 10, 3);
                }
            }
        }
    }

    /**
     * Get used widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */
    public static function get_used_widgets() {

        $used_widgets = array();

        if (class_exists('Elementor\Modules\Usage\Module')) {

            $module     = Module::instance();
            $elements   = $module->get_formatted_usage('raw');
            $stafe_widgets = self::get_stafe_widgets_names();

            if (is_array($elements) || is_object($elements)) {

                foreach ($elements as $post_type => $data) {
                    foreach ($data['elements'] as $element => $count) {
                        if (in_array($element, $stafe_widgets, true)) {
                            if (isset($used_widgets[$element])) {
                                $used_widgets[$element] += $count;
                            } else {
                                $used_widgets[$element] = $count;
                            }
                        }
                    }
                }
            }
        }

        return $used_widgets;
    }

    /**
     * Get used separate widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_used_only_widgets() {

        $used_widgets = array();

        if (class_exists('Elementor\Modules\Usage\Module')) {

            $module     = Module::instance();
            $elements   = $module->get_formatted_usage('raw');
            $stafe_widgets = self::get_stafe_only_widgets();

            if (is_array($elements) || is_object($elements)) {

                foreach ($elements as $post_type => $data) {
                    foreach ($data['elements'] as $element => $count) {
                        if (in_array($element, $stafe_widgets, true)) {
                            if (isset($used_widgets[$element])) {
                                $used_widgets[$element] += $count;
                            } else {
                                $used_widgets[$element] = $count;
                            }
                        }
                    }
                }
            }
        }

        return $used_widgets;
    }

    /**
     * Get used only separate 3rdParty widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_used_only_3rdparty() {

        $used_widgets = array();

        if (class_exists('Elementor\Modules\Usage\Module')) {

            $module     = Module::instance();
            $elements   = $module->get_formatted_usage('raw');
            $stafe_widgets = self::get_stafe_only_3rdparty_names();

            if (is_array($elements) || is_object($elements)) {

                foreach ($elements as $post_type => $data) {
                    foreach ($data['elements'] as $element => $count) {
                        if (in_array($element, $stafe_widgets, true)) {
                            if (isset($used_widgets[$element])) {
                                $used_widgets[$element] += $count;
                            } else {
                                $used_widgets[$element] = $count;
                            }
                        }
                    }
                }
            }
        }

        return $used_widgets;
    }

    /**
     * Get unused widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_unused_widgets() {

        if (!current_user_can('install_plugins')) {
            die();
        }

        $stafe_widgets = self::get_stafe_widgets_names();

        $used_widgets = self::get_used_widgets();

        $unused_widgets = array_diff($stafe_widgets, array_keys($used_widgets));

        return $unused_widgets;
    }

    /**
     * Get unused separate widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_unused_only_widgets() {

        if (!current_user_can('install_plugins')) {
            die();
        }

        $stafe_widgets = self::get_stafe_only_widgets();

        $used_widgets = self::get_used_only_widgets();

        $unused_widgets = array_diff($stafe_widgets, array_keys($used_widgets));

        return $unused_widgets;
    }

    /**
     * Get unused separate 3rdparty widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_unused_only_3rdparty() {

        if (!current_user_can('install_plugins')) {
            die();
        }

        $stafe_widgets = self::get_stafe_only_3rdparty_names();

        $used_widgets = self::get_used_only_3rdparty();

        $unused_widgets = array_diff($stafe_widgets, array_keys($used_widgets));

        return $unused_widgets;
    }

    /**
     * Get widgets name
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_stafe_widgets_names() {
        $names = self::$modules_names;

        if (null === $names) {
            $names = array_map(
                function ($item) {
                    return isset($item['name']) ? 'stafe-' . str_replace('_', '-', $item['name']) : 'none';
                },
                self::$modules_list
            );
        }

        return $names;
    }

    /**
     * Get separate widgets name
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_stafe_only_widgets() {
        $names = self::$modules_names_only_widgets;

        if (null === $names) {
            $names = array_map(
                function ($item) {
                    return isset($item['name']) ? 'stafe-' . str_replace('_', '-', $item['name']) : 'none';
                },
                self::$modules_list_only_widgets
            );
        }

        return $names;
    }

    /**
     * Get separate 3rdParty widgets name
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_stafe_only_3rdparty_names() {
        $names = self::$modules_names_only_3rdparty;

        if (null === $names) {
            $names = array_map(
                function ($item) {
                    return isset($item['name']) ? 'stafe-' . str_replace('_', '-', $item['name']) : 'none';
                },
                self::$modules_list_only_3rdparty
            );
        }

        return $names;
    }

    /**
     * Get URL with page id
     *
     * @access public
     *
     */

    public static function get_url() {
        return admin_url('admin.php?page=' . self::PAGE_ID);
    }

    /**
     * Init settings API
     *
     * @access public
     *
     */

    public function admin_init() {

        //set the settings
        $this->settings_api->set_sections($this->get_settings_sections());
        $this->settings_api->set_fields($this->st_addons_for_elementor_admin_settings());

        //initialize settings
        $this->settings_api->admin_init();
    }

    public function load_media_files($hook) {

        if ($hook == 'toplevel_page_st_addons_for_elementor_options') {
            wp_enqueue_script(
                'stafe-admin-settings-script', 
                STAFE_ASSETS_URL . 'js/admin-settings.js', 
                ['jquery'], 
                STAFE_VER, 
                true
            );
        }
    }

    /**
     * Add Plugin Menus
     *
     * @access public
     *
     */

    public function admin_menu() {
        add_menu_page(
            STAFE_TITLE . ' ' . esc_html__('Dashboard', 'st-addons-for-elementor'),
            STAFE_SHORT_TITLE,
            'manage_options',
            self::PAGE_ID,
            [$this, 'plugin_page'],
            $this->st_addons_for_elementor_icon(),
            58
        );

        add_submenu_page(
            self::PAGE_ID,
            STAFE_TITLE,
            esc_html__('Core Widgets', 'st-addons-for-elementor'),
            'manage_options',
            self::PAGE_ID . '#st_addons_for_elementor_active_modules',
            [$this, 'display_page']
        );

        add_submenu_page(
            self::PAGE_ID,
            STAFE_TITLE,
            esc_html__('Extensions', 'st-addons-for-elementor'),
            'manage_options',
            self::PAGE_ID . '#st_addons_for_elementor_elementor_extend',
            [$this, 'display_page']
        );

        add_submenu_page(
            self::PAGE_ID,
            STAFE_TITLE,
            esc_html__('API Settings', 'st-addons-for-elementor'),
            'manage_options',
            self::PAGE_ID . '#st_addons_for_elementor_api_settings',
            [$this, 'display_page']
        );

        if (!defined('STAFE_LO')) {

            add_submenu_page(
                self::PAGE_ID,
                STAFE_TITLE,
                esc_html__('Other Settings', 'st-addons-for-elementor'),
                'manage_options',
                self::PAGE_ID . '#st_addons_for_elementor_other_settings',
                [$this, 'display_page']
            );
        }

        if (true !== _is_stafe_pro_activated()) {
            add_submenu_page(
                self::PAGE_ID,
                STAFE_TITLE,
                esc_html__('Get Pro', 'st-addons-for-elementor'),
                'manage_options',
                self::PAGE_ID . '#st_addons_for_elementor_get_pro',
                [$this, 'display_page']
            );
        }
    }

    /**
     * Get SVG Icons of ST Addons For Elementor
     *
     * @access public
     * @return string
     */

    public function st_addons_for_elementor_icon() {
        return 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAyNC4wLjAsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiDQoJIHZpZXdCb3g9IjAgMCA5MDkuMyA4ODMuOCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgOTA5LjMgODgzLjg7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+DQoJLnN0MHtmaWxsOiNBN0FBQUQ7fQ0KPC9zdHlsZT4NCjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik04MTEuMiwyNzIuOUg2ODEuNnYxMjkuN2MwLDEzLjYtMTEsMjQuNy0yNC43LDI0LjdoLTEwNWMtMTMuNiwwLTI0LjctMTEtMjQuNy0yNC43YzAsMCwwLDAsMCwwdi0xMDUNCgljMC0xMy42LDExLTI0LjcsMjQuNi0yNC43YzAsMCwwLDAsMCwwaDEyOS43VjE0My4zYzAtMTMuNi0xMS0yNC43LTI0LjctMjQuN0gzOTcuNmMtMTMuNiwwLTI0LjcsMTEtMjQuNywyNC43YzAsMCwwLDAsMCwwdjQ3MS41DQoJYzAsMTMuNi0xMSwyNC42LTI0LjYsMjQuN2MwLDAsMCwwLDAsMGgtMTA1Yy0xMy42LDAtMjQuNy0xMS0yNC43LTI0Ljd2LTM3NWMwLTEzLjYtMTEtMjQuNy0yNC43LTI0LjdIODljLTEzLjYsMC0yNC43LDExLTI0LjcsMjQuNw0KCWMwLDAsMCwwLDAsMHY1MjkuNGMwLDEzLjYsMTEsMjQuNywyNC43LDI0LjdoNDEzLjZjMTMuNiwwLDI0LjctMTEuMSwyNC43LTI0LjdWNjA2LjJjMC0xMy42LDExLTI0LjcsMjQuNy0yNC43aDI1OS4zDQoJYzEzLjYsMCwyNC43LTExLDI0LjctMjQuN1YyOTcuNkM4MzUuOSwyODQsODI0LjksMjczLDgxMS4yLDI3Mi45QzgxMS4yLDI3Mi45LDgxMS4yLDI3Mi45LDgxMS4yLDI3Mi45eiIvPg0KPHJlY3QgeD0iNzMyIiB5PSI4Mi42IiBjbGFzcz0ic3QwIiB3aWR0aD0iMzQuOCIgaGVpZ2h0PSIzNC44Ii8+DQo8cmVjdCB4PSI3OTEiIHk9IjE0OS43IiBjbGFzcz0ic3QwIiB3aWR0aD0iMjMuOSIgaGVpZ2h0PSIyMy45Ii8+DQo8cmVjdCB4PSI4MDMiIHk9IjgyLjYiIGNsYXNzPSJzdDAiIHdpZHRoPSIxNy44IiBoZWlnaHQ9IjE3LjgiLz4NCjxyZWN0IHg9Ijg2Ni43IiB5PSIxNTUuOCIgY2xhc3M9InN0MCIgd2lkdGg9IjE3LjgiIGhlaWdodD0iMTcuOCIvPg0KPHJlY3QgeD0iODI4LjkiIHk9IjQ0LjMiIGNsYXNzPSJzdDAiIHdpZHRoPSI4LjkiIGhlaWdodD0iOC45Ii8+DQo8cmVjdCB4PSI4NzcuNCIgeT0iMzgiIGNsYXNzPSJzdDAiIHdpZHRoPSI3LjIiIGhlaWdodD0iNy4yIi8+DQo8cmVjdCB4PSI4NTIuNiIgeT0iODciIGNsYXNzPSJzdDAiIHdpZHRoPSI4LjkiIGhlaWdodD0iOC45Ii8+DQo8cmVjdCB4PSI3MzUuNCIgeT0iMTgyLjgiIGNsYXNzPSJzdDAiIHdpZHRoPSIxOS43IiBoZWlnaHQ9IjE5LjciLz4NCjxyZWN0IHg9IjgyNi4zIiB5PSIyMDQuNiIgY2xhc3M9InN0MCIgd2lkdGg9IjE0LjEiIGhlaWdodD0iMTQuMSIvPg0KPC9zdmc+DQo=';
    }

    /**
     * Get SVG Icons of ST Addons For Elementor
     *
     * @access public
     * @return array
     */

    public function get_settings_sections() {
        $sections = [
            [
                'id'    => 'st_addons_for_elementor_active_modules',
                'title' => esc_html__('Core Widgets', 'st-addons-for-elementor')
            ],
            [
                'id'    => 'st_addons_for_elementor_elementor_extend',
                'title' => esc_html__('Extensions', 'st-addons-for-elementor')
            ],
            [
                'id'    => 'st_addons_for_elementor_api_settings',
                'title' => esc_html__('API Settings', 'st-addons-for-elementor'),
            ],
            [
                'id'    => 'st_addons_for_elementor_other_settings',
                'title' => esc_html__('Other Settings', 'st-addons-for-elementor'),
            ],
        ];

        return $sections;
    }

    /**
     * Merge Admin Settings
     *
     * @access protected
     * @return array
     */

    protected function st_addons_for_elementor_admin_settings() {

        return ModuleService::get_widget_settings(function ($settings) {
            $settings_fields    = $settings['settings_fields'];

            self::$modules_list = $settings_fields['st_addons_for_elementor_active_modules'];
            self::$modules_list_only_widgets  = $settings_fields['st_addons_for_elementor_active_modules'];

            return $settings_fields;
        });
    }

    /**
     * Get Welcome Panel
     *
     * @access public
     * @return void
     */

    public function st_addons_for_elementor_welcome() {
        $track_nw_msg = '';
        if (!Tracker::is_allow_track()) {
            $track_nw = esc_html__('This feature is not working because the Elementor Usage Data Sharing feature is Not Enabled.', 'st-addons-for-elementor');
            $track_nw_msg = 'st-tooltip="' . $track_nw . '"';
        }
?>

        <div class="stafe-dashboard-panel" st-scrollspy="target: > div > div > .st-card; cls: st-animation-slide-bottom-small; delay: 300">

            <div class="st-grid" st-grid st-height-match="target: > div > .st-card">
                <div class="st-width-1-2@m st-width-1-4@l">
                    <div class="stafe-widget-status st-card st-card-body" <?php echo wp_kses_post($track_nw_msg); ?>>

                        <?php
                        $used_widgets    = count(self::get_used_widgets());
                        $un_used_widgets = count(self::get_unused_widgets());
                        ?>


                        <div class="stafe-count-canvas-wrap st-flex st-flex-between">
                            <div class="stafe-count-wrap">
                                <h1 class="stafe-feature-title">
                                    <?php echo esc_html_x('All Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                </h1>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Used:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b><?php echo esc_html($used_widgets); ?></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Unused:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b><?php echo esc_html($un_used_widgets); ?></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Total:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b><?php echo esc_html($used_widgets) + esc_html($un_used_widgets); ?></b>
                                </div>
                            </div>

                            <div class="stafe-canvas-wrap">
                                <canvas id="st-db-total-status" style="height: 120px; width: 120px;" data-label="Total Widgets Status - (<?php echo esc_attr($used_widgets) + esc_attr($un_used_widgets); ?>)" data-labels="<?php echo esc_attr('Used, Unused'); ?>" data-value="<?php echo esc_attr($used_widgets) . ',' . esc_attr($un_used_widgets); ?>" data-bg="#FFD166, #fff4d9" data-bg-hover="#0673e1, #e71522"></canvas>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="st-width-1-2@m st-width-1-4@l">
                    <div class="stafe-widget-status st-card st-card-body" <?php echo wp_kses_post($track_nw_msg); ?>>

                        <div class="stafe-count-canvas-wrap st-flex st-flex-between">
                            <div class="stafe-count-wrap">
                                <h1 class="stafe-feature-title">
                                    <?php echo esc_html_x('Active', 'Frontend', 'st-addons-for-elementor'); ?>
                                </h1>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Core:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b id="st-total-widgets-status-core"></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Extensions:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b id="st-total-widgets-status-extensions"></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Total:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b id="st-total-widgets-status-heading"></b>
                                </div>
                            </div>

                            <div class="stafe-canvas-wrap">
                                <canvas id="st-total-widgets-status" style="height: 120px; width: 120px;" data-label="Total Active Widgets Status" data-labels="<?php echo esc_attr('Core, Extensions'); ?>" data-bg="#0680d6, #E6F9FF" data-bg-hover="#0673e1, #b6f9e8">
                                </canvas>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <?php if (!Tracker::is_allow_track()) : ?>
                <div class="st-border-rounded st-box-shadow-small st-alert-warning" st-alert>
                    <a href class="st-alert-close" st-close></a>
                    <div class="st-text-default">
                        <?php
                        esc_html_e('To view widgets analytics, Elementor Usage Data Sharing feature by Elementor needs to be activated. Please activate the feature to get widget analytics instantly ', 'st-addons-for-elementor');
                        echo '<a href="' . esc_url(admin_url('admin.php?page=elementor')) . '">from here.</a>';
                        ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="st-grid" st-grid st-height-match="target: > div > .st-card">

                <div class="st-width-1-1@m">
                    <div class="st-card st-card-body stafe-system-requirement">
                        <h1 class="stafe-feature-title st-margin-small-bottom">
                            <?php echo esc_html_x('System Requirement', 'Frontend', 'st-addons-for-elementor'); ?>
                        </h1>
                        <?php $this->st_addons_for_elementor_system_requirement(); ?>
                    </div>
                </div>
            </div>

        </div>


    <?php
    }

    /**
     * Get Pro
     *
     * @access public
     * @return void
     */

    function st_addons_for_elementor_get_pro() {
    ?>
        <div class="stafe-dashboard-panel" st-scrollspy="target: > div > div > .st-card; cls: st-animation-slide-bottom-small; delay: 300">

            <div class="st-grid" st-grid st-height-match="target: > div > .st-card" style="max-width: 800px; margin-left: auto; margin-right: auto;">
                <div class="st-width-1-1@m stafe-comparision st-text-center">
                    <h1 class="st-text-bold">
                        <?php echo esc_html_x('WHY GO WITH PRO?', 'Frontend', 'st-addons-for-elementor'); ?>
                    </h1>
                    <h2>
                        <?php echo esc_html_x('Just Compare With ST Addons For Elementor Free Vs Pro', 'Frontend', 'st-addons-for-elementor'); ?>
                    </h2>


                    <div>

                        <ul class="st-list st-list-divider st-text-left st-text-normal" style="font-size: 16px;">


                            <li class="st-text-bold">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Features', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m">
                                        <?php echo esc_html_x('Free', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m">
                                        <?php echo esc_html_x('Pro', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m"><span st-tooltip="pos: top-left; title: Lite have 35+ Widgets but Pro have 100+ core widgets">
                                            <?php echo esc_html_x('Core Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Theme Compatibility', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Dynamic Content & Custom Fields Capabilities', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Proper Documentation', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Updates & Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Rooten Theme Pro Features', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-no"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Priority Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-no"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Ready Made Pages', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Ready Made Blocks', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Elementor Extended Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Live Copy or Paste', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Duplicator', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Video Link Meta', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Category Image', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>

                        </ul>


                        <div class="stafe-dashboard-divider"></div>


                        <div class="stafe-more-features">
                            <ul class="st-list st-list-divider st-text-left" style="font-size: 16px;">
                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Incredibly Advanced', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Refund or Cancel Anytime', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Dynamic Content', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Super-Flexible Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('24/7 Premium Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Third Party Plugins', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Special Discount!', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Custom Field Integration', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('With Live Chat Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Trusted Payment Methods', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Interactive Effects', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Video Tutorial', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>
                            </ul>

                            <!-- <div class="stafe-dashboard-divider"></div> -->

                            <?php if (true !== _is_stafe_pro_activated()) : ?>
                                <div class="stafe-purchase-button">
                                    <a href="https://spectrathemes.com/" target="_blank">
                                        <?php echo esc_html_x('Purchase Now', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>

        </div>
    <?php
    }

    /**
     * Display System Requirement
     *
     * @access public
     * @return void
     */

    function st_addons_for_elementor_system_requirement() {
        $php_version        = phpversion();
        $max_execution_time = ini_get('max_execution_time');
        $memory_limit       = ini_get('memory_limit');
        $post_limit         = ini_get('post_max_size');
        $uploads            = wp_upload_dir();
        $upload_path        = $uploads['basedir'];
        $yes_icon           = wp_kses_post('<span class="valid"><i class="dashicons-before dashicons-yes"></i></span>');
        $no_icon            = wp_kses_post('<span class="invalid"><i class="dashicons-before dashicons-no-alt"></i></span>');

        $environment = Utils::get_environment_info();


    ?>
        <ul class="check-system-status st-grid st-child-width-1-2@m st-grid-small ">
            <li>
                <div>

                    <span class="label1">
                        <?php echo esc_html_x('PHP Version: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if (version_compare($php_version, '7.0.0', '<')) {
                        echo wp_kses_post($no_icon);
                        echo '<span class="label2" title="Min: 7.0 Recommended" st-tooltip>Currently: ' . esc_html($php_version) . '</span>';
                    } else {
                        echo wp_kses_post($yes_icon);
                        echo '<span class="label2">Currently: ' . esc_html($php_version) . '</span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Max execution time: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if ($max_execution_time < '90') {
                        echo wp_kses_post($no_icon);
                        echo '<span class="label2" title="Min: 90 Recommended" st-tooltip>Currently: ' . esc_html($max_execution_time) . '</span>';
                    } else {
                        echo wp_kses_post($yes_icon);
                        echo '<span class="label2">Currently: ' . esc_html($max_execution_time) . '</span>';
                    }
                    ?>
                </div>
            </li>
            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Memory Limit: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if (intval($memory_limit) < '812') {
                        echo wp_kses_post($no_icon);
                        echo '<span class="label2" title="Min: 812M Recommended" st-tooltip>Currently: ' . esc_html($memory_limit) . '</span>';
                    } else {
                        echo wp_kses_post($yes_icon);
                        echo '<span class="label2">Currently: ' . esc_html($memory_limit) . '</span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Max Post Limit: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if (intval($post_limit) < '32') {
                        echo wp_kses_post($no_icon);
                        echo '<span class="label2" title="Min: 32M Recommended" st-tooltip>Currently: ' . esc_html($post_limit) . '</span>';
                    } else {
                        echo wp_kses_post($yes_icon);
                        echo '<span class="label2">Currently: ' . esc_html($post_limit) . '</span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Uploads folder writable: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php

                        if ( ! function_exists('WP_Filesystem') ) {
                            require_once( ABSPATH . 'wp-admin/includes/file.php' );
                        }

                        if ( ! WP_Filesystem() ) {
                            return;
                        }

                        WP_Filesystem();
                        
                        global $wp_filesystem;            

                        if ( !$wp_filesystem->is_writable($upload_path) ) {
                            echo wp_kses_post($no_icon);
                        } else {
                            echo wp_kses_post($yes_icon);
                        }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('MultiSite: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if ($environment['wp_multisite']) {
                        echo wp_kses_post($yes_icon);
                        echo '<span class="label2">MultiSite</span>';
                    } else {
                        echo wp_kses_post($yes_icon);
                        echo '<span class="label2">No MultiSite </span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('GZip Enabled: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if ($environment['gzip_enabled']) {
                        echo wp_kses_post($yes_icon);
                    } else {
                        echo wp_kses_post($no_icon);
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Debug Mode: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>
                    <?php
                    if ($environment['wp_debug_mode']) {
                        echo wp_kses_post($no_icon);
                        echo '<span class="label2">Currently Turned On</span>';
                    } else {
                        echo wp_kses_post($yes_icon);
                        echo '<span class="label2">Currently Turned Off</span>';
                    }
                    ?>
                </div>
            </li>

        </ul>

        <div class="st-admin-alert">
            <?php
            printf(
                // Translators: %1$s is a note, %2$s is the name of the addon.
                esc_html__('%1$s If you have multiple addons like %2$s so you need some more requirement some cases so make sure you added more memory for others addon too.', 'st-addons-for-elementor'),
                '<strong>Note:</strong>',
                '<b>ST Addons For Elementor</b>'
            ); ?>
        </div>
    <?php
    }

    /**
     * Display Plugin Page
     *
     * @access public
     * @return void
     */

    function plugin_page() {

        echo '<div class="wrap st-addons-for-elementor-dashboard">';
        echo '<h1>' . esc_html(STAFE_TITLE) . ' Settings</h1>';

        $this->settings_api->show_navigation();

    ?>


        <div class="st-switcher st-tab-container st-container-xlarge">
            <div id="st_addons_for_elementor_welcome_page" class="stafe-option-page group">
                <?php $this->st_addons_for_elementor_welcome(); ?>

                <?php if (!defined('STAFE_WL')) {
                    $this->footer_info();
                } ?>
            </div>

            <?php
            $this->settings_api->show_forms();
            ?>

            <?php if (_is_stafe_pro_activated() !== true) : ?>
                <div id="st_addons_for_elementor_get_pro" class="stafe-option-page group">
                    <?php $this->st_addons_for_elementor_get_pro(); ?>
                </div>
            <?php endif; ?>

            <div id="st_addons_for_elementor_license_settings_page" class="stafe-option-page group">

                <?php
                if (_is_stafe_pro_activated() == true) {
                    apply_filters('stafe_license_page', '');
                }

                ?>

                <?php if (!defined('STAFE_WL')) {
                    $this->footer_info();
                } ?>
            </div>
        </div>

        </div>

    <?php
    }

    /**
     * Display Footer
     *
     * @access public
     * @return void
     */

    function footer_info() {
    ?>

        <div class="st-addons-for-elementor-footer-info st-margin-medium-top">

            <div class="st-grid ">

                <div class="st-width-auto@s stafe-setting-save-btn">



                </div>

                <div class="st-width-expand@s st-text-right">
                    <p class="">
                        All rights reserved by <a target="_blank" href="https://spectrathemes.com/">SpectraThemes.com</a>.
                    </p>
                </div>
            </div>

        </div>

<?php
    }

    /**
     * v6 Notice
     * This notice is very important to show minimum 3 to 5 next update released version.
     *
     * @access public
     */

    public function v6_activate_notice() {

        Notices::add_notice(
            [
                'id'               => 'version-6',
                'type'             => 'warning',
                'dismissible'      => true,
                'dismissible-time' => 43200,
                'message'          => __('There are very important changes in our major version <strong>v6.0.0</strong>. If you are continuing with the ST Addons For Elementor plugin from an earlier version of v6.0.0 then you must read this article carefully <a href="https://spectrathemes.com/knowledge-base/read-before-upgrading-to-st-addons-for-elementor-pro-version-6-0" target="_blank">from here</a>. <br> And if you are using this plugin from v6.0.0 there is nothing to worry about you. Thank you.', 'st-addons-for-elementor'),
            ]
        );
    }
    /**
     * 
     * Check mini-Cart of Elementor Activated or Not
     * It's better to not use multiple mini-Cart on the same time.
     * Transient Expire on 15 days
     *
     * @access public
     */

    public function el_use_mini_cart() {

        Notices::add_notice(
            [
                'id'               => 'stafe-el-use-mini-cart',
                'type'             => 'warning',
                'dismissible'      => true,
                'dismissible-time' => MONTH_IN_SECONDS / 2,
                'message'          => __('We can see you activated the <strong>Mini-Cart</strong> of Elementor Pro and also ST Addons For Elementor Pro. We will recommend you to choose one of them, otherwise you will get conflict. Thank you.', 'st-addons-for-elementor'),
            ]
        );
    }

    /**
     * Get all the pages
     *
     * @return array page names with key value pairs
     */
    function get_pages() {
        $pages         = get_pages();
        $pages_options = [];
        if ($pages) {
            foreach ($pages as $page) {
                $pages_options[$page->ID] = $page->post_title;
            }
        }

        return $pages_options;
    }
}

new StAddonsForElementor_Admin_Settings();
