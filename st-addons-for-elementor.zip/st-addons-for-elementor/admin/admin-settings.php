<?php

use STElementorAddon\Notices;
use STElementorAddon\Utils;
use STElementorAddon\Admin\ModuleService;
use Elementor\Modules\Usage\Module;
use Elementor\Tracker;

/**
 * ST Addons For Elementor Admin Settings Class
 */

class StAddonsForElementor_Admin_Settings {

    public static $modules_list  = null;
    public static $modules_names = null;

    public static $modules_list_only_widgets  = null;
    public static $modules_names_only_widgets = null;

    public static $modules_list_only_3rdparty  = null;
    public static $modules_names_only_3rdparty = null;

    const PAGE_ID = 'st_addons_for_elementor_options';

    private $settings_api;

    public  $responseObj;
    public  $licenseMessage;
    public  $showMessage  = false;
    private $is_activated = false;

    function __construct() {
        $this->settings_api = new StAddonsForElementor_Settings_API;

        if (!defined('STAFE_HIDE')) {
            add_action('admin_init', [$this, 'admin_init']);
            add_action('admin_menu', [$this, 'admin_menu'], 201);
        }

        /**
         * Mini-Cart issue fixed
         * Check if MiniCart activate in EP and Elementor
         * If both is activated then Show Notice
         */

        $stafe_3rdPartyOption = get_option('st_addons_for_elementor_third_party_widget');

        $el_use_mini_cart = get_option('elementor_use_mini_cart_template');

        if ($el_use_mini_cart !== false && $stafe_3rdPartyOption !== false) {
            if ($stafe_3rdPartyOption) {
                if ('yes' == $el_use_mini_cart && isset($stafe_3rdPartyOption['wc-mini-cart']) && 'off' !== trim($stafe_3rdPartyOption['wc-mini-cart'])) {
                    add_action('admin_notices', [$this, 'el_use_mini_cart'], 10, 3);
                }
            }
        }
    }

    /**
     * Get used widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */
    public static function get_used_widgets() {

        $used_widgets = array();

        if (class_exists('Elementor\Modules\Usage\Module')) {

            $module     = Module::instance();
            $elements   = $module->get_formatted_usage('raw');
            $stafe_widgets = self::get_stafe_widgets_names();

            if (is_array($elements) || is_object($elements)) {

                foreach ($elements as $post_type => $data) {
                    foreach ($data['elements'] as $element => $count) {
                        if (in_array($element, $stafe_widgets, true)) {
                            if (isset($used_widgets[$element])) {
                                $used_widgets[$element] += $count;
                            } else {
                                $used_widgets[$element] = $count;
                            }
                        }
                    }
                }
            }
        }

        return $used_widgets;
    }

    /**
     * Get used separate widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_used_only_widgets() {

        $used_widgets = array();

        if (class_exists('Elementor\Modules\Usage\Module')) {

            $module     = Module::instance();
            $elements   = $module->get_formatted_usage('raw');
            $stafe_widgets = self::get_stafe_only_widgets();

            if (is_array($elements) || is_object($elements)) {

                foreach ($elements as $post_type => $data) {
                    foreach ($data['elements'] as $element => $count) {
                        if (in_array($element, $stafe_widgets, true)) {
                            if (isset($used_widgets[$element])) {
                                $used_widgets[$element] += $count;
                            } else {
                                $used_widgets[$element] = $count;
                            }
                        }
                    }
                }
            }
        }

        return $used_widgets;
    }

    /**
     * Get used only separate 3rdParty widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_used_only_3rdparty() {

        $used_widgets = array();

        if (class_exists('Elementor\Modules\Usage\Module')) {

            $module     = Module::instance();
            $elements   = $module->get_formatted_usage('raw');
            $stafe_widgets = self::get_stafe_only_3rdparty_names();

            if (is_array($elements) || is_object($elements)) {

                foreach ($elements as $post_type => $data) {
                    foreach ($data['elements'] as $element => $count) {
                        if (in_array($element, $stafe_widgets, true)) {
                            if (isset($used_widgets[$element])) {
                                $used_widgets[$element] += $count;
                            } else {
                                $used_widgets[$element] = $count;
                            }
                        }
                    }
                }
            }
        }

        return $used_widgets;
    }

    /**
     * Get unused widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_unused_widgets() {

        if (!current_user_can('install_plugins')) {
            die();
        }

        $stafe_widgets = self::get_stafe_widgets_names();

        $used_widgets = self::get_used_widgets();

        $unused_widgets = array_diff($stafe_widgets, array_keys($used_widgets));

        return $unused_widgets;
    }

    /**
     * Get unused separate widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_unused_only_widgets() {

        if (!current_user_can('install_plugins')) {
            die();
        }

        $stafe_widgets = self::get_stafe_only_widgets();

        $used_widgets = self::get_used_only_widgets();

        $unused_widgets = array_diff($stafe_widgets, array_keys($used_widgets));

        return $unused_widgets;
    }

    /**
     * Get unused separate 3rdparty widgets.
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_unused_only_3rdparty() {

        if (!current_user_can('install_plugins')) {
            die();
        }

        $stafe_widgets = self::get_stafe_only_3rdparty_names();

        $used_widgets = self::get_used_only_3rdparty();

        $unused_widgets = array_diff($stafe_widgets, array_keys($used_widgets));

        return $unused_widgets;
    }

    /**
     * Get widgets name
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_stafe_widgets_names() {
        $names = self::$modules_names;

        if (null === $names) {
            $names = array_map(
                function ($item) {
                    return isset($item['name']) ? 'stafe-' . str_replace('_', '-', $item['name']) : 'none';
                },
                self::$modules_list
            );
        }

        return $names;
    }

    /**
     * Get separate widgets name
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_stafe_only_widgets() {
        $names = self::$modules_names_only_widgets;

        if (null === $names) {
            $names = array_map(
                function ($item) {
                    return isset($item['name']) ? 'stafe-' . str_replace('_', '-', $item['name']) : 'none';
                },
                self::$modules_list_only_widgets
            );
        }

        return $names;
    }

    /**
     * Get separate 3rdParty widgets name
     *
     * @access public
     * @return array
     * @since 6.0.0
     *
     */

    public static function get_stafe_only_3rdparty_names() {
        $names = self::$modules_names_only_3rdparty;

        if (null === $names) {
            $names = array_map(
                function ($item) {
                    return isset($item['name']) ? 'stafe-' . str_replace('_', '-', $item['name']) : 'none';
                },
                self::$modules_list_only_3rdparty
            );
        }

        return $names;
    }

    /**
     * Get URL with page id
     *
     * @access public
     *
     */

    public static function get_url() {
        return admin_url('admin.php?page=' . self::PAGE_ID);
    }

    /**
     * Init settings API
     *
     * @access public
     *
     */

    public function admin_init() {

        //set the settings
        $this->settings_api->set_sections($this->get_settings_sections());
        $this->settings_api->set_fields($this->st_addons_for_elementor_admin_settings());

        //initialize settings
        $this->settings_api->admin_init();
    }

    /**
     * Add Plugin Menus
     *
     * @access public
     *
     */

    public function admin_menu() {
        add_menu_page(
            STAFE_TITLE . ' ' . esc_html__('Dashboard', 'st-addons-for-elementor'),
            STAFE_TITLE,
            'manage_options',
            self::PAGE_ID,
            [$this, 'plugin_page'],
            $this->st_addons_for_elementor_icon(),
            58
        );

        add_submenu_page(
            self::PAGE_ID,
            STAFE_TITLE,
            esc_html__('Core Widgets', 'st-addons-for-elementor'),
            'manage_options',
            self::PAGE_ID . '#st_addons_for_elementor_active_modules',
            [$this, 'display_page']
        );

        add_submenu_page(
            self::PAGE_ID,
            STAFE_TITLE,
            esc_html__('Extensions', 'st-addons-for-elementor'),
            'manage_options',
            self::PAGE_ID . '#st_addons_for_elementor_elementor_extend',
            [$this, 'display_page']
        );

        add_submenu_page(
            self::PAGE_ID,
            STAFE_TITLE,
            esc_html__('API Settings', 'st-addons-for-elementor'),
            'manage_options',
            self::PAGE_ID . '#st_addons_for_elementor_api_settings',
            [$this, 'display_page']
        );

        if (!defined('STAFE_LO')) {

            add_submenu_page(
                self::PAGE_ID,
                STAFE_TITLE,
                esc_html__('Other Settings', 'st-addons-for-elementor'),
                'manage_options',
                self::PAGE_ID . '#st_addons_for_elementor_other_settings',
                [$this, 'display_page']
            );
        }

        if (true !== _is_stafe_pro_activated()) {
            add_submenu_page(
                self::PAGE_ID,
                STAFE_TITLE,
                esc_html__('Get Pro', 'st-addons-for-elementor'),
                'manage_options',
                self::PAGE_ID . '#st_addons_for_elementor_get_pro',
                [$this, 'display_page']
            );
        }
    }

    /**
     * Get SVG Icons of ST Addons For Elementor
     *
     * @access public
     * @return string
     */

    public function st_addons_for_elementor_icon() {
        return 'data:image/svg+xml;base64,iVBORw0KGgoAAAANSUhEUgAAAHEAAABICAYAAADBCxq1AAAAAXNSR0IB2cksfwAAJihJREFUeJzdfQm8HUWZ71dL9+mz3HvPvTckIWwhBgIMP4M8HGQHAV90cOApouIyjA/cUJ4OA8IAbpEZRXj6Y3k8/flDxQeMsijOPEUdZZBdUNbHbtgTkkASkrucc7qr6n31VVV3n3tvQm5yD1ELTrpPn16q61/f/n11JcxQe/O8pWCYkjLrG0g6g81I1Rp4QM7U/Tfa2ITvBv83BoTkEEeR/eoOQkZbxlh+CWccBGe4TemD/9DvGo8bnmVarB3N5NoNUEvXsci0f3L3+XDQjh+CIw46Bl5c8XSfjJJdGWc1Bp1suK7MznPrUGUZRHIckloLBocV1AfaOAwderZWCpgyEDMBMQeoiA4+Ly1ehbme2f5H2Hf7MWbC69pzeJtpPt4aiSpP46HRrRrkJdUfAzciSkV7r85Yaz/FzEJ8wjwNYijlrA9P6TGICAqhFr7jCzJDg6CZBk0/uI8QeC7XwEqgC3s6x9HEc3F0cZ8RkAK/c6YzxqNRzofXCRWtloI/89/3v/TRVI3d/8Lzz6w0HO+ps2YjMn/bV2dvHugXUZK0tVHjwKIOVGINVckgzgT2SlI3GIuoi1zgMeyPAoG9iPOJyHDy2F3EGKccA6Xc99BpXnQdnw7P4k2X4v4jWzTIBw9eZ4egOablodJ0jsa5uy/O54X47GGcwgJoaM1r3mfL2kTSY/kMtgBaOiMs8I2FfVVmQUZQaB+Bst/xd0lgufPtMfpwC54BiYMvaN8OKLNoG3yjEQHihVhWHk9E67ZqFX4xNr7+vlq12ppVF7xe7XygJvRsmSD11QQ0qkhtMsW7Exw0QQRNGEYQ2A0xKiOxb4E7MDpuuQPgFKQPK0EXuIiJ8LXMdgLShh3maYF40OxL7abK0/QobtL34gP2x8fswpiO7DxhOW69AjA0/8rGb5mjQLdvCDCB7x7RtNZ+0LQD2VIZ9i/CAeX+dwcso6nHETyJ01AI7X6z1CsUk4L1CcH2FEztkcT68Gaf+m9v2KVyY19fehVXnaWGpb/rr7HP1uti3yRhUkb2WsvCMytmiOINTZrANmn6EEjcAxV+Y/kruv7SMeO+c9rHj45UphUdfU0QlzR+SNv1/Y9BpcXf0BHxqUp03ok32YXbKeEfP5E+et0Y5O/pQKCZCw40+/ImnKUcJSKqnEiLEYgWZEedjjgC2+I42AL5mWWpxlIOR3kpUpRPOCkQ2EolYwMN1hwY4AdWq2pPKdqHiLj99Wad/VTGtWcGBuT5So0fYiCVXOgwtQqWCQWIrhnf/+Kd8knJHMWG/rnfHJ8jMeLvsUkQjxy6HEyqQckx3r9+0YGKm3/ikB2GrLpG1/ea4CY1J98C+2TFe/gvxss3z0Zphju2ZAEUMjAtK5cMsU6SQ9xTgGe19jekOgciseY2fk8BWSg0+zkMNpEdJRmLotZQpZIuadTZrknCz2s01C8jKc4cGx//poHsLVLGQmm6A1EbTfWSpsJ46HPp9XLUAjtlnuWHixyrLYurTVOiTiAV4yha2JJUds5FabEf1xWZP5fpLUVjs1tg0XbA6ZUZ5IMd+sH9YFsg3BhlTi6K4kVJUntwuSkGLwDGOPPjh+9kWsBRu40qlmYzpD4Fw8MVGGpyBC+FJB7HrYIq/l5JRBTF2V6xVBcqpT5nTOsmlIFnR5H4NnKARcT+8ObMs2urdLljBcWJAIinOF6akNyKqYKQnQggKWvAS5ONg3hU3w0gWnN4Vnn6bzRPlyJj2FvT5EWWoxnJiterdU3CMHvDdwhsxwHB3bwndmnBCU2IQkdgLMhORuBac8SxWkXKkJR4Tz5qzQyoIfUNDsYwOACosLShEo0igB3cZ7gVICO6Lz5ez0dwviIYWy0r0b0I1lKj9cWoGM1i3nRxc89PGCjkeNG0fynXF/rQOPv3CJRquGOp/vopQTyieTWMxctYwvQBqAKfoYC/EVV2Y2iWKqcBujkDQRaVdCjPsQO/ncxz+aQjG288sE5LZVy52cnCoDjN0/WBoX0WO/ZoTA5i+E/gAUaU6Wa2ne0kFyUQgCjA3MRkbZBxCykshUa/gOZABaqRQWpsQ1IZQ1BTqCdInQmaD5FThCx/wGYJfKHS+mx83sfb7dZ/RHF0TSTlJ7F/IowD9xQf5J17x2Jk7K6gAaLZmHNXXlYaEVxe0songXjwwHfxhSoAnXnzcdA+hVcciJCRYmW6hGoBRZdSY5if8kFgBXXZFHJrEq5TmA0Tj5FKbjU8x5YkgscsgMbLQG7BUQSwfbq0IAWFh7RVQ+YCWWdW47PWm9dCrQ3JwW6RjUZj0DegoDnIoa+OZkKEgEYpbes1BSj/ULPF+wtvguSTmXpo6f1Q3D8piWtfi2r8GnzeUUabPUF7+esBdBLSFFwmhzEc0PlYs5JiVD6b8Y1QYgX/01m7jiR/PJ57HKLHXTd5aTZALli7qcq/kCnZbtR0IagBJrERfER3JyzLLl3PSPPgBKImAidDGyR+LEuhHgr3HDs4kjsApUbJYQESjLRTmnxcORsQX92yzSjKaDAs1VYtlfUbBNHgfgdlnoYafqrVUZKFFSsn8X4R8mbOugdWG0fd+AxkwPB3uHOTYPz/oXZ8LYqiz2tE0r6BYDwQGclvek2rPZfNDFOwfFbS3liJK2lTKERdIB45eAVO6OVMqbn74Kh8FAFMyvC8dvPaY9gN7JSVKKbrbmVtraTuMlN6oDvOvI1HLM8YoijrlSFPjJNLJO7JjcYdoNY+I1noAXROAE4gE+6WPUMLjXIF/U0Bff0M6g2rrHQgRtBqyDaTWOEWAYzBUSu9X3nSuQnraJHYqt2bh0dPGWmpTzRr+ibs8Xux54ty88B4KixsJCiZul6RKZshk8c516ahBOKSxg3Q0eMo8nYYwGtPwNm9AAqeOKltFFQCjHmWS45Mt09YFAwisFr3HiXKnEilLNhyduCt4ZySsFfcn2vlnmeHMTgKJtmN51jmZryrjeSipT4yrpHt8g4ChMpKI0Hq6yD14XcEK0LQkmqG1IcfZJ9o2EMFJ4H07jzX68IuZcTGmZ9qlgPQwyp4zsE10IvjSDyaZfr/IjUugvz6QFFe7HAPJgTGHOQmTOBo4TvzrFlBl8eGAbKSVPC24Ltj9/7WENhWwG3aGCyPuclt1JLman9XRAf0RTP/ugEcbwPxXOVmhXHLSjPWyxEJgliP1SrJ1pNe0HvKt+NCVIYDT7LOu7SEpUrLYtHeswBGcQeazQj6+yNIasgyreZZ6ZA5kVQVgmuVIQUxsU/mzBLuTBhmVD6LWXDduUEkSuduAs9Fpvf2uSd8Y+nya077HU7uNXhsKLyXA0LnakO4PjfdWNBUJ48/Iwe94MwPVA6iMhXIRLuCXToKbz+PeSraTD5Kjeuce4/j9S8hUquQHNqObUIQ0cQGHWF6XydAbjt1v5DXgo3JbXf6zW4jlHcyQ4pMnVwkywmpEQcRFUdyuVm2SRTJrZtN43d7aYpAtmAQh3NwEGVf3YKL4OG96lVkp/WIZKW00QjsFAK4OzdqOyDJy92zrBuN9nnOaQJ747myYhrAsgOe/8HHByRnD6VaX4/H9sQJqMOkzAHs1gwhOCe4kFDW8Auq5Exz/jxj8Yj9loP4hyOPg71/e3WDa/FfsVPIPZABTLJjuh9VerbxPt0xfMNb8IcbcPsYvtarVpPgPHbwkWh3IJKCIkzhaDGFFhu4a8F8vOz0Rrm9KEPwNMo0+2BuHczIZq2MI8rT5LMm+UW+DWNlY0zy0jqkrfelrz+BRgOQAp24tspOjOpqEkckd9NOC6pxRUTcfEBr9Wl8JlqGgcPw3NVXcI1AlbnGiY8z85G97oW3vVcpOB9foQEFT+3+5KPqtHeS3STQpzDT7HxivI186cUuEPe8+5tMy/GdTCb34qasek0N5AQQcWYYZBfqu1Lz/8119bnRaEVn8SsfgUshmfL6P4f25BVnoMlprsO3OwG/zi+4ZvB1Gm/jlVyBpYmPh2bJSL6pk2Z3JrXas4PHXdiTfhKIx9SugdH0VYRd72N4u6ZMwqzab2f4RhspMHbHqhR4udbXGLbun6vr9l/z9CHHwpO3Lodb4ZM96fTr1Ri0LNU8jnR3P9L1jjg+5PDPbfGgA+QadOlablk8608N2ohZC0b4rJ71M6fEOEsEcrTFijmLa9PqjJVpufKCxK3vR/X+Igb9a34NbwZE7y+iKWe7tfDza/wsAR/dsm2CBTRBroXfWMVwOb+xx5sT2V7fOu9Db4KlP7hvxvtJIEotwWQ4dxgssO4jO9U027RS434mebSem/bPN/DVzzRM/4x3cFu2DOUoApnFJr1NGI1gssTpIV0sE1ys1xvrxnEvzoRVAaxhM7hh+bJ5O86bvaxX/Sy0U9lG/s+Q5ivcURr1aCMUychUsMofamojaLvd9Z0zzzIf/tyfN/uc2KxqUFOj1sH3AqL0GE7w/VEvYYV3pdujAt6dFxo5AQT0q9bovBeefnpZL6jQNgLxJ633wBGNb+IeT3g25GLfpNpM7arWngZdyFN3MqFXnXbRZfAAXN6TTm6rtveHLoCnvvdJO5fbCNw9aHH8tbKQetuT51Z0cJtZf6wD0brFrHaP20as+Gw7lOsuOg2ap1884/3MKZFbR7t1LFp7y6ru3kU7FU/1iQzg1GFtfQJycHARLF7zaXggu2TGO7mt2pfevQfM3m4Q1r46kqLp8qjRWssoQs7qfLQhhhMiROWhcp4jsiYiNFPqGsGNGtMwuqfRCMR3xTfCeLrOPnRDyrGHaIE5j7KAKUG0Dmrr0yKbSCVcR/Ob2aL7Xske6Eknt2Xr23shrLrtD6oqoxe0cgodUaL3EDlH+FQRHecCdJZeW5gMlcdZ0wnCbX4jENcqS1fWWaNXKNY2LukpuHy6hbj7ZvKIBvL9fqYrR9y17PIb57Fj9Qvmtz3p6LZoX7j+MXjXcffAy+NK7cjM2liwTDIWGROc3s5744x+lvuH8+Q7CodxGzgmmtQw3pN+EojrlIBEGoUPRZsIFKqpkfO0A+SO3tBB+kYOUXfc6Brj8qgFcw88BA/fAit70s9t1n591+/hM5fdbW6/7INj2w8NdARDDZUJsqOdUmMz2lLvdoPcZ0haK3it1ZKhDeXprCd9JBDXsNthO5ivJK/cxzSjIF3h0pvgRc+dfZ5KKdrOFio9dobh6dqTFz744A1PfRHWwA096fDr3VasWkPRi1suPhH5FVPOYR+iNDp3YucZa7xwWrM8mgMQ8h160QhEy7kzWK8jGHwEOfcqPDSflYmu1MqJui4Z13ZNR5luvVVy9rUVow9eul90yK955ejWb0ackpPCKJ5jfbXBA9Tv920Ke8fvW4q3c7eBn8i/dAZDUQW2H+ijfjz8ykM9GYRNNe51vziugZQVo9M2RUdImTEhGXnjoaPXo1EPnzHnw2Ht/zSd+LnVqMzchdS1MzAfUfGtCKGEwK+Vm9JtreNZZFUm1JGC6T0qs/p+HwO/8/jGPy5TCk0QBLvDNXQEvnRsE4+qEOGTZeQCuExoivtZQWuj8ELYbLUxiOWY2Xl23KrF7bVJ1F6RxG9b19eIstnDAypD3X0EJ0AFJ+Ahnz6vZwOkFfdbRtkXQso8Kw7VVHLAO/Bc6oXx3nvufCYwqZiiBy03MVKJ+KnqGDLuf8d59U6kr4Ypz6tJwUlDUQmXJeZyNzmqqYxn8zXnO3S0OFIy0eYSTOTBkdLHAFMEDDU9jYTIJKPfaAAsZcsUokRDvS6hUatALTa6WlFZRWbjFWGeTSJ2r9bZLYypB+c05JrGYH9qfvd9c82tj8GJp//LzI8QaeEIIirsVqGx0QXyivpsNOYdIizEzyaGjV5PEMFU4M4N70wPaf7kLjQb7kOBfbCrTyi6V4aRyNTG8oRjq+Bnp83+QqGPYPImGbtSU54LUDxPQYjy56+mfRzOXoeUVY0QwKqBPrSp+uoc91OoRAqpUkOSmIXVWnYwsA0n45x5XEL9x2b9qz+974+PPze86qX09vM/Agedc8WMDhDzhV1EWTnbdAU4NobFQuYd89GNoEnY2Jz2W1NEPXrRSjk2MRw66xrb3RXa6Kvwifthp2vG54QUL+XifrlmRrNRefbhQHKFKcrJTWShNvrO7JZS7WyeimOjNiE7jhkksb02Q5AzGB5i0GjYSLumFIlKrQMxAhtHNuuai0qsa8aoKvZtCDqj+xopT4wr8TfmLNj1lyySr8Br+e6n3YKjX0ERcbcyvDuaO6UknDowP+MtB/GODUvgwPg70GqlLRz8m+IoPiaJk3darziNuAlsw5df+UIPQTkmLoHJZoxxmz5BKRIOXJId3Higi++RtODZyiRkn0ihtaqEZh+H/v42AogUiSy1Yj9IlVFMbg+UR57S7ZOZlaSq1lH6TSIWlzPBrwbRueR3V5/3uOJcHfC+L83IALmiGLtN8w8w/57EajWFnicqNXmyMAvJGxMzAGeudWW73fHKyXDgnCtgVI08H8n6xQjbnjj8C3HgcZMxlzYgyEPvS/moRMwW1HGbv5l79F2xCvkX8XfKUXFGE+W6oBIE0hZYonZaqzIY7IuQbQKyyzZSYRuPKahUbMIuUipuSQGyGWsWwNzp4fJ/jAsf9AlQH0GbdWEjG//KU8lut/7mmov0W99/+lYPUMjtdJNWUR+Mz1KwWr0JZXGMlQkTQtJvnvXXQ611Ut7pHSv/DY7Y/n1GG3UnDt0l2NPPI4DDNv3ByiybasFRTkjulBkRUtSp/s6Dx5hPfOKUMiioIsllpAHr4HmpZY2ouERUoDLQj1RZyZDaUqjXrOxjUEEWayuRRGQnjvLlaSFq0OVFYt64joVhRyCQjd3aT5295wcv+M+bRQRHnHDaVg1QHmKiSeTyaihBWXuO5PzeuVM8v84nbNFvxJGLtPuZblOk8f8Ybl7xYzh87nWjqI39CFiK5oY5RUjWb8Fzfc6QtUVe0DuHEmfaVxe5WD+xVCv3bLVsZLPEMvJcSJkhSAoGmwIGB1A1qWUIqE2Rt8BmRIFWTkYRIyqgNHnuWHNX0lAYMgN5Rhun1Br119xkX37i//zD6eueffiebPnvQc77L1s8QHkQOOQ15XWQAKFEwAWjTDeIwS0JJtfgddqb+pWNFtT88aUdYNG8x15qp9ElUuCYysqHhdBNZIFeo9b5SzHmQcyTf319g7SUZNkhmhO6RbUL9Tpqnn0MKVBTcm6jpoj6KrGij4xsvb0fheANgVCmHQaQaoXyPB+eyx+aQByB3B/Nlc/OXbDonOU3f/fprRkgX3BNPtBQImDAURnpC66D3Ua171fgopZr2TI5rTeR7rIVbaMgPg8HwPPLAd6+878+qzVcgCMzYkznZNQyZwv/AhSO8exUhOIP7py+lPdpU/+QRXLZIfD6+yTUajY1EMGj0jA0J1D/rVdsOj3KVKnI0KdgtB+FXH1nfq57WdyVg81cCr3VcGkwGY/xye8wrPJAKxr8xrIffr6z4L1f3qIByhOguLMRXRDAQGm+QlBDJyo2+e8s1FO8DorNVO3nz70Pjlt4zYsI0zdSUM8Ypk/Fd9kbRbqImKs0crLBsz/mgLXFKlbGRdEY1PsMDA6i8V5HdhqNQl8t1DlwqFrWSUUtiqiZogK+RNsxLMpKdZ0JyhLrVumZp1abIc4o6zlClUkMpB11Au+svl0Zc5sx3YO82S33iRYYFOn3viR8Sneb62SeitlDb9xm1ez/5Kn3w9G7f+tl7PdVOOaPcGM+iObCCZGAJqVgWiqwaVa+XMy64WyhSq02gtpmBymwgsAh5cUpyb5GDQ34xNqIQLme3GsI2taZ0b5bkoTC0kbSb66sLczsbkoMRnjwpBivWCWRWIzbd8bSPLDyus9u2JIBMqVsdlZ6vltMIZsUufBnOlCNge5C3NdNsZm6/eqJj8Hu8//nGI7tHYuS5EkQ2U8VU3+XVOIjtUoHEFAba+HWOYxmAasj1Q02FfTVNWmeSdRBynNFKhVkpVEFqPza1c37Gg1f/cSYCzhDOR0QvJLgaZOVlZyAKPNn0GTKrFJkb7REGfZTlNu3v3Dd2bDj8VvmmnPy3xGmmyxeB/Dq6ZRUnpsYuvxlxtu0Vs944pl/sBvzhn2+sGpEx78cgIF7Ncv21Kb1dqP1wXEsdq3VxQCaDGKgD/lZg7EEpROPxlEjtbLQudWoMlfawQ7xNc96gjJD8raG3BmVFJERjRF41ihkQfYW/QrhIDK+WSiP9uyYmT1wux9Lt7tHitGOuu58EMefM+2Bck6OUMMPuRfLyTo+CUTmE3CCqCnskZlvW7SOzc/u/xK8Z/8L1Ety/erZnfiV2Jh7lW73iyjeqdkcWDCrX8zvj/WcOjcDko/HrD4GUWOcyqRj8rVSPg/dK0TETV4ui9JXRzzWjX40VhdoYbbHEesDcpNbTlmKy4WCnzBGjOeToaTNxsj+95P81dmZzl7glekOZKh+Ms7wDyWWeRFooLCNCL1g8W9rmThVu/buM8Ou/tgBZ4+1W+2x/mjWKin0fUg+yMkMEpHmcayZRBNCNmy1rXWxueKX3L7qApG5cE/GQaYdgdQ6oGJY0lLmo8gfUZmChGltKGbtPCF4GXfM2E+CQBC58uPO2zvjnbl49gtrzLPTes+QhhLWNQrrA3DDyfdrjFt4ieUZEMF+LdmTwX2zrbTTzWnfutPJmc/sf5p+bt1L2hpme+I77b5rA4YWAGy3G+qywwiiSoHhx3i/q20EJg+YCDyegFoPkK1AmzGVG9LtdriiNbrhNq6zzyFFvRtPt8uNmZL3I5AdC9Q3WVFUO6CyNffhq94P+5x05Ra9Y9Bf+KTF1uA1RJ0pfXrTZnTttW/ePSGn8p6tv+dLN52rGyMrHuP12lJj1SEmT2CsLFy8R8TSBDlQikX4isJkMyCEHj7inCvE+MvRtCzuQOEQQk5Q1E8GY77cnSJw50/4cwOxF23ukq/Aul99GZ5+5LFlw3Pn/IBptS/S7SLwS2xZwzAsJ8J8QK9cyetJKFZKNZc/tVb2N4bU0uNnw3nXrZpWP/L0i3wpMlOIQqYmnFi0UF/Zy0YgnrzX/7IPH2CyMmjrT2OZkVDRIkItMgUpN6BmOQ7DQwD9/ZoqaqVsQ38tgqqgsNLYgWctXXnh8YfDGdffMuOdbB79efjjj86EFovurpoNtzNbOg2+oJMamYauHLvk2yyKECz1yDoXTdkYmtM209AyipwilsvvQG1dRv/EiD6Ad5bbJRN7u+aPfPvO/wN4zHklqh/WamcnKmWqqc1wtoFc2SGHdSVuQx9KolrNOC+MLdKMOPRXUAmJQFUifs+9Z/79V9+6734GegCibRnEMKxXrOmwxNZEdJAk4mArMh9CcKzNlGRkCSwborcOzEzDloCYu89yHu1ZJNsUuwzJXz1mp1aedLI2DkO8EHt0DH6t23p4iRQo4pSqaQf6Iuhr4DDGYyBFG+oJg4GqRONdgOKogkImth+ey8al6F1PKxKyTsUO5hocyBHw9e+2lWKMUPJhGgBTRouVfZ6b33JzxgPp3WjTulGJvfegSUErKlHUHe0B63JBdokUGFfb0GhqaDYFAmmgWlHINhUtF9KHIFqfJ60nKgzqlAaxVLQ6U6/aomO/CCuuPdXu2nxGGTLvCvkX8l9oHTXj81pyA85mqUUJzsh6FYQQ03jy5oHVrdAECmaUh0MZcNYU6ZFslO32OLA+VOdjjdZbGypVlHsNBQ1knw2Uf426RvDaCGKK7NT6Py1RGJdDQ1lsJOy5sFZ83DuL9tnrzoDviXPYSercnRCjfqdklAfF5CSZ+zfdz97PY0ymUNYrNU0Qy81PmFypKbPSye/OuvbYlOfMRJPWf6lNCz/C1AeQ6voNDDUzqNcdaBGy1Vhk0IfysGbzXQhATWVtmc2rQZse9cPZ7R2aTWn02keuvxT2evenZrSTq370MdA8hb83X9wNRcw+eXjKTFheuVBqiEy5d3Y6J7bpqEzRirQbNmy+LzyP7HtXH/Nu0DwIHJyqU7QC2sIb1YsmF+02DxKNrAb54fCcBFnOGCSVEUgiZKeJXcEhg1oioJowByCt1IQg8hDro2XAdnx1bO1Rd59y4bUHXXXujHbQPPF9WPn7W2y2dcxl9DZ84FuKdWDKgzJFULa8CIJh6wcrqLOtXg9ZNo2aiBCFKJb5gNyNVmy2aZNV5I97DMXIEM06EY0oEXdMUs1YvY7aaDVDNgsu14U7m4fTGlwuKcrPcMta5zHBPnrwlZ99PILVDz/xg9P07h/a+mLKmy84HGC3D8OaO26MBusDRyNsJ3Mmh6jGgRYG8s/noZbSNS8v7WlEN9ywUZ6ZV8SakaxTT+CCn28+JRarPEIexcgpscQht0X6fmjyn288C374iS9YN9byuAJpnBhiozYPJklsZF6Q3HMC2l7i2It1Pxnj0xUpmU0fplX6dQPia53M3H/f984azXgjG5o1x0R4YzLJM1vaZVAsGWinmV0IsJsVoVLVjjvunipDUf1q/MrPPjE0qzlwZJrqs/DJi3KzrWSf5bcwfCLncv8aWI2Yrl6+U1XPXTldeaiL5wVKLBv6fwKN9Mn6bJtsoZ6W0BmzKYR2Vd040j71wi+uByVnLjhZQdEC+5tGBmsyaYw6GpjYI+bwi5iN38XU2Op43auZu0Tn+Sp2CYpk0hpulrQVZKbjssYNR2ZudtFKHx5HyRGVWPalnZQFLbToS4mtlgx9yI+QrfYUaLG8fx1SrY6nNUC5Y527vCE7UnmaIg1L7xSWzW0E4o6LO7DhxdZKHMHHazzeIYmFtIEfbbJgXUFYc5P+jkRYeZ+Cr9wvvYzqjqI81J2Uzk5ByjwJD7UY6hPMB0bLTm9WpqCSrzHCSWErcvHetkayisYLc38/wq8iwFiJ2IKZEa6e2BzFKA73pUK+RHmjH7homkP0+q2wvKWNQNT9z0FlpJ6yVN4k2/EhNsWJltaSXvaE4THOZxgAsEFSKZ3xa/+VEclLZm0ytIkiPCcqFiP3/sbgPGa67BTLtTybjiF9TTwaLrSWjNJOoXIxdA15TnUuj9ydNONhZV3P8uiE1bi5d7Byz7oVZv+tHK4t9bwE3tvDyP6+R/0A7r7qk5nMol8hYX3KKD3frstqCD6dRwVsCwlDk5a5YVAsOhzkhjfWwuqLhpfU8vByLKQ7ODaluQOLG7fKsCavFXfmhMnyjOzCzeb9y6wAs6xB4u+3Ix3fOwJvhHnv2JpluSZGJDZXKIZzp+vl2fyW+1h2HtfmZVN7RnL9Mxy3jxu7WlsOhl8OknttrStyziDPTvPn513l/gwPcEA//JGPEPUOwNoaRS1cRMBotzYFLcCnBX1cioTKn9/tiPZDVjLA8Swbqrix718vWzbyvk9s4RCZCduwX/CR1762t61Y77Q6DLVWNoY6yg8Vg79B1jQfuGQ260xYajS+sNSeS5W9YTCDnAsDG/5mQ/GigY5zV1nBPSGfIBC4YFhgxXlGpPF/vyIviwvPKfoTWrGkvD1P2U7+osOSX657/2dgcMk3t3CINg3E5uST5opyryP7Iyseh3T7xZq3NzxguPweHjoHp3XEjU0F9uuNQlDh7QBn9HGKTtDRggfFFECGxNkcKiiB5gbIL73s7FAd5J2Ts9y45S3zPNSgFYeJ0OXc6qKQh5AZf39IPbp8pTyoJ4MXXnyj0JS15pyrzXzLQVz4j9fBkz9aDAtP/NqGR648+yqhOm+MjHm3IIEmIMTTuBeKhrmYYz6YvADFTbpAEYUSznlhEjCvfOTU54HJ6bIEVLino+I80gRdrI4GKXOgG/ki8uNvK9G5tcV3grlvm1kv0ua3kndnqnVLZ6h1xR12O+E8eOBbK+HZ8Q3L9mg0v45zfjt89sEGyS242MI6SoZ1U1feWYBS8DQsWtedRFQOruZsNL+2e+u/QZCdeSIUhMeFgbEKUWa7tVpq862UySsjFXfid/xlLVU2VZsUPFr8sUvh8SvOMKjn3CsFX4qKwpdQJu3PaXEklzRreEEBuUoPAKH0ObQc4DwTbep0wa7avpKbq7g0t1T9YmVuBnQl2oANjaEtGPHL2Uj7kgrLRtkxM1v6/afapowA3jl8ALyj86CCxq43v/rKQx0J7XMlk4dxE0WKKWaXbaZ69ddQsYs/I7fx8ybeo5gEr6VQ+PQLd5r1aD+XpvrCOI6vhoFoPTv0L2eNuddqU4J40rHvgpfvuBIe/tnF6oqHTvjtV096+lTR4p9hKjsuE2o2giiFXUos/BGTvFJ2AiVO8b34UtZsi3VgNl9uUIjJqsJr8Ms9eLfzO6m5h7d4J4p6sWR1t8b9p9Q2GoufdeCH4TeXvgcuPnQNNN92+ZPPXX3q2bHIbjNCvR/Z62JQZnsOVBhFFFFme9TKAi8cLgn3Lke23wvbPAU/bEnjyXzhKjnibfLqy0zrR7URNypIrlVMvLR+wwrz6B+fh7ec/ssZGyDlSw00PbLD7II2wrgMdmeT6o3yozxX3RgomMbMt00mVLz1U9fm+zufeNn6Vf/+0WsqAP9hFByuU3ibYPBXIPT2QsAQdrCutRZ2jUYuIpBUHhW8/QJCklEwLXLb39+/0FJdMQ3ZhtbvqWlBBxw6Pcq4XiNiviLLssfQTL054vw3MDq2HOKO5sd+pycDpP3CC1p2mBYpZ9YlqCu0aK8mD7j9mxwaJv8FZ/tnKqz/WaKNFpE6kLFqT/o4rayY2cd8225W3z/Wvnb4louuZxteWCCh86Y4lru1lZ5jjOhjissIZ6r9C9Zd6xaH2oVSLYVLtQ8OAe9Y93+qzP2xLjTwtc6MyUaiWK4cbbWfGlHiD2my3TMc2umcJV+dmVHYRBN29QegwOtaWUt+yFqmBip2nMQD7PJnuv8wJb2ZXR1dy3U8qj1lZ2Ta7rGxP522T41ezE7Dp+zHmFNg3elVSP5Kc/0ySs31Y8iESuXftlGKvnvNjBJz3B9rZrpUQMpoXru/zMZiPHfEjK26Txmj9E6XPryVr7qFbYH9a0vfg+Fdd3kemrXTeLNGVMfsCiDSr2ejpeM2XY3RHxF94v5l5sv/dKmq1hL4zr+93JMu/n88S5JgJn1GRQAAAABJRU5ErkJggg==';
    }

    /**
     * Get SVG Icons of ST Addons For Elementor
     *
     * @access public
     * @return array
     */

    public function get_settings_sections() {
        $sections = [
            [
                'id'    => 'st_addons_for_elementor_active_modules',
                'title' => esc_html__('Core Widgets', 'st-addons-for-elementor')
            ],
            [
                'id'    => 'st_addons_for_elementor_elementor_extend',
                'title' => esc_html__('Extensions', 'st-addons-for-elementor')
            ],
            [
                'id'    => 'st_addons_for_elementor_api_settings',
                'title' => esc_html__('API Settings', 'st-addons-for-elementor'),
            ],
            [
                'id'    => 'st_addons_for_elementor_other_settings',
                'title' => esc_html__('Other Settings', 'st-addons-for-elementor'),
            ],
        ];

        return $sections;
    }

    /**
     * Merge Admin Settings
     *
     * @access protected
     * @return array
     */

    protected function st_addons_for_elementor_admin_settings() {

        return ModuleService::get_widget_settings(function ($settings) {
            $settings_fields    = $settings['settings_fields'];

            self::$modules_list = $settings_fields['st_addons_for_elementor_active_modules'];
            self::$modules_list_only_widgets  = $settings_fields['st_addons_for_elementor_active_modules'];

            return $settings_fields;
        });
    }

    /**
     * Get Welcome Panel
     *
     * @access public
     * @return void
     */

    public function st_addons_for_elementor_welcome() {
        $track_nw_msg = '';
        if (!Tracker::is_allow_track()) {
            $track_nw = esc_html__('This feature is not working because the Elementor Usage Data Sharing feature is Not Enabled.', 'st-addons-for-elementor');
            $track_nw_msg = 'st-tooltip="' . $track_nw . '"';
        }
?>

        <div class="stafe-dashboard-panel" st-scrollspy="target: > div > div > .st-card; cls: st-animation-slide-bottom-small; delay: 300">

            <div class="st-grid" st-grid st-height-match="target: > div > .st-card">
                <div class="st-width-1-2@m st-width-1-4@l">
                    <div class="stafe-widget-status st-card st-card-body" <?php echo $track_nw_msg; ?>>

                        <?php
                        $used_widgets    = count(self::get_used_widgets());
                        $un_used_widgets = count(self::get_unused_widgets());
                        ?>


                        <div class="stafe-count-canvas-wrap st-flex st-flex-between">
                            <div class="stafe-count-wrap">
                                <h1 class="stafe-feature-title">
                                    <?php echo esc_html_x('All Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                </h1>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Used:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b><?php echo esc_html($used_widgets); ?></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Unused:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b><?php echo esc_html($un_used_widgets); ?></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Total:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b><?php echo esc_html($used_widgets) + esc_html($un_used_widgets); ?></b>
                                </div>
                            </div>

                            <div class="stafe-canvas-wrap">
                                <canvas id="st-db-total-status" style="height: 120px; width: 120px;" data-label="Total Widgets Status - (<?php echo esc_attr($used_widgets) + esc_attr($un_used_widgets); ?>)" data-labels="<?php echo esc_attr('Used, Unused'); ?>" data-value="<?php echo esc_attr($used_widgets) . ',' . esc_attr($un_used_widgets); ?>" data-bg="#FFD166, #fff4d9" data-bg-hover="#0673e1, #e71522"></canvas>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="st-width-1-2@m st-width-1-4@l">
                    <div class="stafe-widget-status st-card st-card-body" <?php echo $track_nw_msg; ?>>

                        <div class="stafe-count-canvas-wrap st-flex st-flex-between">
                            <div class="stafe-count-wrap">
                                <h1 class="stafe-feature-title">
                                    <?php echo esc_html_x('Active', 'Frontend', 'st-addons-for-elementor'); ?>
                                </h1>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Core:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b id="st-total-widgets-status-core"></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Extensions:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b id="st-total-widgets-status-extensions"></b>
                                </div>
                                <div class="stafe-widget-count">
                                    <?php echo esc_html_x('Total:', 'Frontend', 'st-addons-for-elementor'); ?>
                                    <b id="st-total-widgets-status-heading"></b>
                                </div>
                            </div>

                            <div class="stafe-canvas-wrap">
                                <canvas id="st-total-widgets-status" style="height: 120px; width: 120px;" data-label="Total Active Widgets Status" data-labels="<?php echo esc_attr('Core, Extensions'); ?>" data-bg="#0680d6, #E6F9FF" data-bg-hover="#0673e1, #b6f9e8">
                                </canvas>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <?php if (!Tracker::is_allow_track()) : ?>
                <div class="st-border-rounded st-box-shadow-small st-alert-warning" st-alert>
                    <a href class="st-alert-close" st-close></a>
                    <div class="st-text-default">
                        <?php
                        esc_html_e('To view widgets analytics, Elementor Usage Data Sharing feature by Elementor needs to be activated. Please activate the feature to get widget analytics instantly ', 'st-addons-for-elementor');
                        echo '<a href="' . esc_url(admin_url('admin.php?page=elementor')) . '">from here.</a>';
                        ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="st-grid" st-grid st-height-match="target: > div > .st-card">

                <div class="st-width-1-1@m">
                    <div class="st-card st-card-body stafe-system-requirement">
                        <h1 class="stafe-feature-title st-margin-small-bottom">
                            <?php echo esc_html_x('System Requirement', 'Frontend', 'st-addons-for-elementor'); ?>
                        </h1>
                        <?php $this->st_addons_for_elementor_system_requirement(); ?>
                    </div>
                </div>
            </div>

        </div>


    <?php
    }

    /**
     * Get Pro
     *
     * @access public
     * @return void
     */

    function st_addons_for_elementor_get_pro() {
    ?>
        <div class="stafe-dashboard-panel" st-scrollspy="target: > div > div > .st-card; cls: st-animation-slide-bottom-small; delay: 300">

            <div class="st-grid" st-grid st-height-match="target: > div > .st-card" style="max-width: 800px; margin-left: auto; margin-right: auto;">
                <div class="st-width-1-1@m stafe-comparision st-text-center">
                    <h1 class="st-text-bold">
                        <?php echo esc_html_x('WHY GO WITH PRO?', 'Frontend', 'st-addons-for-elementor'); ?>
                    </h1>
                    <h2>
                        <?php echo esc_html_x('Just Compare With ST Addons For Elementor Free Vs Pro', 'Frontend', 'st-addons-for-elementor'); ?>
                    </h2>


                    <div>

                        <ul class="st-list st-list-divider st-text-left st-text-normal" style="font-size: 16px;">


                            <li class="st-text-bold">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Features', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m">
                                        <?php echo esc_html_x('Free', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m">
                                        <?php echo esc_html_x('Pro', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m"><span st-tooltip="pos: top-left; title: Lite have 35+ Widgets but Pro have 100+ core widgets">
                                            <?php echo esc_html_x('Core Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Theme Compatibility', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Dynamic Content & Custom Fields Capabilities', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Proper Documentation', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Updates & Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Rooten Theme Pro Features', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-no"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Priority Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-no"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Ready Made Pages', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Ready Made Blocks', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Elementor Extended Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Live Copy or Paste', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Duplicator', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Video Link Meta', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>
                            <li class="">
                                <div class="st-grid">
                                    <div class="st-width-expand@m">
                                        <?php echo esc_html_x('Category Image', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                    <div class="st-width-auto@m"><span class="dashicons dashicons-yes"></span></div>
                                </div>
                            </li>

                        </ul>


                        <div class="stafe-dashboard-divider"></div>


                        <div class="stafe-more-features">
                            <ul class="st-list st-list-divider st-text-left" style="font-size: 16px;">
                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Incredibly Advanced', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Refund or Cancel Anytime', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Dynamic Content', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Super-Flexible Widgets', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('24/7 Premium Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Third Party Plugins', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Special Discount!', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Custom Field Integration', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('With Live Chat Support', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="st-grid">
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Trusted Payment Methods', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Interactive Effects', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                        <div class="st-width-1-3@m">
                                            <span class="dashicons dashicons-heart"></span>
                                            <?php echo esc_html_x('Video Tutorial', 'Frontend', 'st-addons-for-elementor'); ?>
                                        </div>
                                    </div>
                                </li>
                            </ul>

                            <!-- <div class="stafe-dashboard-divider"></div> -->

                            <?php if (true !== _is_stafe_pro_activated()) : ?>
                                <div class="stafe-purchase-button">
                                    <a href="https://spectrathemes.com/" target="_blank">
                                        <?php echo esc_html_x('Purchase Now', 'Frontend', 'st-addons-for-elementor'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>

        </div>
    <?php
    }

    /**
     * Display System Requirement
     *
     * @access public
     * @return void
     */

    function st_addons_for_elementor_system_requirement() {
        $php_version        = phpversion();
        $max_execution_time = ini_get('max_execution_time');
        $memory_limit       = ini_get('memory_limit');
        $post_limit         = ini_get('post_max_size');
        $uploads            = wp_upload_dir();
        $upload_path        = $uploads['basedir'];
        $yes_icon           = wp_kses_post('<span class="valid"><i class="dashicons-before dashicons-yes"></i></span>');
        $no_icon            = wp_kses_post('<span class="invalid"><i class="dashicons-before dashicons-no-alt"></i></span>');

        $environment = Utils::get_environment_info();


    ?>
        <ul class="check-system-status st-grid st-child-width-1-2@m st-grid-small ">
            <li>
                <div>

                    <span class="label1">
                        <?php echo esc_html_x('PHP Version: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if (version_compare($php_version, '7.0.0', '<')) {
                        echo $no_icon;
                        echo '<span class="label2" title="Min: 7.0 Recommended" st-tooltip>Currently: ' . $php_version . '</span>';
                    } else {
                        echo $yes_icon;
                        echo '<span class="label2">Currently: ' . $php_version . '</span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Max execution time: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if ($max_execution_time < '90') {
                        echo $no_icon;
                        echo '<span class="label2" title="Min: 90 Recommended" st-tooltip>Currently: ' . $max_execution_time . '</span>';
                    } else {
                        echo $yes_icon;
                        echo '<span class="label2">Currently: ' . $max_execution_time . '</span>';
                    }
                    ?>
                </div>
            </li>
            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Memory Limit: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if (intval($memory_limit) < '812') {
                        echo $no_icon;
                        echo '<span class="label2" title="Min: 812M Recommended" st-tooltip>Currently: ' . $memory_limit . '</span>';
                    } else {
                        echo $yes_icon;
                        echo '<span class="label2">Currently: ' . $memory_limit . '</span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Max Post Limit: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if (intval($post_limit) < '32') {
                        echo $no_icon;
                        echo '<span class="label2" title="Min: 32M Recommended" st-tooltip>Currently: ' . $post_limit . '</span>';
                    } else {
                        echo $yes_icon;
                        echo '<span class="label2">Currently: ' . $post_limit . '</span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Uploads folder writable: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if (!is_writable($upload_path)) {
                        echo $no_icon;
                    } else {
                        echo $yes_icon;
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('MultiSite: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if ($environment['wp_multisite']) {
                        echo $yes_icon;
                        echo '<span class="label2">MultiSite</span>';
                    } else {
                        echo $yes_icon;
                        echo '<span class="label2">No MultiSite </span>';
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('GZip Enabled: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>

                    <?php
                    if ($environment['gzip_enabled']) {
                        echo $yes_icon;
                    } else {
                        echo $no_icon;
                    }
                    ?>
                </div>
            </li>

            <li>
                <div>
                    <span class="label1">
                        <?php echo esc_html_x('Debug Mode: ', 'Frontend', 'st-addons-for-elementor'); ?>
                    </span>
                    <?php
                    if ($environment['wp_debug_mode']) {
                        echo $no_icon;
                        echo '<span class="label2">Currently Turned On</span>';
                    } else {
                        echo $yes_icon;
                        echo '<span class="label2">Currently Turned Off</span>';
                    }
                    ?>
                </div>
            </li>

        </ul>

        <div class="st-admin-alert">
            <?php
            printf(
                esc_html__('%1$s If you have multiple addons like %2$s so you need some more requirement some cases so make sure you added more memory for others addon too.', 'st-addons-for-elementor'),
                '<strong>Note:</strong>',
                '<b>ST Addons For Elementor</b>'
            ); ?>
        </div>
    <?php
    }

    /**
     * Display Plugin Page
     *
     * @access public
     * @return void
     */

    function plugin_page() {

        echo '<div class="wrap st-addons-for-elementor-dashboard">';
        echo '<h1>' . STAFE_TITLE . ' Settings</h1>';

        $this->settings_api->show_navigation();

    ?>


        <div class="st-switcher st-tab-container st-container-xlarge">
            <div id="st_addons_for_elementor_welcome_page" class="stafe-option-page group">
                <?php $this->st_addons_for_elementor_welcome(); ?>

                <?php if (!defined('STAFE_WL')) {
                    $this->footer_info();
                } ?>
            </div>

            <?php
            $this->settings_api->show_forms();
            ?>

            <?php if (_is_stafe_pro_activated() !== true) : ?>
                <div id="st_addons_for_elementor_get_pro" class="stafe-option-page group">
                    <?php $this->st_addons_for_elementor_get_pro(); ?>
                </div>
            <?php endif; ?>

            <div id="st_addons_for_elementor_license_settings_page" class="stafe-option-page group">

                <?php
                if (_is_stafe_pro_activated() == true) {
                    apply_filters('stafe_license_page', '');
                }

                ?>

                <?php if (!defined('STAFE_WL')) {
                    $this->footer_info();
                } ?>
            </div>
        </div>

        </div>

        <?php

        $this->script();

        ?>

    <?php
    }




    /**
     * Tabbable JavaScript codes & Initiate Color Picker
     *
     * This code uses localstorage for displaying active tabs
     */
    function script() {
    ?>
        <script>
            jQuery(document).ready(function() {
                jQuery('.stafe-no-result').removeClass('st-animation-shake');
            });

            function filterSearch(e) {
                var parentID = '#' + jQuery(e).data('id');
                var search = jQuery(parentID).find('.st-search-input').val().toLowerCase();

                jQuery(".stafe-options .stafe-option-item").filter(function() {
                    jQuery(this).toggle(jQuery(this).attr('data-widget-name').toLowerCase().indexOf(search) > -1)
                });

                if (!search) {
                    jQuery(parentID).find('.st-search-input').attr('st-filter-control', "");
                    jQuery(parentID).find('.stafe-widget-all').trigger('click');
                } else {
                    jQuery(parentID).find('.st-search-input').attr('st-filter-control', "filter: [data-widget-name*='" + search + "']");
                    jQuery(parentID).find('.st-search-input').removeClass('st-active'); // Thanks to Bar-Rabbas
                    jQuery(parentID).find('.st-search-input').trigger('click');
                }
            }

            jQuery('.stafe-options-parent').each(function(e, item) {
                var eachItem = '#' + jQuery(item).attr('id');
                jQuery(eachItem).on("beforeFilter", function() {
                    jQuery(eachItem).find('.stafe-no-result').removeClass('st-animation-shake');
                });

                jQuery(eachItem).on("afterFilter", function() {

                    var isElementVisible = false;
                    var i = 0;

                    if (jQuery(eachItem).closest(".stafe-options-parent").eq(i).is(":visible")) {} else {
                        isElementVisible = true;
                    }

                    while (!isElementVisible && i < jQuery(eachItem).find(".stafe-option-item").length) {
                        if (jQuery(eachItem).find(".stafe-option-item").eq(i).is(":visible")) {
                            isElementVisible = true;
                        }
                        i++;
                    }

                    if (isElementVisible === false) {
                        jQuery(eachItem).find('.stafe-no-result').addClass('st-animation-shake');
                    }
                });


            });


            jQuery('.stafe-widget-filter-nav li a').on('click', function(e) {
                jQuery(this).closest('.st-widget-filter-wrapper').find('.st-search-input').val('');
                jQuery(this).closest('.st-widget-filter-wrapper').find('.st-search-input').val('').attr('st-filter-control', '');
            });


            jQuery(document).ready(function($) {
                'use strict';

                function hashHandler() {
                    var $tab = jQuery('.st-addons-for-elementor-dashboard .st-tab');
                    if (window.location.hash) {
                        var hash = window.location.hash.substring(1);
                        spectraThemesAddons.tab($tab).show(jQuery('#st-' + hash).data('tab-index'));
                    }
                }

                jQuery(window).on('load', function() {
                    hashHandler();
                });

                window.addEventListener("hashchange", hashHandler, true);

                jQuery('.toplevel_page_st_addons_for_elementor_options > ul > li > a ').on('click', function(event) {
                    jQuery(this).parent().siblings().removeClass('current');
                    jQuery(this).parent().addClass('current');
                });

                jQuery('#st_addons_for_elementor_active_modules_page a.stafe-active-all-widget').click(function() {

                    jQuery('#st_addons_for_elementor_active_modules_page .stafe-option-item:not(.stafe-pro-inactive) .checkbox:visible').each(function() {
                        jQuery(this).attr('checked', 'checked').prop("checked", true);
                    });

                    jQuery(this).addClass('st-active');
                    jQuery('a.stafe-deactive-all-widget').removeClass('st-active');
                });

                jQuery('#st_addons_for_elementor_active_modules_page a.stafe-deactive-all-widget').click(function() {

                    jQuery('#st_addons_for_elementor_active_modules_page .stafe-option-item:not(.stafe-pro-inactive) .checkbox:visible').each(function() {
                        jQuery(this).removeAttr('checked');
                    });

                    jQuery(this).addClass('st-active');
                    jQuery('a.stafe-active-all-widget').removeClass('st-active');
                });

                jQuery('#st_addons_for_elementor_third_party_widget_page a.stafe-active-all-widget').click(function() {

                    jQuery('#st_addons_for_elementor_third_party_widget_page .checkbox:visible').each(function() {
                        jQuery(this).attr('checked', 'checked').prop("checked", true);
                    });

                    jQuery(this).addClass('st-active');
                    jQuery('a.stafe-deactive-all-widget').removeClass('st-active');
                });

                jQuery('#st_addons_for_elementor_third_party_widget_page a.stafe-deactive-all-widget').click(function() {

                    jQuery('#st_addons_for_elementor_third_party_widget_page .checkbox:visible').each(function() {
                        jQuery(this).removeAttr('checked');
                    });

                    jQuery(this).addClass('st-active');
                    jQuery('a.stafe-active-all-widget').removeClass('st-active');
                });

                jQuery('#st_addons_for_elementor_elementor_extend_page a.stafe-active-all-widget').click(function() {

                    jQuery('#st_addons_for_elementor_elementor_extend_page .checkbox:visible').each(function() {
                        jQuery(this).attr('checked', 'checked').prop("checked", true);
                    });

                    jQuery(this).addClass('st-active');
                    jQuery('a.stafe-deactive-all-widget').removeClass('st-active');
                });

                jQuery('#st_addons_for_elementor_elementor_extend_page a.stafe-deactive-all-widget').click(function() {

                    jQuery('#st_addons_for_elementor_elementor_extend_page .checkbox:visible').each(function() {
                        jQuery(this).removeAttr('checked');
                    });

                    jQuery(this).addClass('st-active');
                    jQuery('a.stafe-active-all-widget').removeClass('st-active');
                });

                jQuery('form.settings-save').submit(function(event) {
                    event.preventDefault();

                    spectraThemesAddons.notification({
                        message: '<div st-spinner></div> <?php esc_html_e('Please wait, Saving settings...', 'st-addons-for-elementor') ?>',
                        timeout: false
                    });

                    jQuery(this).ajaxSubmit({
                        success: function() {
                            spectraThemesAddons.notification.closeAll();
                            spectraThemesAddons.notification({
                                message: '<span class="dashicons dashicons-yes"></span> <?php esc_html_e('Settings Saved Successfully.', 'st-addons-for-elementor') ?>',
                                status: 'primary'
                            });
                        },
                        error: function(data) {
                            spectraThemesAddons.notification.closeAll();
                            spectraThemesAddons.notification({
                                message: '<span st-icon=\'icon: warning\'></span> <?php esc_html_e('Unknown error, make sure access is correct!', 'st-addons-for-elementor') ?>',
                                status: 'warning'
                            });
                        }
                    });

                    return false;
                });

                jQuery('#st_addons_for_elementor_active_modules_page .stafe-pro-inactive .checkbox').each(function() {
                    jQuery(this).removeAttr('checked');
                    jQuery(this).attr("disabled", true);
                });

            });
        </script>
    <?php
    }

    /**
     * Display Footer
     *
     * @access public
     * @return void
     */

    function footer_info() {
    ?>

        <div class="st-addons-for-elementor-footer-info st-margin-medium-top">

            <div class="st-grid ">

                <div class="st-width-auto@s stafe-setting-save-btn">



                </div>

                <div class="st-width-expand@s st-text-right">
                    <p class="">
                        All rights reserved by <a target="_blank" href="https://spectrathemes.com/">SpectraThemes.com</a>.
                    </p>
                </div>
            </div>

        </div>

<?php
    }

    /**
     * v6 Notice
     * This notice is very important to show minimum 3 to 5 next update released version.
     *
     * @access public
     */

    public function v6_activate_notice() {

        Notices::add_notice(
            [
                'id'               => 'version-6',
                'type'             => 'warning',
                'dismissible'      => true,
                'dismissible-time' => 43200,
                'message'          => __('There are very important changes in our major version <strong>v6.0.0</strong>. If you are continuing with the ST Addons For Elementor plugin from an earlier version of v6.0.0 then you must read this article carefully <a href="https://spectrathemes.com/knowledge-base/read-before-upgrading-to-st-addons-for-elementor-pro-version-6-0" target="_blank">from here</a>. <br> And if you are using this plugin from v6.0.0 there is nothing to worry about you. Thank you.', 'st-addons-for-elementor'),
            ]
        );
    }
    /**
     * 
     * Check mini-Cart of Elementor Activated or Not
     * It's better to not use multiple mini-Cart on the same time.
     * Transient Expire on 15 days
     *
     * @access public
     */

    public function el_use_mini_cart() {

        Notices::add_notice(
            [
                'id'               => 'stafe-el-use-mini-cart',
                'type'             => 'warning',
                'dismissible'      => true,
                'dismissible-time' => MONTH_IN_SECONDS / 2,
                'message'          => __('We can see you activated the <strong>Mini-Cart</strong> of Elementor Pro and also ST Addons For Elementor Pro. We will recommend you to choose one of them, otherwise you will get conflict. Thank you.', 'st-addons-for-elementor'),
            ]
        );
    }

    /**
     * Get all the pages
     *
     * @return array page names with key value pairs
     */
    function get_pages() {
        $pages         = get_pages();
        $pages_options = [];
        if ($pages) {
            foreach ($pages as $page) {
                $pages_options[$page->ID] = $page->post_title;
            }
        }

        return $pages_options;
    }
}

new StAddonsForElementor_Admin_Settings();
