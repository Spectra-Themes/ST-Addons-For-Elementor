jQuery(document).ready(function (t) {
    if (jQuery(".wrap").hasClass("st-addons-for-elementor-dashboard")) {
        function e() {
            var t = [],
                e = [];
            jQuery("#st_addons_for_elementor_active_modules_page input:checked").each(function () {
                e.push(jQuery(this).attr("name"));
            }),
                t.push(e.length);
            var a = [];
            jQuery("#st_addons_for_elementor_third_party_widget_page input:checked").each(function () {
                a.push(jQuery(this).attr("name"));
            }),
                t.push(a.length);
            var i = [];
            jQuery("#st_addons_for_elementor_elementor_extend_page input:checked").each(function () {
                i.push(jQuery(this).attr("name"));
            }),
                t.push(i.length),
                jQuery("#st-total-widgets-status").attr("data-value", t),
                jQuery("#st-total-widgets-status-core").text(t[0]),
                jQuery("#st-total-widgets-status-3rd").text(t[1]),
                jQuery("#st-total-widgets-status-extensions").text(t[2]),
                jQuery("#st-total-widgets-status-heading").text(t[0] + t[1] + t[2]);
        }
        e(),
            jQuery(".st-addons-for-elementor-settings-save-btn").on("click", function () {
                setTimeout(function () {
                    e();
                }, 2e3);
            });
        var a = jQuery("#st_addons_for_elementor_active_modules_page").find(".stafe-used-widget"),
            i = jQuery("#st_addons_for_elementor_active_modules_page").find(".stafe-options .stafe-used").length;
        a.text(i);
        var u = jQuery("#st_addons_for_elementor_active_modules_page").find(".stafe-unused-widget"),
            s = jQuery("#st_addons_for_elementor_active_modules_page").find(".stafe-options .stafe-unused").length;
        u.text(s);
        ["#st-db-total-status", "#st-total-widgets-status"].forEach(function (t) {
            const e = jQuery(t);
            var a = e.data("value");
            a = a.split(",");
            var i = e.data("labels");
            i = i.split(",");
            var u = e.data("bg");
            const s = {
                type: "doughnut",
                data: { datasets: [{ data: a, backgroundColor: (u = u.split(",")), borderWidth: 0 }] },
                options: { animation: { duration: 3e3 }, responsive: !0, maintainAspectRatio: !1, plugins: { legend: { display: !1 } }, title: { display: !1, text: e.data("label"), fontSize: 16, fontColor: "#333" }, hover: { mode: null } },
            };
            window.myChart instanceof Chart && window.myChart.destroy();
            new Chart(e, s);
        });
    }
    jQuery(".st-addons-for-elementor-notice.notice-error img").css({ "margin-right": "8px", "vertical-align": "middle" });
});
