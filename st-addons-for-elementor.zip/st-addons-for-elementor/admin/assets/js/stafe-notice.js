!(function (t) {
    "use strict";
    jQuery(document).ready(function () {
        t(".st-addons-for-elementor-notice.is-dismissible .notice-dismiss").on("click", function () {
            var i = t(this).parents(".st-addons-for-elementor-notice"),
                e = i.attr("id") || "",
                s = i.attr("dismissible-time") || "",
                a = i.attr("dismissible-meta") || "";
            t.ajax({ url: ajaxurl, type: "POST", data: { action: "st-addons-for-elementor-notices", id: e, meta: a, time: s, _wpnonce: StAddonsForElementorNoticeConfig.nonce } });
        });
    });
})(jQuery);
