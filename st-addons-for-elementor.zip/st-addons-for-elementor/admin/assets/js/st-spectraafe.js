/*! spectraThemesAddons 3.17.1 | https://www.getspectraafe.com | (c) 2014 - 2023 YOOtheme | MIT License */
!(function (t, e) {
    "object" == typeof exports && "undefined" != typeof module
        ? (module.exports = e())
        : "function" == typeof define && define.amd
        ? define("spectraafe", e)
        : ((t = "undefined" != typeof globalThis ? globalThis : t || self).spectraThemesAddons = e());
})(this, function () {
    "use strict";
    const { hasOwnProperty: t, toString: e } = Object.prototype;
    function i(e, i) {
        return t.call(e, i);
    }
    const n = /\B([A-Z])/g,
        s = Z((t) => t.replace(n, "-$1").toLowerCase()),
        o = /-(\w)/g,
        r = Z((t) => (t.charAt(0).toLowerCase() + t.slice(1)).replace(o, (t, e) => e.toUpperCase())),
        a = Z((t) => t.charAt(0).toUpperCase() + t.slice(1));
    function l(t, e) {
        var i;
        return null == (i = null == t ? void 0 : t.startsWith) ? void 0 : i.call(t, e);
    }
    function h(t, e) {
        var i;
        return null == (i = null == t ? void 0 : t.endsWith) ? void 0 : i.call(t, e);
    }
    function c(t, e) {
        var i;
        return null == (i = null == t ? void 0 : t.includes) ? void 0 : i.call(t, e);
    }
    function d(t, e) {
        var i;
        return null == (i = null == t ? void 0 : t.findIndex) ? void 0 : i.call(t, e);
    }
    const { isArray: u, from: f } = Array,
        { assign: p } = Object;
    function m(t) {
        return "function" == typeof t;
    }
    function g(t) {
        return null !== t && "object" == typeof t;
    }
    function v(t) {
        return "[object Object]" === e.call(t);
    }
    function b(t) {
        return g(t) && t === t.window;
    }
    function w(t) {
        return 9 === y(t);
    }
    function $(t) {
        return y(t) >= 1;
    }
    function x(t) {
        return 1 === y(t);
    }
    function y(t) {
        return !b(t) && g(t) && t.nodeType;
    }
    function S(t) {
        return "boolean" == typeof t;
    }
    function I(t) {
        return "string" == typeof t;
    }
    function C(t) {
        return "number" == typeof t;
    }
    function k(t) {
        return C(t) || (I(t) && !isNaN(t - parseFloat(t)));
    }
    function T(t) {
        return !(u(t) ? t.length : g(t) && Object.keys(t).length);
    }
    function E(t) {
        return void 0 === t;
    }
    function _(t) {
        return S(t) ? t : "true" === t || "1" === t || "" === t || ("false" !== t && "0" !== t && t);
    }
    function B(t) {
        const e = Number(t);
        return !isNaN(e) && e;
    }
    function P(t) {
        return parseFloat(t) || 0;
    }
    function A(t) {
        return D(t)[0];
    }
    function D(t) {
        return $(t) ? [t] : Array.from(t || []).filter($);
    }
    function M(t) {
        if (b(t)) return t;
        const e = w((t = A(t))) ? t : null == t ? void 0 : t.ownerDocument;
        return (null == e ? void 0 : e.defaultView) || window;
    }
    function O(t, e) {
        return t === e || (g(t) && g(e) && Object.keys(t).length === Object.keys(e).length && H(t, (t, i) => t === e[i]));
    }
    function N(t, e, i) {
        return t.replace(new RegExp(`${e}|${i}`, "g"), (t) => (t === e ? i : e));
    }
    function z(t) {
        return t[t.length - 1];
    }
    function H(t, e) {
        for (const i in t) if (!1 === e(t[i], i)) return !1;
        return !0;
    }
    function F(t, e) {
        return t.slice().sort(({ [e]: t = 0 }, { [e]: i = 0 }) => (t > i ? 1 : i > t ? -1 : 0));
    }
    function L(t, e) {
        return t.reduce((t, i) => t + P(m(e) ? e(i) : i[e]), 0);
    }
    function j(t, e) {
        const i = new Set();
        return t.filter(({ [e]: t }) => !i.has(t) && i.add(t));
    }
    function W(t, e) {
        return e.reduce((e, i) => ({ ...e, [i]: t[i] }), {});
    }
    function q(t, e = 0, i = 1) {
        return Math.min(Math.max(B(t) || 0, e), i);
    }
    function V() {}
    function R(...t) {
        return [
            ["bottom", "top"],
            ["right", "left"],
        ].every(([e, i]) => Math.min(...t.map(({ [e]: t }) => t)) - Math.max(...t.map(({ [i]: t }) => t)) > 0);
    }
    function U(t, e) {
        return t.x <= e.right && t.x >= e.left && t.y <= e.bottom && t.y >= e.top;
    }
    function X(t, e, i) {
        const n = "width" === e ? "height" : "width";
        return { [n]: t[e] ? Math.round((i * t[n]) / t[e]) : t[n], [e]: i };
    }
    function Y(t, e) {
        t = { ...t };
        for (const i in t) t = t[i] > e[i] ? X(t, i, e[i]) : t;
        return t;
    }
    const J = {
        ratio: X,
        contain: Y,
        cover: function (t, e) {
            t = Y(t, e);
            for (const i in t) t = t[i] < e[i] ? X(t, i, e[i]) : t;
            return t;
        },
    };
    function G(t, e, i = 0, n = !1) {
        e = D(e);
        const { length: s } = e;
        return s ? ((t = k(t) ? B(t) : "next" === t ? i + 1 : "previous" === t ? i - 1 : "last" === t ? s - 1 : e.indexOf(A(t))), n ? q(t, 0, s - 1) : (t %= s) < 0 ? t + s : t) : -1;
    }
    function Z(t) {
        const e = Object.create(null);
        return (i) => e[i] || (e[i] = t(i));
    }
    function K(t, e, i) {
        var n;
        if (g(e)) for (const i in e) K(t, i, e[i]);
        else {
            if (E(i)) return null == (n = A(t)) ? void 0 : n.getAttribute(e);
            for (const n of D(t)) m(i) && (i = i.call(n, K(n, e))), null === i ? tt(n, e) : n.setAttribute(e, i);
        }
    }
    function Q(t, e) {
        return D(t).some((t) => t.hasAttribute(e));
    }
    function tt(t, e) {
        D(t).forEach((t) => t.removeAttribute(e));
    }
    function et(t, e) {
        for (const i of [e, `data-${e}`]) if (Q(t, i)) return K(t, i);
    }
    function it(t, ...e) {
        for (const i of D(t)) {
            const t = lt(e).filter((t) => !rt(i, t));
            t.length && i.classList.add(...t);
        }
    }
    function nt(t, ...e) {
        for (const i of D(t)) {
            const t = lt(e).filter((t) => rt(i, t));
            t.length && i.classList.remove(...t);
        }
    }
    function st(t, e) {
        e = new RegExp(e);
        for (const i of D(t)) i.classList.remove(...f(i.classList).filter((t) => t.match(e)));
    }
    function ot(t, e, i) {
        (i = lt(i)), nt(t, (e = lt(e).filter((t) => !c(i, t)))), it(t, i);
    }
    function rt(t, e) {
        return ([e] = lt(e)), D(t).some((t) => t.classList.contains(e));
    }
    function at(t, e, i) {
        const n = lt(e);
        E(i) || (i = !!i);
        for (const e of D(t)) for (const t of n) e.classList.toggle(t, i);
    }
    function lt(t) {
        return u(t) ? t.map(lt).flat() : String(t).split(/[ ,]/).filter(Boolean);
    }
    const ht = { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 };
    function ct(t) {
        return D(t).some((t) => ht[t.tagName.toLowerCase()]);
    }
    function dt(t) {
        return D(t).some((t) => t.offsetWidth || t.offsetHeight || t.getClientRects().length);
    }
    const ut = "input,select,textarea,button";
    function ft(t) {
        return D(t).some((t) => bt(t, ut));
    }
    const pt = `${ut},a[href],[tabindex]`;
    function mt(t) {
        return bt(t, pt);
    }
    function gt(t) {
        var e;
        return null == (e = A(t)) ? void 0 : e.parentElement;
    }
    function vt(t, e) {
        return D(t).filter((t) => bt(t, e));
    }
    function bt(t, e) {
        return D(t).some((t) => t.matches(e));
    }
    function wt(t, e) {
        var i;
        return null == (i = A(t)) ? void 0 : i.closest(l(e, ">") ? e.slice(1) : e);
    }
    function $t(t, e) {
        return I(e) ? !!wt(t, e) : A(e).contains(A(t));
    }
    function xt(t, e) {
        const i = [];
        for (; (t = gt(t)); ) (e && !bt(t, e)) || i.push(t);
        return i;
    }
    function yt(t, e) {
        const i = (t = A(t)) ? f(t.children) : [];
        return e ? vt(i, e) : i;
    }
    function St(t, e) {
        return e ? D(t).indexOf(A(e)) : yt(gt(t)).indexOf(t);
    }
    function It(t) {
        return (t = A(t)) && ["origin", "pathname", "search"].every((e) => t[e] === location[e]);
    }
    function Ct(t) {
        if (It(t)) {
            t = A(t);
            const e = decodeURIComponent(t.hash).substring(1);
            return document.getElementById(e) || document.getElementsByName(e)[0];
        }
    }
    function kt(t, e) {
        return Et(t, At(t, e));
    }
    function Tt(t, e) {
        return _t(t, At(t, e));
    }
    function Et(t, e) {
        return A(Ot(t, A(e), "querySelector"));
    }
    function _t(t, e) {
        return D(Ot(t, A(e), "querySelectorAll"));
    }
    const Bt = /(^|[^\\],)\s*[!>+~-]/,
        Pt = Z((t) => t.match(Bt));
    function At(t, e = document) {
        return (I(t) && Pt(t)) || w(e) ? e : e.ownerDocument;
    }
    const Dt = /([!>+~-])(?=\s+[!>+~-]|\s*$)/g,
        Mt = Z((t) => t.replace(Dt, "$1 *"));
    function Ot(t, e = document, i) {
        if (!t || !I(t)) return t;
        if (((t = Mt(t)), Pt(t))) {
            const i = zt(t);
            t = "";
            for (let n of i) {
                let s = e;
                if ("!" === n[0]) {
                    const t = n.substr(1).trim().split(" ");
                    if (((s = wt(gt(e), t[0])), (n = t.slice(1).join(" ").trim()), !n.length && 1 === i.length)) return s;
                }
                if ("-" === n[0]) {
                    const t = n.substr(1).trim().split(" "),
                        i = (s || e).previousElementSibling;
                    (s = bt(i, n.substr(1)) ? i : null), (n = t.slice(1).join(" "));
                }
                s && (t += `${t ? "," : ""}${Ht(s)} ${n}`);
            }
            e = document;
        }
        try {
            return e[i](t);
        } catch (t) {
            return null;
        }
    }
    const Nt = /.*?[^\\](?:,|$)/g,
        zt = Z((t) => t.match(Nt).map((t) => t.replace(/,$/, "").trim()));
    function Ht(t) {
        const e = [];
        for (; t.parentNode; ) {
            const i = K(t, "id");
            if (i) {
                e.unshift(`#${Ft(i)}`);
                break;
            }
            {
                let { tagName: i } = t;
                "HTML" !== i && (i += `:nth-child(${St(t) + 1})`), e.unshift(i), (t = t.parentNode);
            }
        }
        return e.join(" > ");
    }
    function Ft(t) {
        return I(t) ? CSS.escape(t) : "";
    }
    function Lt(...t) {
        let [e, i, n, s, o = !1] = Rt(t);
        s.length > 1 &&
            (s = (function (t) {
                return (e) => (u(e.detail) ? t(e, ...e.detail) : t(e));
            })(s)),
            (null == o ? void 0 : o.self) &&
                (s = (function (t) {
                    return function (e) {
                        if (e.target === e.currentTarget || e.target === e.current) return t.call(null, e);
                    };
                })(s)),
            n &&
                (s = (function (t, e) {
                    return (i) => {
                        const n =
                            ">" === t[0]
                                ? _t(t, i.currentTarget)
                                      .reverse()
                                      .filter((t) => $t(i.target, t))[0]
                                : wt(i.target, t);
                        n && ((i.current = n), e.call(this, i), delete i.current);
                    };
                })(n, s));
        for (const t of i) for (const i of e) i.addEventListener(t, s, o);
        return () => jt(e, i, s, o);
    }
    function jt(...t) {
        let [e, i, , n, s = !1] = Rt(t);
        for (const t of i) for (const i of e) i.removeEventListener(t, n, s);
    }
    function Wt(...t) {
        const [e, i, n, s, o = !1, r] = Rt(t),
            a = Lt(
                e,
                i,
                n,
                (t) => {
                    const e = !r || r(t);
                    e && (a(), s(t, e));
                },
                o
            );
        return a;
    }
    function qt(t, e, i) {
        return Yt(t).every((t) => t.dispatchEvent(Vt(e, !0, !0, i)));
    }
    function Vt(t, e = !0, i = !1, n) {
        return I(t) && (t = new CustomEvent(t, { bubbles: e, cancelable: i, detail: n })), t;
    }
    function Rt(t) {
        return (t[0] = Yt(t[0])), I(t[1]) && (t[1] = t[1].split(" ")), m(t[2]) && t.splice(2, 0, !1), t;
    }
    function Ut(t) {
        return t && "addEventListener" in t;
    }
    function Xt(t) {
        return Ut(t) ? t : A(t);
    }
    function Yt(t) {
        return u(t) ? t.map(Xt).filter(Boolean) : I(t) ? _t(t) : Ut(t) ? [t] : D(t);
    }
    function Jt(t) {
        return "touch" === t.pointerType || !!t.touches;
    }
    function Gt(t) {
        var e, i;
        const { clientX: n, clientY: s } = (null == (e = t.touches) ? void 0 : e[0]) || (null == (i = t.changedTouches) ? void 0 : i[0]) || t;
        return { x: n, y: s };
    }
    const Zt = {
        "animation-iteration-count": !0,
        "column-count": !0,
        "fill-opacity": !0,
        "flex-grow": !0,
        "flex-shrink": !0,
        "font-weight": !0,
        "line-height": !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        "stroke-dasharray": !0,
        "stroke-dashoffset": !0,
        widows: !0,
        "z-index": !0,
        zoom: !0,
    };
    function Kt(t, e, i, n) {
        const s = D(t);
        for (const t of s)
            if (I(e)) {
                if (((e = Qt(e)), E(i))) return getComputedStyle(t).getPropertyValue(e);
                t.style.setProperty(e, k(i) && !Zt[e] ? `${i}px` : i || C(i) ? i : "", n);
            } else {
                if (u(e)) {
                    const i = {};
                    for (const n of e) i[n] = Kt(t, n);
                    return i;
                }
                g(e) && ((n = i), H(e, (e, i) => Kt(t, i, e, n)));
            }
        return s[0];
    }
    const Qt = Z((t) =>
        (function (t) {
            if (l(t, "--")) return t;
            t = s(t);
            const { style: e } = document.documentElement;
            if (t in e) return t;
            for (const i of ["webkit", "moz"]) {
                const n = `-${i}-${t}`;
                if (n in e) return n;
            }
        })(t)
    );
    const te = "st-transition",
        ee = "transitionend",
        ie = "transitioncanceled";
    const ne = {
            start: function (t, e, i = 400, n = "linear") {
                return (
                    (i = Math.round(i)),
                    Promise.all(
                        D(t).map(
                            (t) =>
                                new Promise((s, o) => {
                                    for (const i in e) {
                                        const e = Kt(t, i);
                                        "" === e && Kt(t, i, e);
                                    }
                                    const r = setTimeout(() => qt(t, ee), i);
                                    Wt(
                                        t,
                                        [ee, ie],
                                        ({ type: e }) => {
                                            clearTimeout(r), nt(t, te), Kt(t, { transitionProperty: "", transitionDuration: "", transitionTimingFunction: "" }), e === ie ? o() : s(t);
                                        },
                                        { self: !0 }
                                    ),
                                        it(t, te),
                                        Kt(t, { transitionProperty: Object.keys(e).map(Qt).join(","), transitionDuration: `${i}ms`, transitionTimingFunction: n, ...e });
                                })
                        )
                    )
                );
            },
            async stop(t) {
                qt(t, ee), await Promise.resolve();
            },
            async cancel(t) {
                qt(t, ie), await Promise.resolve();
            },
            inProgress: (t) => rt(t, te),
        },
        se = "st-animation-",
        oe = "animationend",
        re = "animationcanceled";
    function ae(t, e, i = 200, n, s) {
        return Promise.all(
            D(t).map(
                (t) =>
                    new Promise((o, r) => {
                        qt(t, re);
                        const a = setTimeout(() => qt(t, oe), i);
                        Wt(
                            t,
                            [oe, re],
                            ({ type: e }) => {
                                clearTimeout(a), e === re ? r() : o(t), Kt(t, "animationDuration", ""), st(t, `${se}\\S*`);
                            },
                            { self: !0 }
                        ),
                            Kt(t, "animationDuration", `${i}ms`),
                            it(t, e, se + (s ? "leave" : "enter")),
                            l(e, se) && (n && it(t, `st-transform-origin-${n}`), s && it(t, `${se}reverse`));
                    })
            )
        );
    }
    const le = new RegExp(`${se}(enter|leave)`),
        he = {
            in: ae,
            out: (t, e, i, n) => ae(t, e, i, n, !0),
            inProgress: (t) => le.test(K(t, "class")),
            cancel(t) {
                qt(t, re);
            },
        };
    function ce(t, ...e) {
        return e.some((e) => {
            var i;
            return (null == (i = null == t ? void 0 : t.tagName) ? void 0 : i.toLowerCase()) === e.toLowerCase();
        });
    }
    function de(t) {
        return ((t = ke(t)).innerHTML = ""), t;
    }
    function ue(t, e) {
        return E(e) ? ke(t).innerHTML : pe(de(t), e);
    }
    const fe = ve("prepend"),
        pe = ve("append"),
        me = ve("before"),
        ge = ve("after");
    function ve(t) {
        return function (e, i) {
            var n;
            const s = D(I(i) ? Se(i) : i);
            return null == (n = ke(e)) || n[t](...s), Ie(s);
        };
    }
    function be(t) {
        D(t).forEach((t) => t.remove());
    }
    function we(t, e) {
        for (e = A(me(t, e)); e.firstChild; ) e = e.firstChild;
        return pe(e, t), e;
    }
    function $e(t, e) {
        return D(D(t).map((t) => (t.hasChildNodes() ? we(f(t.childNodes), e) : pe(t, e))));
    }
    function xe(t) {
        D(t)
            .map(gt)
            .filter((t, e, i) => i.indexOf(t) === e)
            .forEach((t) => t.replaceWith(...t.childNodes));
    }
    const ye = /^<(\w+)\s*\/?>(?:<\/\1>)?$/;
    function Se(t) {
        const e = ye.exec(t);
        if (e) return document.createElement(e[1]);
        const i = document.createElement("template");
        return (i.innerHTML = t.trim()), Ie(i.content.childNodes);
    }
    function Ie(t) {
        return t.length > 1 ? t : t[0];
    }
    function Ce(t, e) {
        if (x(t))
            for (e(t), t = t.firstElementChild; t; ) {
                const i = t.nextElementSibling;
                Ce(t, e), (t = i);
            }
    }
    function ke(t, e) {
        return Ee(t) ? A(Se(t)) : Et(t, e);
    }
    function Te(t, e) {
        return Ee(t) ? D(Se(t)) : _t(t, e);
    }
    function Ee(t) {
        return I(t) && l(t.trim(), "<");
    }
    const _e = { width: ["left", "right"], height: ["top", "bottom"] };
    function Be(t) {
        const e = x(t) ? A(t).getBoundingClientRect() : { height: Me(t), width: Oe(t), top: 0, left: 0 };
        return { height: e.height, width: e.width, top: e.top, left: e.left, bottom: e.top + e.height, right: e.left + e.width };
    }
    function Pe(t, e) {
        e && Kt(t, { left: 0, top: 0 });
        const i = Be(t);
        if (t) {
            const { scrollY: e, scrollX: n } = M(t),
                s = { height: e, width: n };
            for (const t in _e) for (const e of _e[t]) i[e] += s[t];
        }
        if (!e) return i;
        for (const n of ["left", "top"]) Kt(t, n, e[n] - i[n]);
    }
    function Ae(t) {
        let { top: e, left: i } = Pe(t);
        const {
            ownerDocument: { body: n, documentElement: s },
            offsetParent: o,
        } = A(t);
        let r = o || s;
        for (; r && (r === n || r === s) && "static" === Kt(r, "position"); ) r = r.parentNode;
        if (x(r)) {
            const t = Pe(r);
            (e -= t.top + P(Kt(r, "borderTopWidth"))), (i -= t.left + P(Kt(r, "borderLeftWidth")));
        }
        return { top: e - P(Kt(t, "marginTop")), left: i - P(Kt(t, "marginLeft")) };
    }
    function De(t) {
        const e = [(t = A(t)).offsetTop, t.offsetLeft];
        for (; (t = t.offsetParent); )
            if (((e[0] += t.offsetTop + P(Kt(t, "borderTopWidth"))), (e[1] += t.offsetLeft + P(Kt(t, "borderLeftWidth"))), "fixed" === Kt(t, "position"))) {
                const i = M(t);
                return (e[0] += i.scrollY), (e[1] += i.scrollX), e;
            }
        return e;
    }
    const Me = Ne("height"),
        Oe = Ne("width");
    function Ne(t) {
        const e = a(t);
        return (i, n) => {
            if (E(n)) {
                if (b(i)) return i[`inner${e}`];
                if (w(i)) {
                    const t = i.documentElement;
                    return Math.max(t[`offset${e}`], t[`scroll${e}`]);
                }
                return (n = "auto" === (n = Kt((i = A(i)), t)) ? i[`offset${e}`] : P(n) || 0) - ze(i, t);
            }
            return Kt(i, t, n || 0 === n ? +n + ze(i, t) + "px" : "");
        };
    }
    function ze(t, e, i = "border-box") {
        return Kt(t, "boxSizing") === i ? L(_e[e].map(a), (e) => P(Kt(t, `padding${e}`)) + P(Kt(t, `border${e}Width`))) : 0;
    }
    function He(t) {
        for (const e in _e) for (const i in _e[e]) if (_e[e][i] === t) return _e[e][1 - i];
        return t;
    }
    function Fe(t, e = "width", i = window, n = !1) {
        return I(t)
            ? L(je(t), (t) => {
                  const s = qe(t);
                  return s
                      ? (function (t, e) {
                            return (t * P(e)) / 100;
                        })(
                            "vh" === s
                                ? (function () {
                                      if (Ve) return Ve;
                                      Re || ((Re = ke("<div>")), Kt(Re, { height: "100vh", position: "fixed" }), Lt(window, "resize", () => (Ve = null)));
                                      return pe(document.body, Re), (Ve = Re.clientHeight), be(Re), Ve;
                                  })()
                                : "vw" === s
                                ? Oe(M(i))
                                : n
                                ? i[`offset${a(e)}`]
                                : Be(i)[e],
                            t
                        )
                      : t;
              })
            : P(t);
    }
    const Le = /-?\d+(?:\.\d+)?(?:v[wh]|%|px)?/g,
        je = Z((t) => t.toString().replace(/\s/g, "").match(Le) || []),
        We = /(?:v[hw]|%)$/,
        qe = Z((t) => (t.match(We) || [])[0]);
    let Ve, Re;
    const Ue = "undefined" != typeof window,
        Xe = Ue && "rtl" === document.dir,
        Ye = Ue && "ontouchstart" in window,
        Je = Ue && window.PointerEvent,
        Ge = Je ? "pointerdown" : Ye ? "touchstart" : "mousedown",
        Ze = Je ? "pointermove" : Ye ? "touchmove" : "mousemove",
        Ke = Je ? "pointerup" : Ye ? "touchend" : "mouseup",
        Qe = Je ? "pointerenter" : Ye ? "" : "mouseenter",
        ti = Je ? "pointerleave" : Ye ? "" : "mouseleave",
        ei = Je ? "pointercancel" : "touchcancel",
        ii = {
            reads: [],
            writes: [],
            read(t) {
                return this.reads.push(t), oi(), t;
            },
            write(t) {
                return this.writes.push(t), oi(), t;
            },
            clear(t) {
                ai(this.reads, t), ai(this.writes, t);
            },
            flush: ni,
        };
    function ni(t) {
        ri(ii.reads), ri(ii.writes.splice(0)), (ii.scheduled = !1), (ii.reads.length || ii.writes.length) && oi(t + 1);
    }
    const si = 4;
    function oi(t) {
        ii.scheduled || ((ii.scheduled = !0), t && t < si ? Promise.resolve().then(() => ni(t)) : requestAnimationFrame(() => ni(1)));
    }
    function ri(t) {
        let e;
        for (; (e = t.shift()); )
            try {
                e();
            } catch (t) {
                console.error(t);
            }
    }
    function ai(t, e) {
        const i = t.indexOf(e);
        return ~i && t.splice(i, 1);
    }
    function li() {}
    function hi(t, e, i = {}, { intersecting: n = !0 } = {}) {
        const s = new IntersectionObserver(
            n
                ? (t, i) => {
                      t.some((t) => t.isIntersecting) && e(t, i);
                  }
                : e,
            i
        );
        for (const e of D(t)) s.observe(e);
        return s;
    }
    li.prototype = {
        positions: [],
        init() {
            let t;
            (this.positions = []),
                (this.unbind = Lt(document, "mousemove", (e) => (t = Gt(e)))),
                (this.interval = setInterval(() => {
                    t && (this.positions.push(t), this.positions.length > 5 && this.positions.shift());
                }, 50));
        },
        cancel() {
            var t;
            null == (t = this.unbind) || t.call(this), clearInterval(this.interval);
        },
        movesTo(t) {
            if (this.positions.length < 2) return !1;
            const e = t.getBoundingClientRect(),
                { left: i, right: n, top: s, bottom: o } = e,
                [r] = this.positions,
                a = z(this.positions),
                l = [r, a];
            if (U(a, e)) return !1;
            return [
                [
                    { x: i, y: s },
                    { x: n, y: o },
                ],
                [
                    { x: i, y: o },
                    { x: n, y: s },
                ],
            ].some((t) => {
                const i = (function ([{ x: t, y: e }, { x: i, y: n }], [{ x: s, y: o }, { x: r, y: a }]) {
                    const l = (a - o) * (i - t) - (r - s) * (n - e);
                    if (0 === l) return !1;
                    const h = ((r - s) * (e - o) - (a - o) * (t - s)) / l;
                    if (h < 0) return !1;
                    return { x: t + h * (i - t), y: e + h * (n - e) };
                })(l, t);
                return i && U(i, e);
            });
        },
    };
    const ci = Ue && window.ResizeObserver;
    function di(t, e, i = { box: "border-box" }) {
        if (ci) return pi(ResizeObserver, t, e, i);
        const n = [Lt(window, "load resize", e), Lt(document, "loadedmetadata load", e, !0)];
        return { disconnect: () => n.map((t) => t()) };
    }
    function ui(t) {
        return { disconnect: Lt([window, window.visualViewport], "resize", t) };
    }
    function fi(t, e, i) {
        return pi(MutationObserver, t, e, i);
    }
    function pi(t, e, i, n) {
        const s = new t(i);
        for (const t of D(e)) s.observe(t, n);
        return s;
    }
    function mi(t) {
        $i(t) && Si(t, { func: "playVideo", method: "play" }), wi(t) && t.play();
    }
    function gi(t) {
        $i(t) && Si(t, { func: "pauseVideo", method: "pause" }), wi(t) && t.pause();
    }
    function vi(t) {
        $i(t) && Si(t, { func: "mute", method: "setVolume", value: 0 }), wi(t) && (t.muted = !0);
    }
    function bi(t) {
        return wi(t) || $i(t);
    }
    function wi(t) {
        return ce(t, "video");
    }
    function $i(t) {
        return ce(t, "iframe") && (xi(t) || yi(t));
    }
    function xi(t) {
        return !!t.src.match(/\/\/.*?youtube(-nocookie)?\.[a-z]+\/(watch\?v=[^&\s]+|embed)|youtu\.be\/.*/);
    }
    function yi(t) {
        return !!t.src.match(/vimeo\.com\/video\/.*/);
    }
    async function Si(t, e) {
        await (function (t) {
            if (t[Ci]) return t[Ci];
            const e = xi(t),
                i = yi(t),
                n = ++ki;
            let s;
            return (t[Ci] = new Promise((o) => {
                e &&
                    Wt(t, "load", () => {
                        const e = () => Ii(t, { event: "listening", id: n });
                        (s = setInterval(e, 100)), e();
                    }),
                    Wt(window, "message", o, !1, ({ data: t }) => {
                        try {
                            return (t = JSON.parse(t)), (e && (null == t ? void 0 : t.id) === n && "onReady" === t.event) || (i && Number(null == t ? void 0 : t.player_id) === n);
                        } catch (t) {}
                    }),
                    (t.src = `${t.src}${c(t.src, "?") ? "&" : "?"}${e ? "enablejsapi=1" : `api=1&player_id=${n}`}`);
            }).then(() => clearInterval(s)));
        })(t),
            Ii(t, e);
    }
    function Ii(t, e) {
        t.contentWindow.postMessage(JSON.stringify({ event: "command", ...e }), "*");
    }
    const Ci = "_ukPlayer";
    let ki = 0;
    function Ti(t, e = 0, i = 0) {
        return (
            !!dt(t) &&
            R(
                ...Ai(t)
                    .map((t) => {
                        const { top: n, left: s, bottom: o, right: r } = Di(t);
                        return { top: n - e, left: s - i, bottom: o + e, right: r + i };
                    })
                    .concat(Pe(t))
            )
        );
    }
    function Ei(t, { offset: e = 0 } = {}) {
        const i = dt(t) ? Bi(t, !1, ["hidden"]) : [];
        return i.reduce(
            (n, s, o) => {
                const { scrollTop: r, scrollHeight: a, offsetHeight: l } = s,
                    h = Di(s),
                    c = a - h.height,
                    { height: d, top: u } = i[o - 1] ? Di(i[o - 1]) : Pe(t);
                let f = Math.ceil(u - h.top - e + r);
                return (
                    e > 0 && l < d + e ? (f += e) : (e = 0),
                    f > c ? ((e -= f - c), (f = c)) : f < 0 && ((e -= f), (f = 0)),
                    () =>
                        (function (t, e, n, s) {
                            return new Promise((o) => {
                                const r = t.scrollTop,
                                    a = ((l = Math.abs(e)), 40 * Math.pow(l, 0.375));
                                var l;
                                const h = Date.now(),
                                    c = Pe(n).top;
                                let d = 0,
                                    u = 15;
                                !(function l() {
                                    const f = ((p = q((Date.now() - h) / a)), 0.5 * (1 - Math.cos(Math.PI * p)));
                                    var p;
                                    let m = 0;
                                    if (i[0] === t && r + e < s) {
                                        m = Pe(n).top - c;
                                        const t = (g = n).ownerDocument.elementsFromPoint(0, 0).find((t) => ["fixed", "sticky"].includes(Kt(t, "position")) && !t.contains(g));
                                        m -= t ? Pe(t).height : 0;
                                    }
                                    var g;
                                    (t.scrollTop = Math[e + m > 0 ? "max" : "min"](t.scrollTop, r + (e + m) * f)), 1 !== f || (d !== m && u--) ? ((d = m), requestAnimationFrame(l)) : o();
                                })();
                            });
                        })(s, f - r, t, c).then(n)
                );
            },
            () => Promise.resolve()
        )();
    }
    function _i(t, e = 0, i = 0) {
        if (!dt(t)) return 0;
        const n = Pi(t, !0),
            { scrollHeight: s, scrollTop: o } = n,
            { height: r } = Di(n),
            a = s - r,
            l = De(t)[0] - De(n)[0],
            h = Math.max(0, l - r + e);
        return q((o - h) / (Math.min(a, l + t.offsetHeight - i) - h));
    }
    function Bi(t, e = !1, i = []) {
        const n = Mi(t);
        let s = xt(t).reverse();
        s = s.slice(s.indexOf(n) + 1);
        const o = d(s, (t) => "fixed" === Kt(t, "position"));
        return (
            ~o && (s = s.slice(o)),
            [n]
                .concat(
                    s.filter(
                        (t) =>
                            Kt(t, "overflow")
                                .split(" ")
                                .some((t) => c(["auto", "scroll", ...i], t)) &&
                            (!e || t.scrollHeight > Di(t).height)
                    )
                )
                .reverse()
        );
    }
    function Pi(...t) {
        return Bi(...t)[0];
    }
    function Ai(t) {
        return Bi(t, !1, ["hidden", "clip"]);
    }
    function Di(t) {
        const e = M(t),
            {
                visualViewport: i,
                document: { documentElement: n },
            } = e;
        let s = t === Mi(t) ? e : t;
        if (b(s) && i) {
            let { height: t, width: e, scale: n, pageTop: s, pageLeft: o } = i;
            return (t = Math.round(t * n)), (e = Math.round(e * n)), { height: t, width: e, top: s, left: o, bottom: s + t, right: o + e };
        }
        let o = Pe(s);
        if ("inline" === Kt(s, "display")) return o;
        for (let [t, e, i, r] of [
            ["width", "x", "left", "right"],
            ["height", "y", "top", "bottom"],
        ]) {
            b(s) ? (s = n) : (o[i] += P(Kt(s, `border-${i}-width`)));
            const l = o[t] % 1;
            (o[t] = o[e] = s[`client${a(t)}`] - (l ? (l < 0.5 ? -l : 1 - l) : 0)), (o[r] = o[t] + o[i]);
        }
        return o;
    }
    function Mi(t) {
        return M(t).document.scrollingElement;
    }
    const Oi = [
        ["width", "x", "left", "right"],
        ["height", "y", "top", "bottom"],
    ];
    function Ni(t, e, i) {
        (i = { attach: { element: ["left", "top"], target: ["left", "top"], ...i.attach }, offset: [0, 0], placement: [], ...i }), u(e) || (e = [e, e]), Pe(t, zi(t, e, i));
    }
    function zi(t, e, i) {
        const n = Hi(t, e, i),
            { boundary: s, viewportOffset: o = 0, placement: r } = i;
        let a = n;
        for (const [l, [h, , c, d]] of Object.entries(Oi)) {
            const u = ji(t, e[l], o, s, l);
            if (Ri(n, u, l)) continue;
            let f = 0;
            if ("flip" === r[l]) {
                const s = i.attach.target[l];
                if ((s === d && n[d] <= u[d]) || (s === c && n[c] >= u[c])) continue;
                f = Ui(t, e, i, l)[c] - n[c];
                const r = Wi(t, e[l], o, l);
                if (!Ri(Fi(n, f, l), r, l)) {
                    if (Ri(n, r, l)) continue;
                    if (i.recursion) return !1;
                    const s = Xi(t, e, i);
                    if (s && Ri(s, r, 1 - l)) return s;
                    continue;
                }
            } else if ("shift" === r[l]) {
                const t = Pe(e[l]),
                    { offset: s } = i;
                f = q(q(n[c], u[c], u[d] - n[h]), t[c] - n[h] + s[l], t[d] - s[l]) - n[c];
            }
            a = Fi(a, f, l);
        }
        return a;
    }
    function Hi(t, e, i) {
        let { attach: n, offset: s } = { attach: { element: ["left", "top"], target: ["left", "top"], ...i.attach }, offset: [0, 0], ...i },
            o = Pe(t);
        for (const [t, [i, , r, a]] of Object.entries(Oi)) {
            const l = n.target[t] === n.element[t] ? Di(e[t]) : Pe(e[t]);
            o = Fi(o, l[r] - o[r] + Li(n.target[t], a, l[i]) - Li(n.element[t], a, o[i]) + +s[t], t);
        }
        return o;
    }
    function Fi(t, e, i) {
        const [, n, s, o] = Oi[i],
            r = { ...t };
        return (r[s] = t[n] = t[s] + e), (r[o] += e), r;
    }
    function Li(t, e, i) {
        return "center" === t ? i / 2 : t === e ? i : 0;
    }
    function ji(t, e, i, n, s) {
        let o = Vi(...qi(t, e).map(Di));
        return i && ((o[Oi[s][2]] += i), (o[Oi[s][3]] -= i)), n && (o = Vi(o, Pe(u(n) ? n[s] : n))), o;
    }
    function Wi(t, e, i, n) {
        const [s, o, r, l] = Oi[n],
            [h] = qi(t, e),
            c = Di(h);
        return ["auto", "scroll"].includes(Kt(h, `overflow-${o}`)) && ((c[r] -= h[`scroll${a(r)}`]), (c[l] = c[r] + h[`scroll${a(s)}`])), (c[r] += i), (c[l] -= i), c;
    }
    function qi(t, e) {
        return Ai(e).filter((e) => $t(t, e));
    }
    function Vi(...t) {
        let e = {};
        for (const i of t) for (const [, , t, n] of Oi) (e[t] = Math.max(e[t] || 0, i[t])), (e[n] = Math.min(...[e[n], i[n]].filter(Boolean)));
        return e;
    }
    function Ri(t, e, i) {
        const [, , n, s] = Oi[i];
        return t[n] >= e[n] && t[s] <= e[s];
    }
    function Ui(t, e, { offset: i, attach: n }, s) {
        return Hi(t, e, { attach: { element: Yi(n.element, s), target: Yi(n.target, s) }, offset: Gi(i, s) });
    }
    function Xi(t, e, i) {
        return zi(t, e, { ...i, attach: { element: i.attach.element.map(Ji).reverse(), target: i.attach.target.map(Ji).reverse() }, offset: i.offset.reverse(), placement: i.placement.reverse(), recursion: !0 });
    }
    function Yi(t, e) {
        const i = [...t],
            n = Oi[e].indexOf(t[e]);
        return ~n && (i[e] = Oi[e][1 - (n % 2) + 2]), i;
    }
    function Ji(t) {
        for (let e = 0; e < Oi.length; e++) {
            const i = Oi[e].indexOf(t);
            if (~i) return Oi[1 - e][(i % 2) + 2];
        }
    }
    function Gi(t, e) {
        return ((t = [...t])[e] *= -1), t;
    }
    var Zi = Object.freeze({
            __proto__: null,
            $: ke,
            $$: Te,
            Animation: he,
            Dimensions: J,
            MouseTracker: li,
            Transition: ne,
            addClass: it,
            after: ge,
            append: pe,
            apply: Ce,
            assign: p,
            attr: K,
            before: me,
            boxModelAdjust: ze,
            camelize: r,
            children: yt,
            clamp: q,
            closest: wt,
            createEvent: Vt,
            css: Kt,
            data: et,
            dimensions: Be,
            each: H,
            empty: de,
            endsWith: h,
            escape: Ft,
            fastdom: ii,
            filter: vt,
            find: Et,
            findAll: _t,
            findIndex: d,
            flipPosition: He,
            fragment: Se,
            getEventPos: Gt,
            getIndex: G,
            getTargetedElement: Ct,
            hasAttr: Q,
            hasClass: rt,
            hasOwn: i,
            hasTouch: Ye,
            height: Me,
            html: ue,
            hyphenate: s,
            inBrowser: Ue,
            includes: c,
            index: St,
            intersectRect: R,
            isArray: u,
            isBoolean: S,
            isDocument: w,
            isElement: x,
            isEmpty: T,
            isEqual: O,
            isFocusable: mt,
            isFunction: m,
            isInView: Ti,
            isInput: ft,
            isNode: $,
            isNumber: C,
            isNumeric: k,
            isObject: g,
            isPlainObject: v,
            isRtl: Xe,
            isSameSiteAnchor: It,
            isString: I,
            isTag: ce,
            isTouch: Jt,
            isUndefined: E,
            isVideo: bi,
            isVisible: dt,
            isVoidElement: ct,
            isWindow: b,
            last: z,
            matches: bt,
            memoize: Z,
            mute: vi,
            noop: V,
            observeIntersection: hi,
            observeMutation: fi,
            observeResize: di,
            observeViewportResize: ui,
            off: jt,
            offset: Pe,
            offsetPosition: De,
            offsetViewport: Di,
            on: Lt,
            once: Wt,
            overflowParents: Ai,
            parent: gt,
            parents: xt,
            pause: gi,
            pick: W,
            play: mi,
            pointInRect: U,
            pointerCancel: ei,
            pointerDown: Ge,
            pointerEnter: Qe,
            pointerLeave: ti,
            pointerMove: Ze,
            pointerUp: Ke,
            position: Ae,
            positionAt: Ni,
            prepend: fe,
            propName: Qt,
            query: kt,
            queryAll: Tt,
            ready: function (t) {
                "loading" === document.readyState ? Wt(document, "DOMContentLoaded", t) : t();
            },
            remove: be,
            removeAttr: tt,
            removeClass: nt,
            removeClasses: st,
            replaceClass: ot,
            scrollIntoView: Ei,
            scrollParent: Pi,
            scrollParents: Bi,
            scrolledOver: _i,
            selFocusable: pt,
            selInput: ut,
            sortBy: F,
            startsWith: l,
            sumBy: L,
            swap: N,
            toArray: f,
            toBoolean: _,
            toEventTargets: Yt,
            toFloat: P,
            toNode: A,
            toNodes: D,
            toNumber: B,
            toPx: Fe,
            toWindow: M,
            toggleClass: at,
            trigger: qt,
            ucfirst: a,
            uniqueBy: j,
            unwrap: xe,
            width: Oe,
            within: $t,
            wrapAll: we,
            wrapInner: $e,
        }),
        Ki = {
            connected() {
                it(this.$el, this.$options.id);
            },
        };
    const Qi = ["days", "hours", "minutes", "seconds"];
    var tn = {
        mixins: [Ki],
        props: { date: String, clsWrapper: String, role: String },
        data: { date: "", clsWrapper: ".st-countdown-%unit%", role: "timer" },
        connected() {
            K(this.$el, "role", this.role), (this.date = P(Date.parse(this.$props.date))), (this.end = !1), this.start();
        },
        disconnected() {
            this.stop();
        },
        events: {
            name: "visibilitychange",
            el: () => document,
            handler() {
                document.hidden ? this.stop() : this.start();
            },
        },
        methods: {
            start() {
                this.stop(), this.update(), this.timer || (qt(this.$el, "countdownstart"), (this.timer = setInterval(this.update, 1e3)));
            },
            stop() {
                this.timer && (clearInterval(this.timer), qt(this.$el, "countdownstop"), (this.timer = null));
            },
            update() {
                const t = (function (t) {
                    const e = Math.max(0, t - Date.now()) / 1e3;
                    return { total: e, seconds: e % 60, minutes: (e / 60) % 60, hours: (e / 60 / 60) % 24, days: e / 60 / 60 / 24 };
                })(this.date);
                t.total || (this.stop(), this.end || (qt(this.$el, "countdownend"), (this.end = !0)));
                for (const e of Qi) {
                    const i = ke(this.clsWrapper.replace("%unit%", e), this.$el);
                    if (!i) continue;
                    let n = String(Math.trunc(t[e]));
                    (n = n.length < 2 ? `0${n}` : n), i.textContent !== n && ((n = n.split("")), n.length !== i.children.length && ue(i, n.map(() => "<span></span>").join("")), n.forEach((t, e) => (i.children[e].textContent = t)));
                }
            },
        },
    };
    const en = {};
    function nn(t, e, i) {
        return en.computed(m(t) ? t.call(i, i) : t, m(e) ? e.call(i, i) : e);
    }
    function sn(t, e) {
        return (t = t && !u(t) ? [t] : t), e ? (t ? t.concat(e) : u(e) ? e : [e]) : t;
    }
    function on(t, e) {
        return E(e) ? t : e;
    }
    function rn(t, e, n) {
        const s = {};
        if ((m(e) && (e = e.options), e.extends && (t = rn(t, e.extends, n)), e.mixins)) for (const i of e.mixins) t = rn(t, i, n);
        for (const e in t) o(e);
        for (const n in e) i(t, n) || o(n);
        function o(i) {
            s[i] = (en[i] || on)(t[i], e[i], n);
        }
        return s;
    }
    function an(t, e = []) {
        try {
            return t
                ? l(t, "{")
                    ? JSON.parse(t)
                    : e.length && !c(t, ":")
                    ? { [e[0]]: t }
                    : t.split(";").reduce((t, e) => {
                          const [i, n] = e.split(/:(.*)/);
                          return i && !E(n) && (t[i.trim()] = n.trim()), t;
                      }, {})
                : {};
        } catch (t) {
            return {};
        }
    }
    function ln(t, e) {
        return t === Boolean
            ? _(e)
            : t === Number
            ? B(e)
            : "list" === t
            ? (function (t) {
                  return u(t) ? t : I(t) ? t.split(/,(?![^(]*\))/).map((t) => (k(t) ? B(t) : _(t.trim()))) : [t];
              })(e)
            : t === Object && I(e)
            ? an(e)
            : t
            ? t(e)
            : e;
    }
    function hn(t) {
        return gn(di, t, "resize");
    }
    function cn(t) {
        return gn(hi, t);
    }
    function dn(t) {
        return gn(fi, t);
    }
    function un(t = {}) {
        return cn({
            handler: function (e, i) {
                const { targets: n = this.$el, preload: s = 5 } = t;
                for (const t of D(m(n) ? n(this) : n))
                    Te('[loading="lazy"]', t)
                        .slice(0, s - 1)
                        .forEach((t) => tt(t, "loading"));
                for (const t of e.filter(({ isIntersecting: t }) => t).map(({ target: t }) => t)) i.unobserve(t);
            },
            ...t,
        });
    }
    function fn(t) {
        return gn((t, e) => ui(e), t);
    }
    function pn(t) {
        return gn(
            (t, e) => {
                return {
                    disconnect: Lt(
                        ((i = t),
                        D(i).map((t) => {
                            const { ownerDocument: e } = t,
                                i = Pi(t, !0);
                            return i === e.scrollingElement ? e : i;
                        })),
                        "scroll",
                        e,
                        { passive: !0 }
                    ),
                };
                var i;
            },
            t,
            "scroll"
        );
    }
    function mn(t) {
        return {
            observe: (t, e) => ({ observe: V, unobserve: V, disconnect: Lt(t, Ge, e, { passive: !0 }) }),
            handler(t) {
                if (!Jt(t)) return;
                const e = Gt(t),
                    i = "tagName" in t.target ? t.target : gt(t.target);
                Wt(document, `${Ke} ${ei} scroll`, (t) => {
                    const { x: n, y: s } = Gt(t);
                    (("scroll" !== t.type && i && n && Math.abs(e.x - n) > 100) || (s && Math.abs(e.y - s) > 100)) &&
                        setTimeout(() => {
                            var t, o, r, a;
                            qt(i, "swipe"), qt(i, "swipe" + ((t = e.x), (o = e.y), (r = n), (a = s), Math.abs(t - r) >= Math.abs(o - a) ? (t - r > 0 ? "Left" : "Right") : o - a > 0 ? "Up" : "Down"));
                        });
                });
            },
            ...t,
        };
    }
    function gn(t, e, i) {
        return {
            observe: t,
            handler() {
                this.$emit(i);
            },
            ...e,
        };
    }
    (en.events = en.watch = en.observe = en.created = en.beforeConnect = en.connected = en.beforeDisconnect = en.disconnected = en.destroy = sn),
        (en.args = function (t, e) {
            return !1 !== e && sn(e || t);
        }),
        (en.update = function (t, e) {
            return F(sn(t, m(e) ? { read: e } : e), "order");
        }),
        (en.props = function (t, e) {
            if (u(e)) {
                const t = {};
                for (const i of e) t[i] = String;
                e = t;
            }
            return en.methods(t, e);
        }),
        (en.computed = en.methods = function (t, e) {
            return e ? (t ? { ...t, ...e } : e) : t;
        }),
        (en.i18n = en.data = function (t, e, i) {
            return i
                ? nn(t, e, i)
                : e
                ? t
                    ? function (i) {
                          return nn(t, e, i);
                      }
                    : e
                : t;
        });
    var vn = {
        props: { margin: String, firstColumn: Boolean },
        data: { margin: "st-margin-small-top", firstColumn: "st-first-column" },
        observe: [dn({ options: { childList: !0, attributes: !0, attributeFilter: ["style"] } }), hn({ target: ({ $el: t }) => [t, ...yt(t)] })],
        update: {
            read() {
                return { rows: bn(f(this.$el.children)) };
            },
            write({ rows: t }) {
                for (const e of t) for (const i of e) at(i, this.margin, t[0] !== e), at(i, this.firstColumn, e[Xe ? e.length - 1 : 0] === i);
            },
            events: ["resize"],
        },
    };
    function bn(t) {
        const e = [[]],
            i = t.some((e, i) => i && t[i - 1].offsetParent !== e.offsetParent);
        for (const n of t) {
            if (!dt(n)) continue;
            const t = wn(n, i);
            for (let s = e.length - 1; s >= 0; s--) {
                const o = e[s];
                if (!o[0]) {
                    o.push(n);
                    break;
                }
                const r = wn(o[0], i);
                if (t.top >= r.bottom - 1 && t.top !== r.top) {
                    e.push([n]);
                    break;
                }
                if (t.bottom - 1 > r.top || t.top === r.top) {
                    let e = o.length - 1;
                    for (; e >= 0; e--) {
                        const n = wn(o[e], i);
                        if (t.left >= n.left) break;
                    }
                    o.splice(e + 1, 0, n);
                    break;
                }
                if (0 === s) {
                    e.unshift([n]);
                    break;
                }
            }
        }
        return e;
    }
    function wn(t, e = !1) {
        let { offsetTop: i, offsetLeft: n, offsetHeight: s, offsetWidth: o } = t;
        return e && ([i, n] = De(t)), { top: i, left: n, bottom: i + s, right: n + o };
    }
    const $n = "st-transition-leave",
        xn = "st-transition-enter";
    function yn(t, e, i, n = 0) {
        const s = Sn(e, !0),
            o = { opacity: 1 },
            r = { opacity: 0 },
            a = (t) => () => (s === Sn(e) ? t() : Promise.reject()),
            l = a(async () => {
                it(e, $n), await Promise.all(Cn(e).map((t, e) => new Promise((s) => setTimeout(() => ne.start(t, r, i / 2, "ease").then(s), e * n)))), nt(e, $n);
            }),
            h = a(async () => {
                const a = Me(e);
                it(e, xn), t(), Kt(yt(e), { opacity: 0 }), await new Promise((t) => requestAnimationFrame(t));
                const l = yt(e),
                    h = Me(e);
                Kt(e, "alignContent", "flex-start"), Me(e, a);
                const c = Cn(e);
                Kt(l, r);
                const d = c.map(async (t, e) => {
                    var s;
                    await ((s = e * n), new Promise((t) => setTimeout(t, s))), await ne.start(t, o, i / 2, "ease");
                });
                a !== h && d.push(ne.start(e, { height: h }, i / 2 + c.length * n, "ease")),
                    await Promise.all(d).then(() => {
                        nt(e, xn), s === Sn(e) && (Kt(e, { height: "", alignContent: "" }), Kt(l, { opacity: "" }), delete e.dataset.transition);
                    });
            });
        return rt(e, $n) ? In(e).then(h) : rt(e, xn) ? In(e).then(l).then(h) : l().then(h);
    }
    function Sn(t, e) {
        return e && (t.dataset.transition = 1 + Sn(t)), B(t.dataset.transition) || 0;
    }
    function In(t) {
        return Promise.all(
            yt(t)
                .filter(ne.inProgress)
                .map((t) => new Promise((e) => Wt(t, "transitionend transitioncanceled", e)))
        );
    }
    function Cn(t) {
        return bn(yt(t)).flat().filter(Ti);
    }
    async function kn(t, e, i) {
        await _n();
        let n = yt(e);
        const s = n.map((t) => Tn(t, !0)),
            o = { ...Kt(e, ["height", "padding"]), display: "block" };
        await Promise.all(n.concat(e).map(ne.cancel)), t(), (n = n.concat(yt(e).filter((t) => !c(n, t)))), await Promise.resolve(), ii.flush();
        const r = K(e, "style"),
            a = Kt(e, ["height", "padding"]),
            [l, h] = (function (t, e, i) {
                const n = e.map((t, e) => !(!gt(t) || !(e in i)) && (i[e] ? (dt(t) ? En(t) : { opacity: 0 }) : { opacity: dt(t) ? 1 : 0 })),
                    s = n.map((n, s) => {
                        const o = gt(e[s]) === t && (i[s] || Tn(e[s]));
                        if (!o) return !1;
                        if (n) {
                            if (!("opacity" in n)) {
                                const { opacity: t } = o;
                                t % 1 ? (n.opacity = 1) : delete o.opacity;
                            }
                        } else delete o.opacity;
                        return o;
                    });
                return [n, s];
            })(e, n, s),
            d = n.map((t) => ({ style: K(t, "style") }));
        n.forEach((t, e) => h[e] && Kt(t, h[e])), Kt(e, o), qt(e, "scroll"), ii.flush(), await _n();
        const u = n.map((t, n) => gt(t) === e && ne.start(t, l[n], i, "ease")).concat(ne.start(e, a, i, "ease"));
        try {
            await Promise.all(u),
                n.forEach((t, i) => {
                    K(t, d[i]), gt(t) === e && Kt(t, "display", 0 === l[i].opacity ? "none" : "");
                }),
                K(e, "style", r);
        } catch (t) {
            K(n, "style", ""),
                (function (t, e) {
                    for (const i in e) Kt(t, i, "");
                })(e, o);
        }
    }
    function Tn(t, e) {
        const i = Kt(t, "zIndex");
        return !!dt(t) && { display: "", opacity: e ? Kt(t, "opacity") : "0", pointerEvents: "none", position: "absolute", zIndex: "auto" === i ? St(t) : i, ...En(t) };
    }
    function En(t) {
        const { height: e, width: i } = Pe(t);
        return { height: e, width: i, transform: "", ...Ae(t), ...Kt(t, ["marginTop", "marginLeft"]) };
    }
    function _n() {
        return new Promise((t) => requestAnimationFrame(t));
    }
    var Bn = {
        props: { duration: Number, animation: Boolean },
        data: { duration: 150, animation: "slide" },
        methods: {
            animate(t, e = this.$el) {
                const i = this.animation;
                return ("fade" === i ? yn : "delayed-fade" === i ? (...t) => yn(...t, 40) : i ? kn : () => (t(), Promise.resolve()))(t, e, this.duration).catch(V);
            },
        },
    };
    const Pn = 9,
        An = 27,
        Dn = 32,
        Mn = 35,
        On = 36,
        Nn = 37,
        zn = 38,
        Hn = 39,
        Fn = 40;
    var Ln = {
        mixins: [Bn],
        args: "target",
        props: { target: String, selActive: Boolean },
        data: { target: "", selActive: !1, attrItem: "st-filter-control", cls: "st-active", duration: 250 },
        computed: { toggles: ({ attrItem: t }, e) => Te(`[${t}],[data-${t}]`, e), children: ({ target: t }, e) => Te(`${t} > *`, e) },
        watch: {
            toggles(t) {
                this.updateState();
                const e = Te(this.selActive, this.$el);
                for (const n of t) {
                    !1 !== this.selActive && at(n, this.cls, c(e, n));
                    const t = ke("a,button", (i = n)) || i;
                    ce(t, "a") && K(t, "role", "button");
                }
                var i;
            },
            children(t, e) {
                e && this.updateState();
            },
        },
        events: {
            name: "click keydown",
            delegate() {
                return `[${this.attrItem}],[data-${this.attrItem}]`;
            },
            handler(t) {
                ("keydown" === t.type && t.keyCode !== Dn) || (wt(t.target, "a,button") && (t.preventDefault(), this.apply(t.current)));
            },
        },
        methods: {
            apply(t) {
                const e = this.getState(),
                    i = Wn(t, this.attrItem, this.getState());
                var n, s;
                (n = e), (s = i), ["filter", "sort"].every((t) => O(n[t], s[t])) || this.setState(i);
            },
            getState() {
                return this.toggles.filter((t) => rt(t, this.cls)).reduce((t, e) => Wn(e, this.attrItem, t), { filter: { "": "" }, sort: [] });
            },
            async setState(t, e = !0) {
                (t = { filter: { "": "" }, sort: [], ...t }), qt(this.$el, "beforeFilter", [this, t]);
                for (const e of this.toggles) at(e, this.cls, qn(e, this.attrItem, t));
                await Promise.all(
                    Te(this.target, this.$el).map((i) => {
                        const n = () => {
                            !(function (t, e, i) {
                                const n = (function ({ filter: t }) {
                                    let e = "";
                                    return H(t, (t) => (e += t || "")), e;
                                })(t);
                                i.forEach((t) => Kt(t, "display", n && !bt(t, n) ? "none" : ""));
                                const [s, o] = t.sort;
                                if (s) {
                                    const t = (function (t, e, i) {
                                        return [...t].sort((t, n) => et(t, e).localeCompare(et(n, e), void 0, { numeric: !0 }) * ("asc" === i || -1));
                                    })(i, s, o);
                                    O(t, i) || pe(e, t);
                                }
                            })(t, i, yt(i)),
                                this.$update(this.$el);
                        };
                        return e ? this.animate(n, i) : n();
                    })
                ),
                    qt(this.$el, "afterFilter", [this]);
            },
            updateState() {
                ii.write(() => this.setState(this.getState(), !1));
            },
        },
    };
    function jn(t, e) {
        return an(et(t, e), ["filter"]);
    }
    function Wn(t, e, i) {
        const { filter: n, group: s, sort: o, order: r = "asc" } = jn(t, e);
        return (n || E(o)) && (s ? (n ? (delete i.filter[""], (i.filter[s] = n)) : (delete i.filter[s], (T(i.filter) || "" in i.filter) && (i.filter = { "": n || "" }))) : (i.filter = { "": n || "" })), E(o) || (i.sort = [o, r]), i;
    }
    function qn(t, e, { filter: i = { "": "" }, sort: [n, s] }) {
        const { filter: o = "", group: r = "", sort: a, order: l = "asc" } = jn(t, e);
        return E(a) ? (r in i && o === i[r]) || (!o && r && !(r in i) && !i[""]) : n === a && s === l;
    }
    var Vn = {
        props: { container: Boolean },
        data: { container: !0 },
        computed: {
            container({ container: t }) {
                return (!0 === t && this.$container) || (t && ke(t));
            },
        },
    };
    let Rn;
    function Un(t) {
        const e = Lt(
            t,
            "touchmove",
            (t) => {
                if (1 !== t.targetTouches.length || bt(t.target, 'input[type="range"')) return;
                let { scrollHeight: e, clientHeight: i } = Pi(t.target);
                i >= e && t.cancelable && t.preventDefault();
            },
            { passive: !1 }
        );
        if (Rn) return e;
        Rn = !0;
        const { scrollingElement: i } = document;
        return (
            Kt(i, { overflowY: CSS.supports("overflow", "clip") ? "clip" : "hidden", touchAction: "none", paddingRight: Oe(window) - i.clientWidth || "" }),
            () => {
                (Rn = !1), e(), Kt(i, { overflowY: "", touchAction: "", paddingRight: "" });
            }
        );
    }
    var Xn = {
        props: { cls: Boolean, animation: "list", duration: Number, velocity: Number, origin: String, transition: String },
        data: { cls: !1, animation: [!1], duration: 200, velocity: 0.2, origin: !1, transition: "ease", clsEnter: "st-togglabe-enter", clsLeave: "st-togglabe-leave" },
        computed: { hasAnimation: ({ animation: t }) => !!t[0], hasTransition: ({ animation: t }) => ["slide", "reveal"].some((e) => l(t[0], e)) },
        methods: {
            async toggleElement(t, e, i) {
                try {
                    return (
                        await Promise.all(
                            D(t).map((t) => {
                                const n = S(e) ? e : !this.isToggled(t);
                                if (!qt(t, "before" + (n ? "show" : "hide"), [this])) return Promise.reject();
                                const s = (m(i) ? i : !1 !== i && this.hasAnimation ? (this.hasTransition ? Jn : Gn) : Yn)(t, n, this),
                                    o = n ? this.clsEnter : this.clsLeave;
                                it(t, o), qt(t, n ? "show" : "hide", [this]);
                                const r = () => {
                                    nt(t, o), qt(t, n ? "shown" : "hidden", [this]);
                                };
                                return s ? s.then(r, () => (nt(t, o), Promise.reject())) : r();
                            })
                        ),
                        !0
                    );
                } catch (t) {
                    return !1;
                }
            },
            isToggled(t = this.$el) {
                return !!rt((t = A(t)), this.clsEnter) || (!rt(t, this.clsLeave) && (this.cls ? rt(t, this.cls.split(" ")[0]) : dt(t)));
            },
            _toggle(t, e) {
                if (!t) return;
                let i;
                (e = Boolean(e)),
                    this.cls ? ((i = c(this.cls, " ") || e !== rt(t, this.cls)), i && at(t, this.cls, c(this.cls, " ") ? void 0 : e)) : ((i = e === t.hidden), i && (t.hidden = !e)),
                    Te("[autofocus]", t).some((t) => (dt(t) ? t.focus() || !0 : t.blur())),
                    i && qt(t, "toggled", [e, this]);
            },
        },
    };
    function Yn(t, e, { _toggle: i }) {
        return he.cancel(t), ne.cancel(t), i(t, e);
    }
    async function Jn(t, e, { animation: i, duration: n, velocity: s, transition: o, _toggle: r }) {
        var a;
        const [l = "reveal", h = "top"] = (null == (a = i[0]) ? void 0 : a.split("-")) || [],
            d = [
                ["left", "right"],
                ["top", "bottom"],
            ],
            u = d[c(d[0], h) ? 0 : 1],
            f = u[1] === h,
            p = ["width", "height"][d.indexOf(u)],
            m = `margin-${u[0]}`,
            g = `margin-${h}`;
        let v = Be(t)[p];
        const b = ne.inProgress(t);
        await ne.cancel(t), e && r(t, !0);
        const w = Object.fromEntries(["padding", "border", "width", "height", "minWidth", "minHeight", "overflowY", "overflowX", m, g].map((e) => [e, t.style[e]])),
            $ = Be(t),
            x = P(Kt(t, m)),
            y = P(Kt(t, g)),
            S = $[p] + y;
        b || e || (v += y);
        const [I] = $e(t, "<div>");
        Kt(I, { boxSizing: "border-box", height: $.height, width: $.width, ...Kt(t, ["overflow", "padding", "borderTop", "borderRight", "borderBottom", "borderLeft", "borderImage", g]) }),
            Kt(t, { padding: 0, border: 0, minWidth: 0, minHeight: 0, [g]: 0, width: $.width, height: $.height, overflow: "hidden", [p]: v });
        const C = v / S;
        n = (s * S + n) * (e ? 1 - C : C);
        const k = { [p]: e ? S : 0 };
        f && (Kt(t, m, S - v + x), (k[m] = e ? x : S + x)), !f ^ ("reveal" === l) && (Kt(I, m, -S + v), ne.start(I, { [m]: e ? 0 : -S }, n, o));
        try {
            await ne.start(t, k, n, o);
        } finally {
            Kt(t, w), xe(I.firstChild), e || r(t, !1);
        }
    }
    function Gn(t, e, i) {
        const { animation: n, duration: s, _toggle: o } = i;
        return e ? (o(t, !0), he.in(t, n[0], s, i.origin)) : he.out(t, n[1] || n[0], s, i.origin).then(() => o(t, !1));
    }
    const Zn = [];
    var Kn = {
        mixins: [Ki, Vn, Xn],
        props: { selPanel: String, selClose: String, escClose: Boolean, bgClose: Boolean, stack: Boolean, role: String },
        data: { cls: "st-open", escClose: !0, bgClose: !0, overlay: !0, stack: !1, role: "dialog" },
        computed: {
            panel: ({ selPanel: t }, e) => ke(t, e),
            transitionElement() {
                return this.panel;
            },
            bgClose({ bgClose: t }) {
                return t && this.panel;
            },
        },
        connected() {
            K(this.panel || this.$el, "role", this.role), this.overlay && K(this.panel || this.$el, "aria-modal", !0);
        },
        beforeDisconnect() {
            c(Zn, this) && this.toggleElement(this.$el, !1, !1);
        },
        events: [
            {
                name: "click",
                delegate() {
                    return `${this.selClose},a[href*="#"]`;
                },
                handler(t) {
                    const { current: e, defaultPrevented: i } = t,
                        { hash: n } = e;
                    !i && n && It(e) && !$t(n, this.$el) && ke(n, document.body) ? this.hide() : bt(e, this.selClose) && (t.preventDefault(), this.hide());
                },
            },
            {
                name: "toggle",
                self: !0,
                handler(t) {
                    t.defaultPrevented || (t.preventDefault(), this.isToggled() === c(Zn, this) && this.toggle());
                },
            },
            {
                name: "beforeshow",
                self: !0,
                handler(t) {
                    if (c(Zn, this)) return !1;
                    !this.stack && Zn.length ? (Promise.all(Zn.map((t) => t.hide())).then(this.show), t.preventDefault()) : Zn.push(this);
                },
            },
            {
                name: "show",
                self: !0,
                handler() {
                    this.stack && Kt(this.$el, "zIndex", P(Kt(this.$el, "zIndex")) + Zn.length);
                    const t = [this.overlay && ts(this), this.overlay && Un(this.$el), this.bgClose && es(this), this.escClose && is(this)];
                    Wt(this.$el, "hidden", () => t.forEach((t) => t && t()), { self: !0 }), it(document.documentElement, this.clsPage);
                },
            },
            {
                name: "shown",
                self: !0,
                handler() {
                    mt(this.$el) || K(this.$el, "tabindex", "-1"), bt(this.$el, ":focus-within") || this.$el.focus();
                },
            },
            {
                name: "hidden",
                self: !0,
                handler() {
                    c(Zn, this) && Zn.splice(Zn.indexOf(this), 1), Kt(this.$el, "zIndex", ""), Zn.some((t) => t.clsPage === this.clsPage) || nt(document.documentElement, this.clsPage);
                },
            },
        ],
        methods: {
            toggle() {
                return this.isToggled() ? this.hide() : this.show();
            },
            show() {
                return this.container && gt(this.$el) !== this.container ? (pe(this.container, this.$el), new Promise((t) => requestAnimationFrame(() => this.show().then(t)))) : this.toggleElement(this.$el, !0, Qn);
            },
            hide() {
                return this.toggleElement(this.$el, !1, Qn);
            },
        },
    };
    function Qn(t, e, { transitionElement: i, _toggle: n }) {
        return new Promise((s, o) =>
            Wt(t, "show hide", () => {
                var r;
                null == (r = t._reject) || r.call(t), (t._reject = o), n(t, e);
                const a = Wt(
                        i,
                        "transitionstart",
                        () => {
                            Wt(i, "transitionend transitioncancel", s, { self: !0 }), clearTimeout(l);
                        },
                        { self: !0 }
                    ),
                    l = setTimeout(
                        () => {
                            a(), s();
                        },
                        (c = Kt(i, "transitionDuration")) ? (h(c, "ms") ? P(c) : 1e3 * P(c)) : 0
                    );
                var c;
            })
        ).then(() => delete t._reject);
    }
    function ts(t) {
        return Lt(document, "focusin", (e) => {
            z(Zn) !== t || $t(e.target, t.$el) || t.$el.focus();
        });
    }
    function es(t) {
        return Lt(document, Ge, ({ target: e }) => {
            z(Zn) !== t ||
                (t.overlay && !$t(e, t.$el)) ||
                $t(e, t.panel) ||
                Wt(
                    document,
                    `${Ke} ${ei} scroll`,
                    ({ defaultPrevented: i, type: n, target: s }) => {
                        i || n !== Ke || e !== s || t.hide();
                    },
                    !0
                );
        });
    }
    function is(t) {
        return Lt(document, "keydown", (e) => {
            27 === e.keyCode && z(Zn) === t && t.hide();
        });
    }
    var ns = { slide: { show: (t) => [{ transform: os(-100 * t) }, { transform: os() }], percent: (t) => ss(t), translate: (t, e) => [{ transform: os(-100 * e * t) }, { transform: os(100 * e * (1 - t)) }] } };
    function ss(t) {
        return Math.abs(Kt(t, "transform").split(",")[4] / t.offsetWidth);
    }
    function os(t = 0, e = "%") {
        return `translate3d(${(t += t ? e : "")}, 0, 0)`;
    }
    function rs(t) {
        return `scale3d(${t}, ${t}, 1)`;
    }
    function as(t, e, i) {
        qt(t, Vt(e, !1, !1, i));
    }
    var ls = {
            props: { i18n: Object },
            data: { i18n: null },
            methods: {
                t(t, ...e) {
                    var i, n, s;
                    let o = 0;
                    return (null == (s = (null == (i = this.i18n) ? void 0 : i[t]) || (null == (n = this.$options.i18n) ? void 0 : n[t])) ? void 0 : s.replace(/%s/g, () => e[o++] || "")) || "";
                },
            },
        },
        hs = {
            props: { autoplay: Boolean, autoplayInterval: Number, pauseOnHover: Boolean },
            data: { autoplay: !1, autoplayInterval: 7e3, pauseOnHover: !0 },
            connected() {
                K(this.list, "aria-live", this.autoplay ? "off" : "polite"), this.autoplay && this.startAutoplay();
            },
            disconnected() {
                this.stopAutoplay();
            },
            update() {
                K(this.slides, "tabindex", "-1");
            },
            events: [
                {
                    name: "visibilitychange",
                    el: () => document,
                    filter() {
                        return this.autoplay;
                    },
                    handler() {
                        document.hidden ? this.stopAutoplay() : this.startAutoplay();
                    },
                },
            ],
            methods: {
                startAutoplay() {
                    this.stopAutoplay(),
                        (this.interval = setInterval(() => {
                            this.stack.length || (this.draggable && bt(this.$el, ":focus-within")) || (this.pauseOnHover && bt(this.$el, ":hover")) || this.show("next");
                        }, this.autoplayInterval));
                },
                stopAutoplay() {
                    clearInterval(this.interval);
                },
            },
        };
    const cs = { passive: !1, capture: !0 },
        ds = { passive: !0, capture: !0 },
        us = "touchmove mousemove",
        fs = "touchend touchcancel mouseup click input scroll";
    var ps = {
        props: { draggable: Boolean },
        data: { draggable: !0, threshold: 10 },
        created() {
            for (const t of ["start", "move", "end"]) {
                const e = this[t];
                this[t] = (t) => {
                    const i = Gt(t).x * (Xe ? -1 : 1);
                    (this.prevPos = i === this.pos ? this.prevPos : this.pos), (this.pos = i), e(t);
                };
            }
        },
        events: [
            {
                name: "touchstart mousedown",
                passive: !0,
                delegate() {
                    return `${this.selList} > *`;
                },
                handler(t) {
                    var e;
                    !this.draggable ||
                        (!Jt(t) && ((e = t.target), "none" !== Kt(e, "userSelect") && f(e.childNodes).some((t) => 3 === t.nodeType && t.textContent.trim()))) ||
                        wt(t.target, ut) ||
                        t.button > 0 ||
                        this.length < 2 ||
                        this.start(t);
                },
            },
            {
                name: "dragstart",
                handler(t) {
                    t.preventDefault();
                },
            },
            {
                name: us,
                el() {
                    return this.list;
                },
                handler: V,
                ...cs,
            },
        ],
        methods: {
            start() {
                (this.drag = this.pos),
                    this._transitioner
                        ? ((this.percent = this._transitioner.percent()),
                          (this.drag += this._transitioner.getDistance() * this.percent * this.dir),
                          this._transitioner.cancel(),
                          this._transitioner.translate(this.percent),
                          (this.dragging = !0),
                          (this.stack = []))
                        : (this.prevIndex = this.index),
                    Lt(document, us, this.move, cs),
                    Lt(document, fs, this.end, ds),
                    Kt(this.list, "userSelect", "none");
            },
            move(t) {
                const e = this.pos - this.drag;
                if (0 === e || this.prevPos === this.pos || (!this.dragging && Math.abs(e) < this.threshold)) return;
                Kt(this.list, "pointerEvents", "none"), t.cancelable && t.preventDefault(), (this.dragging = !0), (this.dir = e < 0 ? 1 : -1);
                let { slides: i, prevIndex: n } = this,
                    s = Math.abs(e),
                    o = this.getIndex(n + this.dir),
                    r = this._getDistance(n, o);
                for (; o !== n && s > r; ) (this.drag -= r * this.dir), (n = o), (s -= r), (o = this.getIndex(n + this.dir)), (r = this._getDistance(n, o));
                this.percent = s / r;
                const a = i[n],
                    l = i[o],
                    h = this.index !== o,
                    d = n === o;
                let u;
                for (const t of [this.index, this.prevIndex]) c([o, n], t) || (qt(i[t], "itemhidden", [this]), d && ((u = !0), (this.prevIndex = n)));
                ((this.index === n && this.prevIndex !== n) || u) && qt(i[this.index], "itemshown", [this]),
                    h && ((this.prevIndex = n), (this.index = o), !d && qt(a, "beforeitemhide", [this]), qt(l, "beforeitemshow", [this])),
                    (this._transitioner = this._translate(Math.abs(this.percent), a, !d && l)),
                    h && (!d && qt(a, "itemhide", [this]), qt(l, "itemshow", [this]));
            },
            end() {
                if ((jt(document, us, this.move, cs), jt(document, fs, this.end, ds), this.dragging))
                    if (((this.dragging = null), this.index === this.prevIndex)) (this.percent = 1 - this.percent), (this.dir *= -1), this._show(!1, this.index, !0), (this._transitioner = null);
                    else {
                        const t = (Xe ? this.dir * (Xe ? 1 : -1) : this.dir) < 0 == this.prevPos > this.pos;
                        (this.index = t ? this.index : this.prevIndex), t && (this.percent = 1 - this.percent), this.show((this.dir > 0 && !t) || (this.dir < 0 && t) ? "next" : "previous", !0);
                    }
                Kt(this.list, { userSelect: "", pointerEvents: "" }), (this.drag = this.percent = null);
            },
            _getDistance(t, e) {
                return this._getTransitioner(t, t !== e && e).getDistance() || this.slides[t].offsetWidth;
            },
        },
    };
    function ms(t, e = "update") {
        t._connected &&
            t._updates.length &&
            (t._queued ||
                ((t._queued = new Set()),
                ii.read(() => {
                    t._connected &&
                        (function (t, e) {
                            for (const { read: i, write: n, events: s = [] } of t._updates) {
                                if (!e.has("update") && !s.some((t) => e.has(t))) continue;
                                let o;
                                i && ((o = i.call(t, t._data, e)), o && v(o) && p(t._data, o)),
                                    n &&
                                        !1 !== o &&
                                        ii.write(() => {
                                            t._connected && n.call(t, t._data, e);
                                        });
                            }
                        })(t, t._queued),
                        delete t._queued;
                })),
            t._queued.add(e.type || e));
    }
    function gs(t, e, i) {
        t._watches.push({ name: i, ...(v(e) ? e : { handler: e }) });
    }
    function vs(t, e, n) {
        (t._hasComputed = !0),
            Object.defineProperty(t, e, {
                enumerable: !0,
                get() {
                    const { _computed: s, $props: o, $el: r } = t;
                    return i(s, e) || (s[e] = (n.get || n).call(t, o, r)), s[e];
                },
                set(i) {
                    const { _computed: s } = t;
                    (s[e] = n.set ? n.set.call(t, i) : i), E(s[e]) && delete s[e];
                },
            });
    }
    function bs(t) {
        t._hasComputed &&
            (!(function (t, e) {
                t._updates.unshift(e);
            })(t, {
                read: () =>
                    (function (t, e) {
                        for (const { name: n, handler: s, immediate: o = !0 } of t._watches) ((t._initial && o) || (i(e, n) && !O(e[n], t[n]))) && s.call(t, t[n], e[n]);
                        t._initial = !1;
                    })(t, ws(t)),
                events: ["resize", "computed"],
            }),
            (function () {
                if ($s) return;
                (xs = new Set()),
                    ($s = new MutationObserver(() => {
                        for (const t of xs) ms(t, "computed");
                    })),
                    $s.observe(document, { subtree: !0, childList: !0 });
            })(),
            xs.add(t));
    }
    function ws(t) {
        const e = { ...t._computed };
        return (t._computed = {}), e;
    }
    let $s, xs;
    function ys(t, e, i) {
        let { name: n, el: s, handler: o, capture: r, passive: a, delegate: l, filter: h, self: c } = v(e) ? e : { name: i, handler: e };
        (s = m(s) ? s.call(t, t) : s || t.$el),
            u(s) ? s.forEach((n) => ys(t, { ...e, el: n }, i)) : !s || (h && !h.call(t)) || t._events.push(Lt(s, n, l ? (I(l) ? l : l.call(t, t)) : null, I(o) ? t[o] : o.bind(t), { passive: a, capture: r, self: c }));
    }
    function Ss(t, ...e) {
        t._observers.push(...e);
    }
    function Is(t, e) {
        let { observe: n, target: s = t.$el, handler: o, options: r, filter: a, args: l } = e;
        if (a && !a.call(t, t)) return;
        const h = `_observe${t._observers.length}`;
        m(s) && !i(t, h) && vs(t, h, () => s.call(t, t)), (o = I(o) ? t[o] : o.bind(t)), m(r) && (r = r.call(t, t));
        const c = n(i(t, h) ? t[h] : s, o, r, l);
        m(s) && u(t[h]) && c.unobserve && gs(t, { handler: Cs(c), immediate: !1 }, h), Ss(t, c);
    }
    function Cs(t) {
        return (e, i) => {
            for (const n of i) !c(e, n) && t.unobserve(n);
            for (const n of e) !c(i, n) && t.observe(n);
        };
    }
    function ks(t) {
        const e = {},
            { args: i = [], props: n = {}, el: o, id: a } = t;
        if (!n) return e;
        for (const t in n) {
            const i = s(t);
            let r = et(o, i);
            E(r) || ((r = (n[t] === Boolean && "" === r) || ln(n[t], r)), ("target" === i && l(r, "_")) || (e[t] = r));
        }
        const h = an(et(o, a), i);
        for (const t in h) {
            const i = r(t);
            E(n[i]) || (e[i] = ln(n[i], h[t]));
        }
        return e;
    }
    function Ts(t, e) {
        return t.every((t) => !t || !i(t, e));
    }
    function Es(t, e) {
        var i;
        null == (i = t.$options[e]) || i.forEach((e) => e.call(t));
    }
    function _s(t) {
        t._connected ||
            (!(function (t) {
                const e = ks(t.$options);
                for (let i in e) E(e[i]) || (t.$props[i] = e[i]);
                const i = [t.$options.computed, t.$options.methods];
                for (let n in t.$props) n in e && Ts(i, n) && (t[n] = t.$props[n]);
            })(t),
            Es(t, "beforeConnect"),
            (t._connected = !0),
            (function (t) {
                t._events = [];
                for (const e of t.$options.events || [])
                    if (i(e, "handler")) ys(t, e);
                    else for (const i in e) ys(t, e[i], i);
            })(t),
            (function (t) {
                (t._data = {}), (t._updates = [...(t.$options.update || [])]);
            })(t),
            (function (t) {
                t._watches = [];
                for (const e of t.$options.watch || []) for (const [i, n] of Object.entries(e)) gs(t, n, i);
                t._initial = !0;
            })(t),
            (function (t) {
                t._observers = [];
                for (const e of t.$options.observe || [])
                    if (i(e, "handler")) Is(t, e);
                    else for (const i of e) Is(t, i);
            })(t),
            (function (t) {
                const { $options: e, $props: i } = t,
                    { id: n, props: o, el: a } = e;
                if (!o) return;
                const l = Object.keys(o),
                    h = l.map((t) => s(t)).concat(n),
                    c = new MutationObserver((s) => {
                        const o = ks(e);
                        s.some(({ attributeName: t }) => {
                            const e = t.replace("data-", "");
                            return (e === n ? l : [r(e), r(t)]).some((t) => !E(o[t]) && o[t] !== i[t]);
                        }) && t.$reset();
                    });
                c.observe(a, { attributes: !0, attributeFilter: h.concat(h.map((t) => `data-${t}`)) }), Ss(t, c);
            })(t),
            bs(t),
            Es(t, "connected"),
            ms(t));
    }
    function Bs(t) {
        t._connected &&
            (Es(t, "beforeDisconnect"),
            (function (t) {
                t._events.forEach((t) => t()), delete t._events;
            })(t),
            (function (t) {
                delete t._data;
            })(t),
            (function (t) {
                for (const e of t._observers) e.disconnect();
            })(t),
            (function (t) {
                null == xs || xs.delete(t), ws(t);
            })(t),
            Es(t, "disconnected"),
            (t._connected = !1));
    }
    let Ps = 0;
    function As(t, e = {}) {
        (e.data = (function ({ data: t = {} }, { args: e = [], props: i = {} }) {
            u(t) && (t = t.slice(0, e.length).reduce((t, i, n) => (v(i) ? p(t, i) : (t[e[n]] = i), t), {}));
            for (const e in t) E(t[e]) ? delete t[e] : i[e] && (t[e] = ln(i[e], t[e]));
            return t;
        })(e, t.constructor.options)),
            (t.$options = rn(t.constructor.options, e, t)),
            (t.$props = {}),
            (t._uid = Ps++),
            (function (t) {
                const { data: e = {} } = t.$options;
                for (const i in e) t.$props[i] = t[i] = e[i];
            })(t),
            (function (t) {
                const { methods: e } = t.$options;
                if (e) for (const i in e) t[i] = e[i].bind(t);
            })(t),
            (function (t) {
                const { computed: e } = t.$options;
                if (((t._computed = {}), e)) for (const i in e) vs(t, i, e[i]);
            })(t),
            Es(t, "created"),
            e.el && t.$mount(e.el);
    }
    const Ds = function (t) {
        As(this, t);
    };
    (Ds.util = Zi), (Ds.options = {}), (Ds.version = "3.17.1");
    const Ms = "st-",
        Os = "__spectraafe__",
        Ns = {};
    function zs(t, e) {
        var i;
        const n = Ms + s(t);
        if (!e) return v(Ns[n]) && (Ns[n] = Ds.extend(Ns[n])), Ns[n];
        (t = r(t)), (Ds[t] = (e, i) => Hs(t, e, i));
        const o = v(e) ? { ...e } : e.options;
        return (o.id = n), (o.name = t), null == (i = o.install) || i.call(o, Ds, o, t), Ds._initialized && !o.functional && requestAnimationFrame(() => Hs(t, `[${n}],[data-${n}]`)), (Ns[n] = o);
    }
    function Hs(t, e, i, ...n) {
        const s = zs(t);
        return s.options.functional ? new s({ data: v(e) ? e : [e, i, ...n] }) : e ? Te(e).map(o)[0] : o();
        function o(e) {
            const n = Ls(e, t);
            if (n) {
                if (!i) return n;
                n.$destroy();
            }
            return new s({ el: e, data: i });
        }
    }
    function Fs(t) {
        return (null == t ? void 0 : t[Os]) || {};
    }
    function Ls(t, e) {
        return Fs(t)[e];
    }
    function js(t, e) {
        t = t ? A(t) : document.body;
        for (const i of xt(t).reverse()) Ws(i, e);
        Ce(t, (t) => Ws(t, e));
    }
    function Ws(t, e) {
        const i = Fs(t);
        for (const t in i) ms(i[t], e);
    }
    function qs(t, e = t.$el, i = "") {
        if (e.id) return e.id;
        let n = `${t.$options.id}-${t._uid}${i}`;
        return ke(`#${n}`) && (n = qs(t, e, `${i}-2`)), n;
    }
    var Vs = {
            i18n: { next: "Next slide", previous: "Previous slide", slideX: "Slide %s", slideLabel: "%s of %s", role: "String" },
            data: { selNav: !1, role: "region" },
            computed: {
                nav: ({ selNav: t }, e) => ke(t, e),
                navChildren() {
                    return yt(this.nav);
                },
                selNavItem: ({ attrItem: t }) => `[${t}],[data-${t}]`,
                navItems(t, e) {
                    return Te(this.selNavItem, e);
                },
            },
            watch: {
                nav(t, e) {
                    K(t, "role", "tablist"), e && this.$emit();
                },
                list(t) {
                    K(t, "role", "presentation");
                },
                navChildren(t) {
                    K(t, "role", "presentation");
                },
                navItems(t) {
                    for (const e of t) {
                        const t = et(e, this.attrItem),
                            i = ke("a,button", e) || e;
                        let n,
                            s = null;
                        if (k(t)) {
                            const e = B(t),
                                o = this.slides[e];
                            o && (o.id || (o.id = qs(this, o, `-item-${t}`)), (s = o.id)), (n = this.t("slideX", P(t) + 1)), K(i, "role", "tab");
                        } else this.list && (this.list.id || (this.list.id = qs(this, this.list, "-items")), (s = this.list.id)), (n = this.t(t));
                        K(i, { "aria-controls": s, "aria-label": K(i, "aria-label") || n });
                    }
                },
                slides(t) {
                    t.forEach((t, e) => K(t, { role: this.nav ? "tabpanel" : "group", "aria-label": this.t("slideLabel", e + 1, this.length), "aria-roledescription": this.nav ? null : "slide" }));
                },
                length(t) {
                    const e = this.navChildren.length;
                    if (this.nav && t !== e) {
                        de(this.nav);
                        for (let e = 0; e < t; e++) pe(this.nav, `<li ${this.attrItem}="${e}"><a href></a></li>`);
                    }
                },
            },
            connected() {
                K(this.$el, { role: this.role, "aria-roledescription": "carousel" });
            },
            update: [
                {
                    write() {
                        this.navItems.concat(this.nav).forEach((t) => t && (t.hidden = !this.maxIndex)), this.updateNav();
                    },
                    events: ["resize"],
                },
            ],
            events: [
                {
                    name: "click keydown",
                    delegate() {
                        return this.selNavItem;
                    },
                    handler(t) {
                        !wt(t.target, "a,button") || ("click" !== t.type && t.keyCode !== Dn) || (t.preventDefault(), this.show(et(t.current, this.attrItem)));
                    },
                },
                { name: "itemshow", handler: "updateNav" },
                {
                    name: "keydown",
                    delegate() {
                        return this.selNavItem;
                    },
                    handler(t) {
                        const { current: e, keyCode: i } = t;
                        if (!k(et(e, this.attrItem))) return;
                        let n = i === On ? 0 : i === Mn ? "last" : i === Nn ? "previous" : i === Hn ? "next" : -1;
                        ~n && (t.preventDefault(), this.show(n));
                    },
                },
            ],
            methods: {
                updateNav() {
                    const t = this.getValidIndex();
                    for (const e of this.navItems) {
                        const i = et(e, this.attrItem),
                            n = ke("a,button", e) || e;
                        if (k(i)) {
                            const s = B(i) === t;
                            at(e, this.clsActive, s), K(n, { "aria-selected": s, tabindex: s ? null : -1 }), s && n && bt(gt(e), ":focus-within") && n.focus();
                        } else at(e, "st-invisible", this.finite && (("previous" === i && 0 === t) || ("next" === i && t >= this.maxIndex)));
                    }
                },
            },
        },
        Rs = {
            mixins: [hs, ps, Vs, ls],
            props: { clsActivated: Boolean, easing: String, index: Number, finite: Boolean, velocity: Number },
            data: () => ({ easing: "ease", finite: !1, velocity: 1, index: 0, prevIndex: -1, stack: [], percent: 0, clsActive: "st-active", clsActivated: !1, Transitioner: !1, transitionOptions: {} }),
            connected() {
                (this.prevIndex = -1), (this.index = this.getValidIndex(this.$props.index)), (this.stack = []);
            },
            disconnected() {
                nt(this.slides, this.clsActive);
            },
            computed: {
                duration: ({ velocity: t }, e) => Us(e.offsetWidth / t),
                list: ({ selList: t }, e) => ke(t, e),
                maxIndex() {
                    return this.length - 1;
                },
                slides() {
                    return yt(this.list);
                },
                length() {
                    return this.slides.length;
                },
            },
            watch: {
                slides(t, e) {
                    e && this.$emit();
                },
            },
            observe: hn(),
            methods: {
                show(t, e = !1) {
                    var i;
                    if (this.dragging || !this.length) return;
                    const { stack: n } = this,
                        s = e ? 0 : n.length,
                        o = () => {
                            n.splice(s, 1), n.length && this.show(n.shift(), !0);
                        };
                    if ((n[e ? "unshift" : "push"](t), !e && n.length > 1)) return void (2 === n.length && (null == (i = this._transitioner) || i.forward(Math.min(this.duration, 200))));
                    const r = this.getIndex(this.index),
                        a = rt(this.slides, this.clsActive) && this.slides[r],
                        l = this.getIndex(t, this.index),
                        h = this.slides[l];
                    if (a === h) return void o();
                    if (
                        ((this.dir = (function (t, e) {
                            return "next" === t ? 1 : "previous" === t || t < e ? -1 : 1;
                        })(t, r)),
                        (this.prevIndex = r),
                        (this.index = l),
                        (a && !qt(a, "beforeitemhide", [this])) || !qt(h, "beforeitemshow", [this, a]))
                    )
                        return (this.index = this.prevIndex), void o();
                    const c = this._show(a, h, e).then(() => {
                        a && qt(a, "itemhidden", [this]), qt(h, "itemshown", [this]), n.shift(), (this._transitioner = null), requestAnimationFrame(() => n.length && this.show(n.shift(), !0));
                    });
                    return a && qt(a, "itemhide", [this]), qt(h, "itemshow", [this]), c;
                },
                getIndex(t = this.index, e = this.index) {
                    return q(G(t, this.slides, e, this.finite), 0, Math.max(0, this.maxIndex));
                },
                getValidIndex(t = this.index, e = this.prevIndex) {
                    return this.getIndex(t, e);
                },
                _show(t, e, i) {
                    if (
                        ((this._transitioner = this._getTransitioner(t, e, this.dir, {
                            easing: i ? (e.offsetWidth < 600 ? "cubic-bezier(0.25, 0.46, 0.45, 0.94)" : "cubic-bezier(0.165, 0.84, 0.44, 1)") : this.easing,
                            ...this.transitionOptions,
                        })),
                        !i && !t)
                    )
                        return this._translate(1), Promise.resolve();
                    const { length: n } = this.stack;
                    return this._transitioner[n > 1 ? "forward" : "show"](n > 1 ? Math.min(this.duration, 75 + 75 / (n - 1)) : this.duration, this.percent);
                },
                _translate(t, e = this.prevIndex, i = this.index) {
                    const n = this._getTransitioner(e !== i && e, i);
                    return n.translate(t), n;
                },
                _getTransitioner(t = this.prevIndex, e = this.index, i = this.dir || 1, n = this.transitionOptions) {
                    return new this.Transitioner(C(t) ? this.slides[t] : t, C(e) ? this.slides[e] : e, i * (Xe ? -1 : 1), n);
                },
            },
        };
    function Us(t) {
        return 0.5 * t + 300;
    }
    var Xs = {
            mixins: [Rs],
            props: { animation: String },
            data: {
                animation: "slide",
                clsActivated: "st-transition-active",
                Animations: ns,
                Transitioner: function (t, e, i, { animation: n, easing: s }) {
                    const { percent: o, translate: r, show: a = V } = n,
                        l = a(i);
                    let h;
                    return {
                        dir: i,
                        show(n, o = 0, r) {
                            const a = r ? "linear" : s;
                            return (
                                (n -= Math.round(n * q(o, -1, 1))),
                                this.translate(o),
                                as(e, "itemin", { percent: o, duration: n, timing: a, dir: i }),
                                as(t, "itemout", { percent: 1 - o, duration: n, timing: a, dir: i }),
                                new Promise((i) => {
                                    h || (h = i),
                                        Promise.all([ne.start(e, l[1], n, a), ne.start(t, l[0], n, a)]).then(() => {
                                            this.reset(), h();
                                        }, V);
                                })
                            );
                        },
                        cancel: () => ne.cancel([e, t]),
                        reset() {
                            for (const i in l[0]) Kt([e, t], i, "");
                        },
                        async forward(t, e = this.percent()) {
                            return await this.cancel(), this.show(t, e, !0);
                        },
                        translate(n) {
                            this.reset();
                            const s = r(n, i);
                            Kt(e, s[1]), Kt(t, s[0]), as(e, "itemtranslatein", { percent: n, dir: i }), as(t, "itemtranslateout", { percent: 1 - n, dir: i });
                        },
                        percent: () => o(t || e, e, i),
                        getDistance: () => (null == t ? void 0 : t.offsetWidth),
                    };
                },
            },
            computed: {
                animation: ({ animation: t, Animations: e }) => ({ ...(e[t] || e.slide), name: t }),
                transitionOptions() {
                    return { animation: this.animation };
                },
            },
            events: {
                beforeitemshow({ target: t }) {
                    it(t, this.clsActive);
                },
                itemshown({ target: t }) {
                    it(t, this.clsActivated);
                },
                itemhidden({ target: t }) {
                    nt(t, this.clsActive, this.clsActivated);
                },
            },
        },
        Ys = {
            ...ns,
            fade: { show: () => [{ opacity: 0 }, { opacity: 1 }], percent: (t) => 1 - Kt(t, "opacity"), translate: (t) => [{ opacity: 1 - t }, { opacity: t }] },
            scale: {
                show: () => [
                    { opacity: 0, transform: rs(0.8) },
                    { opacity: 1, transform: rs(1) },
                ],
                percent: (t) => 1 - Kt(t, "opacity"),
                translate: (t) => [
                    { opacity: 1 - t, transform: rs(1 - 0.2 * t) },
                    { opacity: t, transform: rs(0.8 + 0.2 * t) },
                ],
            },
        },
        Js = {
            mixins: [Kn, Xs],
            functional: !0,
            props: { delayControls: Number, preload: Number, videoAutoplay: Boolean, template: String },
            data: () => ({
                preload: 1,
                videoAutoplay: !1,
                delayControls: 3e3,
                items: [],
                cls: "st-open",
                clsPage: "st-lightbox-page",
                selList: ".st-lightbox-items",
                attrItem: "st-lightbox-item",
                selClose: ".st-close-large",
                selCaption: ".st-lightbox-caption",
                pauseOnHover: !1,
                velocity: 2,
                Animations: Ys,
                template:
                    '<div class="st-lightbox st-overflow-hidden"> <ul class="st-lightbox-items"></ul> <div class="st-lightbox-toolbar st-position-top st-text-right st-transition-slide-top st-transition-opaque"> <button class="st-lightbox-toolbar-icon st-close-large" type="button" st-close></button> </div> <a class="st-lightbox-button st-position-center-left st-position-medium st-transition-fade" href st-slidenav-previous st-lightbox-item="previous"></a> <a class="st-lightbox-button st-position-center-right st-position-medium st-transition-fade" href st-slidenav-next st-lightbox-item="next"></a> <div class="st-lightbox-toolbar st-lightbox-caption st-position-bottom st-text-center st-transition-slide-bottom st-transition-opaque"></div> </div>',
            }),
            created() {
                const t = ke(this.template),
                    e = ke(this.selList, t);
                this.items.forEach(() => pe(e, "<li>"));
                const i = ke("[st-close]", t),
                    n = this.t("close");
                i && n && (i.dataset.i18n = JSON.stringify({ label: n })), this.$mount(pe(this.container, t));
            },
            computed: { caption: ({ selCaption: t }, e) => ke(t, e) },
            events: [
                { name: `${Ze} ${Ge} keydown`, handler: "showControls" },
                {
                    name: "click",
                    self: !0,
                    delegate() {
                        return `${this.selList} > *`;
                    },
                    handler(t) {
                        t.defaultPrevented || this.hide();
                    },
                },
                {
                    name: "shown",
                    self: !0,
                    handler() {
                        this.showControls();
                    },
                },
                {
                    name: "hide",
                    self: !0,
                    handler() {
                        this.hideControls(), nt(this.slides, this.clsActive), ne.stop(this.slides);
                    },
                },
                {
                    name: "hidden",
                    self: !0,
                    handler() {
                        this.$destroy(!0);
                    },
                },
                {
                    name: "keyup",
                    el: () => document,
                    handler({ keyCode: t }) {
                        if (!this.isToggled(this.$el) || !this.draggable) return;
                        let e = -1;
                        t === Nn ? (e = "previous") : t === Hn ? (e = "next") : t === On ? (e = 0) : t === Mn && (e = "last"), ~e && this.show(e);
                    },
                },
                {
                    name: "beforeitemshow",
                    handler(t) {
                        this.isToggled() || ((this.draggable = !1), t.preventDefault(), this.toggleElement(this.$el, !0, !1), (this.animation = Ys.scale), nt(t.target, this.clsActive), this.stack.splice(1, 0, this.index));
                    },
                },
                {
                    name: "itemshow",
                    handler() {
                        ue(this.caption, this.getItem().caption || "");
                        for (let t = -this.preload; t <= this.preload; t++) this.loadItem(this.index + t);
                    },
                },
                {
                    name: "itemshown",
                    handler() {
                        this.draggable = this.$props.draggable;
                    },
                },
                {
                    name: "itemload",
                    async handler(t, e) {
                        const { source: i, type: n, alt: s = "", poster: o, attrs: r = {} } = e;
                        if ((this.setItem(e, "<span st-spinner></span>"), !i)) return;
                        let a;
                        const l = { allowfullscreen: "", style: "max-width: 100%; box-sizing: border-box;", "st-responsive": "", "st-video": `${this.videoAutoplay}` };
                        if ("image" === n || i.match(/\.(avif|jpe?g|jfif|a?png|gif|svg|webp)($|\?)/i)) {
                            const t = Gs("img", { src: i, alt: s, ...r });
                            Lt(t, "load", () => this.setItem(e, t)), Lt(t, "error", () => this.setError(e));
                        } else if ("video" === n || i.match(/\.(mp4|webm|ogv)($|\?)/i)) {
                            const t = Gs("video", { src: i, poster: o, controls: "", playsinline: "", "st-video": `${this.videoAutoplay}`, ...r });
                            Lt(t, "loadedmetadata", () => this.setItem(e, t)), Lt(t, "error", () => this.setError(e));
                        } else if ("iframe" === n || i.match(/\.(html|php)($|\?)/i)) this.setItem(e, Gs("iframe", { src: i, allowfullscreen: "", class: "st-lightbox-iframe", ...r }));
                        else if ((a = i.match(/\/\/(?:.*?youtube(-nocookie)?\..*?(?:[?&]v=|\/shorts\/)|youtu\.be\/)([\w-]{11})[&?]?(.*)?/)))
                            this.setItem(e, Gs("iframe", { src: `https://www.youtube${a[1] || ""}.com/embed/${a[2]}${a[3] ? `?${a[3]}` : ""}`, width: 1920, height: 1080, ...l, ...r }));
                        else if ((a = i.match(/\/\/.*?vimeo\.[a-z]+\/(\d+)[&?]?(.*)?/)))
                            try {
                                const { height: t, width: n } = await (await fetch(`https://vimeo.com/api/oembed.json?maxwidth=1920&url=${encodeURI(i)}`, { credentials: "omit" })).json();
                                this.setItem(e, Gs("iframe", { src: `https://player.vimeo.com/video/${a[1]}${a[2] ? `?${a[2]}` : ""}`, width: n, height: t, ...l, ...r }));
                            } catch (t) {
                                this.setError(e);
                            }
                    },
                },
            ],
            methods: {
                loadItem(t = this.index) {
                    const e = this.getItem(t);
                    this.getSlide(e).childElementCount || qt(this.$el, "itemload", [e]);
                },
                getItem(t = this.index) {
                    return this.items[G(t, this.slides)];
                },
                setItem(t, e) {
                    qt(this.$el, "itemloaded", [this, ue(this.getSlide(t), e)]);
                },
                getSlide(t) {
                    return this.slides[this.items.indexOf(t)];
                },
                setError(t) {
                    this.setItem(t, '<span st-icon="icon: bolt; ratio: 2"></span>');
                },
                showControls() {
                    clearTimeout(this.controlsTimer), (this.controlsTimer = setTimeout(this.hideControls, this.delayControls)), it(this.$el, "st-active", "st-transition-active");
                },
                hideControls() {
                    nt(this.$el, "st-active", "st-transition-active");
                },
            },
        };
    function Gs(t, e) {
        const i = Se(`<${t}>`);
        return K(i, e), i;
    }
    var Zs = {
        install: function (t, e) {
            t.lightboxPanel || t.component("lightboxPanel", Js);
            p(e.props, t.component("lightboxPanel").options.props);
        },
        props: { toggle: String },
        data: { toggle: "a" },
        computed: { toggles: ({ toggle: t }, e) => Te(t, e) },
        watch: {
            toggles(t) {
                this.hide();
                for (const e of t) ce(e, "a") && K(e, "role", "button");
            },
        },
        disconnected() {
            this.hide();
        },
        events: {
            name: "click",
            delegate() {
                return `${this.toggle}:not(.st-disabled)`;
            },
            handler(t) {
                t.preventDefault(), this.show(t.current);
            },
        },
        methods: {
            show(t) {
                const e = j(this.toggles.map(Ks), "source");
                if (x(t)) {
                    const { source: i } = Ks(t);
                    t = d(e, ({ source: t }) => i === t);
                }
                return (this.panel = this.panel || this.$create("lightboxPanel", { ...this.$props, items: e })), Lt(this.panel.$el, "hidden", () => (this.panel = null)), this.panel.show(t);
            },
            hide() {
                var t;
                return null == (t = this.panel) ? void 0 : t.hide();
            },
        },
    };
    function Ks(t) {
        const e = {};
        for (const i of ["href", "caption", "type", "poster", "alt", "attrs"]) e["href" === i ? "source" : i] = et(t, i);
        return (e.attrs = an(e.attrs)), e;
    }
    var Qs = {
        mixins: [Vn],
        functional: !0,
        args: ["message", "status"],
        data: { message: "", status: "", timeout: 5e3, group: "", pos: "top-center", clsContainer: "st-notification", clsClose: "st-notification-close", clsMsg: "st-notification-message" },
        install: function (t) {
            t.notification.closeAll = function (e, i) {
                Ce(document.body, (n) => {
                    const s = t.getComponent(n, "notification");
                    !s || (e && e !== s.group) || s.close(i);
                });
            };
        },
        computed: {
            marginProp: ({ pos: t }) => "margin" + (l(t, "top") ? "Top" : "Bottom"),
            startProps() {
                return { opacity: 0, [this.marginProp]: -this.$el.offsetHeight };
            },
        },
        created() {
            const t = `${this.clsContainer}-${this.pos}`;
            let e = ke(`.${t}`, this.container);
            (e && dt(e)) || (e = pe(this.container, `<div class="${this.clsContainer} ${t}"></div>`)),
                this.$mount(pe(e, `<div class="${this.clsMsg}${this.status ? ` ${this.clsMsg}-${this.status}` : ""}" role="alert"> <a href class="${this.clsClose}" data-st-close></a> <div>${this.message}</div> </div>`));
        },
        async connected() {
            const t = P(Kt(this.$el, this.marginProp));
            await ne.start(Kt(this.$el, this.startProps), { opacity: 1, [this.marginProp]: t }), this.timeout && (this.timer = setTimeout(this.close, this.timeout));
        },
        events: {
            click(t) {
                wt(t.target, 'a[href="#"],a[href=""]') && t.preventDefault(), this.close();
            },
            [Qe]() {
                this.timer && clearTimeout(this.timer);
            },
            [ti]() {
                this.timeout && (this.timer = setTimeout(this.close, this.timeout));
            },
        },
        methods: {
            async close(t) {
                this.timer && clearTimeout(this.timer),
                    t || (await ne.start(this.$el, this.startProps)),
                    ((t) => {
                        const e = gt(t);
                        qt(t, "close", [this]), be(t), (null == e ? void 0 : e.hasChildNodes()) || be(e);
                    })(this.$el);
            },
        },
    };
    var to = {
        props: { media: Boolean },
        data: { media: !1 },
        connected() {
            const t = (function (t, e) {
                if (I(t))
                    if (l(t, "@")) t = P(Kt(e, `--st-breakpoint-${t.substr(1)}`));
                    else if (isNaN(t)) return t;
                return t && k(t) ? `(min-width: ${t}px)` : "";
            })(this.media, this.$el);
            if (((this.matchMedia = !0), t)) {
                this.mediaObj = window.matchMedia(t);
                const e = () => {
                    (this.matchMedia = this.mediaObj.matches), qt(this.$el, Vt("mediachange", !1, !0, [this.mediaObj]));
                };
                (this.offMediaObj = Lt(this.mediaObj, "change", () => {
                    e(), this.$emit("resize");
                })),
                    e();
            }
        },
        disconnected() {
            var t;
            null == (t = this.offMediaObj) || t.call(this);
        },
    };
    function eo(t) {
        return Math.ceil(
            Math.max(
                0,
                ...Te("[stroke]", t).map((t) => {
                    try {
                        return t.getTotalLength();
                    } catch (t) {
                        return 0;
                    }
                })
            )
        );
    }
    const io = {
            x: oo,
            y: oo,
            rotate: oo,
            scale: oo,
            color: ro,
            backgroundColor: ro,
            borderColor: ro,
            blur: ao,
            hue: ao,
            fopacity: ao,
            grayscale: ao,
            invert: ao,
            saturate: ao,
            sepia: ao,
            opacity: function (t, e, i) {
                1 === i.length && i.unshift(wo(e, t, ""));
                return (
                    (i = po(i)),
                    (e, n) => {
                        e[t] = go(i, n);
                    }
                );
            },
            stroke: function (t, e, i) {
                1 === i.length && i.unshift(0);
                const n = bo(i),
                    s = eo(e);
                if (((i = po(i.reverse(), (t) => ((t = P(t)), "%" === n ? (t * s) / 100 : t))), !i.some(([t]) => t))) return V;
                return (
                    Kt(e, "strokeDasharray", s),
                    (t, e) => {
                        t.strokeDashoffset = go(i, e);
                    }
                );
            },
            bgx: lo,
            bgy: lo,
        },
        { keys: no } = Object;
    var so = {
        mixins: [to],
        props: $o(no(io), "list"),
        data: $o(no(io), void 0),
        computed: {
            props(t, e) {
                const i = {};
                for (const e in t) e in io && !E(t[e]) && (i[e] = t[e].slice());
                const n = {};
                for (const t in i) n[t] = io[t](t, e, i[t], i);
                return n;
            },
        },
        events: {
            load() {
                this.$emit();
            },
        },
        methods: {
            reset() {
                for (const t in this.getCss(0)) Kt(this.$el, t, "");
            },
            getCss(t) {
                const e = {};
                for (const i in this.props) this.props[i](e, q(t));
                return (e.willChange = Object.keys(e).map(Qt).join(",")), e;
            },
        },
    };
    function oo(t, e, i) {
        let n,
            s = bo(i) || { x: "px", y: "px", rotate: "deg" }[t] || "";
        return (
            "x" === t || "y" === t
                ? ((t = `translate${a(t)}`), (n = (t) => P(P(t).toFixed("px" === s ? 0 : 6))))
                : "scale" === t &&
                  ((s = ""),
                  (n = (t) => {
                      var i;
                      return bo([t]) ? Fe(t, "width", e, !0) / e["offset" + ((null == (i = t.endsWith) ? void 0 : i.call(t, "vh")) ? "Height" : "Width")] : P(t);
                  })),
            1 === i.length && i.unshift("scale" === t ? 1 : 0),
            (i = po(i, n)),
            (e, n) => {
                e.transform = `${e.transform || ""} ${t}(${go(i, n)}${s})`;
            }
        );
    }
    function ro(t, e, i) {
        return (
            1 === i.length && i.unshift(wo(e, t, "")),
            (i = po(i, (t) =>
                (function (t, e) {
                    return wo(t, "color", e).split(/[(),]/g).slice(1, -1).concat(1).slice(0, 4).map(P);
                })(e, t)
            )),
            (e, n) => {
                const [s, o, r] = mo(i, n),
                    a = s.map((t, e) => ((t += r * (o[e] - t)), 3 === e ? P(t) : parseInt(t, 10))).join(",");
                e[t] = `rgba(${a})`;
            }
        );
    }
    function ao(t, e, i) {
        1 === i.length && i.unshift(0);
        const n = bo(i) || { blur: "px", hue: "deg" }[t] || "%";
        return (
            (t = { fopacity: "opacity", hue: "hue-rotate" }[t] || t),
            (i = po(i)),
            (e, s) => {
                const o = go(i, s);
                e.filter = `${e.filter || ""} ${t}(${o + n})`;
            }
        );
    }
    function lo(t, e, i, n) {
        1 === i.length && i.unshift(0);
        const s = "bgy" === t ? "height" : "width";
        n[t] = po(i, (t) => Fe(t, s, e));
        const o = ["bgx", "bgy"].filter((t) => t in n);
        if (2 === o.length && "bgx" === t) return V;
        if ("cover" === wo(e, "backgroundSize", ""))
            return (function (t, e, i, n) {
                const s = (function (t) {
                    const e = Kt(t, "backgroundImage").replace(/^none|url\(["']?(.+?)["']?\)$/, "$1");
                    if (uo[e]) return uo[e];
                    const i = new Image();
                    if (e && ((i.src = e), !i.naturalWidth))
                        return (
                            (i.onload = () => {
                                (uo[e] = fo(i)), qt(t, Vt("load", !1));
                            }),
                            fo(i)
                        );
                    return (uo[e] = fo(i));
                })(e);
                if (!s.width) return V;
                const o = { width: e.offsetWidth, height: e.offsetHeight },
                    r = ["bgx", "bgy"].filter((t) => t in n),
                    a = {};
                for (const t of r) {
                    const e = n[t].map(([t]) => t),
                        i = Math.min(...e),
                        s = Math.max(...e),
                        r = e.indexOf(i) < e.indexOf(s),
                        l = s - i;
                    (a[t] = (r ? -l : 0) - (r ? i : s) + "px"), (o["bgy" === t ? "height" : "width"] += l);
                }
                const l = J.cover(s, o);
                for (const t of r) {
                    const i = "bgy" === t ? "height" : "width",
                        n = l[i] - o[i];
                    a[t] = `max(${ho(e, t)},-${n}px) + ${a[t]}`;
                }
                const h = co(r, a, n);
                return (t, e) => {
                    h(t, e), (t.backgroundSize = `${l.width}px ${l.height}px`), (t.backgroundRepeat = "no-repeat");
                };
            })(0, e, 0, n);
        const r = {};
        for (const t of o) r[t] = ho(e, t);
        return co(o, r, n);
    }
    function ho(t, e) {
        return wo(t, `background-position-${e.substr(-1)}`, "");
    }
    function co(t, e, i) {
        return function (n, s) {
            for (const o of t) {
                const t = go(i[o], s);
                n[`background-position-${o.substr(-1)}`] = `calc(${e[o]} + ${t}px)`;
            }
        };
    }
    const uo = {};
    function fo(t) {
        return { width: t.naturalWidth, height: t.naturalHeight };
    }
    function po(t, e = P) {
        const i = [],
            { length: n } = t;
        let s = 0;
        for (let o = 0; o < n; o++) {
            let [r, a] = I(t[o]) ? t[o].trim().split(/ (?![^(]*\))/) : [t[o]];
            if (((r = e(r)), (a = a ? P(a) / 100 : null), 0 === o ? (null === a ? (a = 0) : a && i.push([r, 0])) : o === n - 1 && (null === a ? (a = 1) : 1 !== a && (i.push([r, a]), (a = 1))), i.push([r, a]), null === a)) s++;
            else if (s) {
                const t = i[o - s - 1][1],
                    e = (a - t) / (s + 1);
                for (let n = s; n > 0; n--) i[o - n][1] = t + e * (s - n + 1);
                s = 0;
            }
        }
        return i;
    }
    function mo(t, e) {
        const i = d(t.slice(1), ([, t]) => e <= t) + 1;
        return [t[i - 1][0], t[i][0], (e - t[i - 1][1]) / (t[i][1] - t[i - 1][1])];
    }
    function go(t, e) {
        const [i, n, s] = mo(t, e);
        return i + Math.abs(i - n) * s * (i < n ? 1 : -1);
    }
    const vo = /^-?\d+(?:\.\d+)?(\S+)?/;
    function bo(t, e) {
        var i;
        for (const e of t) {
            const t = null == (i = e.match) ? void 0 : i.call(e, vo);
            if (t) return t[1];
        }
        return e;
    }
    function wo(t, e, i) {
        const n = t.style[e],
            s = Kt(Kt(t, e, i), e);
        return (t.style[e] = n), s;
    }
    function $o(t, e) {
        return t.reduce((t, i) => ((t[i] = e), t), {});
    }
    var xo = {
        mixins: [so],
        props: { target: String, viewport: Number, easing: Number, start: String, end: String },
        data: { target: !1, viewport: 1, easing: 1, start: 0, end: 0 },
        computed: {
            target: ({ target: t }, e) => yo((t && kt(t, e)) || e),
            start({ start: t }) {
                return Fe(t, "height", this.target, !0);
            },
            end({ end: t, viewport: e }) {
                return Fe(t || ((e = 100 * (1 - e)) && `${e}vh+${e}%`), "height", this.target, !0);
            },
        },
        observe: [fn(), pn({ target: ({ target: t }) => t }), hn({ target: ({ $el: t, target: e }) => [t, e, Pi(e, !0)] })],
        update: {
            read({ percent: t }, e) {
                if ((e.has("scroll") || (t = !1), !dt(this.$el))) return !1;
                if (!this.matchMedia) return;
                const i = t;
                return {
                    percent: (t = (function (t, e) {
                        return e >= 0 ? Math.pow(t, e + 1) : 1 - Math.pow(1 - t, 1 - e);
                    })(_i(this.target, this.start, this.end), this.easing)),
                    style: i !== t && this.getCss(t),
                };
            },
            write({ style: t }) {
                this.matchMedia ? t && Kt(this.$el, t) : this.reset();
            },
            events: ["scroll", "resize"],
        },
    };
    function yo(t) {
        return t ? ("offsetTop" in t ? t : yo(gt(t))) : document.documentElement;
    }
    var So = {
            update: {
                write() {
                    if (this.stack.length || this.dragging) return;
                    const t = this.getValidIndex();
                    ~this.prevIndex && this.index === t ? this._translate(1, this.prevIndex, this.index) : this.show(t);
                },
                events: ["resize"],
            },
        },
        Io = { observe: un({ target: ({ slides: t }) => t, targets: (t) => t.getAdjacentSlides() }) };
    function Co(t, e, i) {
        const n = Eo(t, e);
        return i
            ? n -
                  (function (t, e) {
                      return Be(e).width / 2 - Be(t).width / 2;
                  })(t, e)
            : Math.min(n, ko(e));
    }
    function ko(t) {
        return Math.max(0, To(t) - Be(t).width);
    }
    function To(t) {
        return L(yt(t), (t) => Be(t).width);
    }
    function Eo(t, e) {
        return (t && (Ae(t).left + (Xe ? Be(t).width - Be(e).width : 0)) * (Xe ? -1 : 1)) || 0;
    }
    function _o(t, e) {
        e -= 1;
        const i = Be(t).width,
            n = e + i + 2;
        return yt(t).filter((s) => {
            const o = Eo(s, t),
                r = o + Math.min(Be(s).width, i);
            return o >= e && r <= n;
        });
    }
    function Bo(t, e, i) {
        qt(t, Vt(e, !1, !1, i));
    }
    var Po = {
        mixins: [Ki, Rs, So, Io],
        props: { center: Boolean, sets: Boolean },
        data: {
            center: !1,
            sets: !1,
            attrItem: "st-slider-item",
            selList: ".st-slider-items",
            selNav: ".st-slider-nav",
            clsContainer: "st-slider-container",
            Transitioner: function (t, e, i, { center: n, easing: s, list: o }) {
                const r = t ? Co(t, o, n) : Co(e, o, n) + Be(e).width * i,
                    a = e ? Co(e, o, n) : r + Be(t).width * i * (Xe ? -1 : 1);
                let l;
                return {
                    dir: i,
                    show(e, n = 0, r) {
                        const h = r ? "linear" : s;
                        return (
                            (e -= Math.round(e * q(n, -1, 1))),
                            this.translate(n),
                            (n = t ? n : q(n, 0, 1)),
                            Bo(this.getItemIn(), "itemin", { percent: n, duration: e, timing: h, dir: i }),
                            t && Bo(this.getItemIn(!0), "itemout", { percent: 1 - n, duration: e, timing: h, dir: i }),
                            new Promise((t) => {
                                l || (l = t), ne.start(o, { transform: os(-a * (Xe ? -1 : 1), "px") }, e, h).then(l, V);
                            })
                        );
                    },
                    cancel: () => ne.cancel(o),
                    reset() {
                        Kt(o, "transform", "");
                    },
                    async forward(t, e = this.percent()) {
                        return await this.cancel(), this.show(t, e, !0);
                    },
                    translate(n) {
                        const s = this.getDistance() * i * (Xe ? -1 : 1);
                        Kt(o, "transform", os(q(s - s * n - a, -To(o), Be(o).width) * (Xe ? -1 : 1), "px"));
                        const r = this.getActives(),
                            l = this.getItemIn(),
                            h = this.getItemIn(!0);
                        n = t ? q(n, -1, 1) : 0;
                        for (const s of yt(o)) {
                            const a = c(r, s),
                                d = s === l,
                                u = s === h;
                            Bo(s, "itemtranslate" + (d || (!u && (a || (i * (Xe ? -1 : 1) == -1) ^ (Eo(s, o) > Eo(t || e)))) ? "in" : "out"), { dir: i, percent: u ? 1 - n : d ? n : a ? 1 : 0 });
                        }
                    },
                    percent: () => Math.abs((Kt(o, "transform").split(",")[4] * (Xe ? -1 : 1) + r) / (a - r)),
                    getDistance: () => Math.abs(a - r),
                    getItemIn(i = !1) {
                        let s = this.getActives(),
                            r = _o(o, Co(e || t, o, n));
                        if (i) {
                            const t = s;
                            (s = r), (r = t);
                        }
                        return r[d(r, (t) => !c(s, t))];
                    },
                    getActives: () => _o(o, Co(t || e, o, n)),
                };
            },
        },
        computed: {
            avgWidth() {
                return To(this.list) / this.length;
            },
            finite({ finite: t }) {
                return (
                    t ||
                    (function (t, e) {
                        if (!t || t.length < 2) return !0;
                        const { width: i } = Be(t);
                        if (!e)
                            return (
                                Math.ceil(To(t)) <
                                Math.trunc(
                                    i +
                                        (function (t) {
                                            return Math.max(0, ...yt(t).map((t) => Be(t).width));
                                        })(t)
                                )
                            );
                        const n = yt(t),
                            s = Math.trunc(i / 2);
                        for (const t in n) {
                            const e = n[t],
                                i = Be(e).width,
                                o = new Set([e]);
                            let r = 0;
                            for (const e of [-1, 1]) {
                                let a = i / 2,
                                    l = 0;
                                for (; a < s; ) {
                                    const i = n[G(+t + e + l++ * e, n)];
                                    if (o.has(i)) return !0;
                                    (a += Be(i).width), o.add(i);
                                }
                                r = Math.max(r, i / 2 + Be(n[G(+t + e, n)]).width / 2 - (a - s));
                            }
                            if (
                                r >
                                L(
                                    n.filter((t) => !o.has(t)),
                                    (t) => Be(t).width
                                )
                            )
                                return !0;
                        }
                        return !1;
                    })(this.list, this.center)
                );
            },
            maxIndex() {
                if (!this.finite || (this.center && !this.sets)) return this.length - 1;
                if (this.center) return z(this.sets);
                let t = 0;
                const e = ko(this.list),
                    i = d(this.slides, (i) => {
                        if (t >= e) return !0;
                        t += Be(i).width;
                    });
                return ~i ? i : this.length - 1;
            },
            sets({ sets: t }) {
                if (!t) return;
                let e = 0;
                const i = [],
                    n = Be(this.list).width;
                for (let t = 0; t < this.length; t++) {
                    const s = Be(this.slides[t]).width;
                    e + s > n && (e = 0), this.center ? e < n / 2 && e + s + Be(G(+t + 1, this.slides)).width / 2 > n / 2 && (i.push(+t), (e = n / 2 - s / 2)) : 0 === e && i.push(Math.min(+t, this.maxIndex)), (e += s);
                }
                return i.length ? i : void 0;
            },
            transitionOptions() {
                return { center: this.center, list: this.list };
            },
            slides() {
                return yt(this.list).filter(dt);
            },
        },
        connected() {
            at(this.$el, this.clsContainer, !ke(`.${this.clsContainer}`, this.$el));
        },
        observe: hn({ target: ({ slides: t }) => t }),
        update: {
            write() {
                for (const t of this.navItems) {
                    const e = B(et(t, this.attrItem));
                    !1 !== e && (t.hidden = !this.maxIndex || e > this.maxIndex || (this.sets && !c(this.sets, e)));
                }
                !this.length || this.dragging || this.stack.length || (this.reorder(), this._translate(1)), this.updateActiveClasses();
            },
            events: ["resize"],
        },
        events: {
            beforeitemshow(t) {
                !this.dragging && this.sets && this.stack.length < 2 && !c(this.sets, this.index) && (this.index = this.getValidIndex());
                const e = Math.abs(this.index - this.prevIndex + ((this.dir > 0 && this.index < this.prevIndex) || (this.dir < 0 && this.index > this.prevIndex) ? (this.maxIndex + 1) * this.dir : 0));
                if (!this.dragging && e > 1) {
                    for (let t = 0; t < e; t++) this.stack.splice(1, 0, this.dir > 0 ? "next" : "previous");
                    return void t.preventDefault();
                }
                const i = this.dir < 0 || !this.slides[this.prevIndex] ? this.index : this.prevIndex;
                (this.duration = Us(this.avgWidth / this.velocity) * (Be(this.slides[i]).width / this.avgWidth)), this.reorder();
            },
            itemshow() {
                ~this.prevIndex && it(this._getTransitioner().getItemIn(), this.clsActive);
            },
            itemshown() {
                this.updateActiveClasses();
            },
        },
        methods: {
            reorder() {
                if (this.finite) return void Kt(this.slides, "order", "");
                const t = this.dir > 0 && this.slides[this.prevIndex] ? this.prevIndex : this.index;
                if ((this.slides.forEach((e, i) => Kt(e, "order", this.dir > 0 && i < t ? 1 : this.dir < 0 && i >= this.index ? -1 : "")), !this.center)) return;
                const e = this.slides[t];
                let i = Be(this.list).width / 2 - Be(e).width / 2,
                    n = 0;
                for (; i > 0; ) {
                    const e = this.getIndex(--n + t, t),
                        s = this.slides[e];
                    Kt(s, "order", e > t ? -2 : -1), (i -= Be(s).width);
                }
            },
            updateActiveClasses() {
                const t = this._getTransitioner(this.index).getActives(),
                    e = [this.clsActive, ((!this.sets || c(this.sets, P(this.index))) && this.clsActivated) || ""];
                for (const n of this.slides) {
                    const s = c(t, n);
                    at(n, e, s), K(n, "aria-hidden", !s);
                    for (const t of Te(pt, n)) i(t, "_tabindex") || (t._tabindex = K(t, "tabindex")), K(t, "tabindex", s ? t._tabindex : -1);
                }
            },
            getValidIndex(t = this.index, e = this.prevIndex) {
                if (((t = this.getIndex(t, e)), !this.sets)) return t;
                let i;
                do {
                    if (c(this.sets, t)) return t;
                    (i = t), (t = this.getIndex(t + this.dir, e));
                } while (t !== i);
                return t;
            },
            getAdjacentSlides() {
                const { width: t } = Be(this.list),
                    e = -t,
                    i = 2 * t,
                    n = Be(this.slides[this.index]).width,
                    s = this.center ? t / 2 - n / 2 : 0,
                    o = new Set();
                for (const t of [-1, 1]) {
                    let r = s + (t > 0 ? n : 0),
                        a = 0;
                    do {
                        const e = this.slides[this.getIndex(this.index + t + a++ * t)];
                        (r += Be(e).width * t), o.add(e);
                    } while (this.length > a && r > e && r < i);
                }
                return Array.from(o);
            },
        },
    };
    var Ao = {
        mixins: [so],
        data: { selItem: "!li" },
        beforeConnect() {
            this.item = kt(this.selItem, this.$el);
        },
        disconnected() {
            this.item = null;
        },
        events: [
            {
                name: "itemin itemout",
                self: !0,
                el() {
                    return this.item;
                },
                handler({ type: t, detail: { percent: e, duration: i, timing: n, dir: s } }) {
                    ii.read(() => {
                        if (!this.matchMedia) return;
                        const o = this.getCss(Mo(t, s, e)),
                            r = this.getCss(Do(t) ? 0.5 : s > 0 ? 1 : 0);
                        ii.write(() => {
                            Kt(this.$el, o), ne.start(this.$el, r, i, n).catch(V);
                        });
                    });
                },
            },
            {
                name: "transitioncanceled transitionend",
                self: !0,
                el() {
                    return this.item;
                },
                handler() {
                    ne.cancel(this.$el);
                },
            },
            {
                name: "itemtranslatein itemtranslateout",
                self: !0,
                el() {
                    return this.item;
                },
                handler({ type: t, detail: { percent: e, dir: i } }) {
                    ii.read(() => {
                        if (!this.matchMedia) return void this.reset();
                        const n = this.getCss(Mo(t, i, e));
                        ii.write(() => Kt(this.$el, n));
                    });
                },
            },
        ],
    };
    function Do(t) {
        return h(t, "in");
    }
    function Mo(t, e, i) {
        return (i /= 2), Do(t) ^ (e < 0) ? i : 1 - i;
    }
    var Oo = {
        ...ns,
        fade: { show: () => [{ opacity: 0, zIndex: 0 }, { zIndex: -1 }], percent: (t) => 1 - Kt(t, "opacity"), translate: (t) => [{ opacity: 1 - t, zIndex: 0 }, { zIndex: -1 }] },
        scale: { show: () => [{ opacity: 0, transform: rs(1.5), zIndex: 0 }, { zIndex: -1 }], percent: (t) => 1 - Kt(t, "opacity"), translate: (t) => [{ opacity: 1 - t, transform: rs(1 + 0.5 * t), zIndex: 0 }, { zIndex: -1 }] },
        pull: {
            show: (t) =>
                t < 0
                    ? [
                          { transform: os(30), zIndex: -1 },
                          { transform: os(), zIndex: 0 },
                      ]
                    : [
                          { transform: os(-100), zIndex: 0 },
                          { transform: os(), zIndex: -1 },
                      ],
            percent: (t, e, i) => (i < 0 ? 1 - ss(e) : ss(t)),
            translate: (t, e) =>
                e < 0
                    ? [
                          { transform: os(30 * t), zIndex: -1 },
                          { transform: os(-100 * (1 - t)), zIndex: 0 },
                      ]
                    : [
                          { transform: os(100 * -t), zIndex: 0 },
                          { transform: os(30 * (1 - t)), zIndex: -1 },
                      ],
        },
        push: {
            show: (t) =>
                t < 0
                    ? [
                          { transform: os(100), zIndex: 0 },
                          { transform: os(), zIndex: -1 },
                      ]
                    : [
                          { transform: os(-30), zIndex: -1 },
                          { transform: os(), zIndex: 0 },
                      ],
            percent: (t, e, i) => (i > 0 ? 1 - ss(e) : ss(t)),
            translate: (t, e) =>
                e < 0
                    ? [
                          { transform: os(100 * t), zIndex: 0 },
                          { transform: os(-30 * (1 - t)), zIndex: -1 },
                      ]
                    : [
                          { transform: os(-30 * t), zIndex: -1 },
                          { transform: os(100 * (1 - t)), zIndex: 0 },
                      ],
        },
    };
    const No = Ue && CSS.supports("aspect-ratio", "1/1");
    var zo = {
            mixins: [Ki, Xs, So, Io],
            props: { ratio: String, minHeight: Number, maxHeight: Number },
            data: { ratio: "16:9", minHeight: !1, maxHeight: !1, selList: ".st-slideshow-items", attrItem: "st-slideshow-item", selNav: ".st-slideshow-nav", Animations: Oo },
            watch: {
                list(t) {
                    t && No && Kt(t, { aspectRatio: this.ratio.replace(":", "/"), minHeight: this.minHeight || "", maxHeight: this.maxHeight || "", minWidth: "100%", maxWidth: "100%" });
                },
            },
            update: {
                read() {
                    if (!this.list || No) return !1;
                    let [t, e] = this.ratio.split(":").map(Number);
                    return (e = (e * this.list.offsetWidth) / t || 0), this.minHeight && (e = Math.max(this.minHeight, e)), this.maxHeight && (e = Math.min(this.maxHeight, e)), { height: e - ze(this.list, "height", "content-box") };
                },
                write({ height: t }) {
                    t > 0 && Kt(this.list, "minHeight", t);
                },
                events: ["resize"],
            },
            methods: {
                getAdjacentSlides() {
                    return [1, -1].map((t) => this.slides[this.getIndex(this.index + t)]);
                },
            },
        },
        Ho = {
            mixins: [Ki, Bn],
            props: { group: String, threshold: Number, clsItem: String, clsPlaceholder: String, clsDrag: String, clsDragState: String, clsBase: String, clsNoDrag: String, clsEmpty: String, clsCustom: String, handle: String },
            data: {
                group: !1,
                threshold: 5,
                clsItem: "st-sortable-item",
                clsPlaceholder: "st-sortable-placeholder",
                clsDrag: "st-sortable-drag",
                clsDragState: "st-drag",
                clsBase: "st-sortable",
                clsNoDrag: "st-sortable-nodrag",
                clsEmpty: "st-sortable-empty",
                clsCustom: "",
                handle: !1,
                pos: {},
            },
            created() {
                for (const t of ["init", "start", "move", "end"]) {
                    const e = this[t];
                    this[t] = (t) => {
                        p(this.pos, Gt(t)), e(t);
                    };
                }
            },
            events: { name: Ge, passive: !1, handler: "init" },
            computed: {
                target() {
                    return (this.$el.tBodies || [this.$el])[0];
                },
                items() {
                    return yt(this.target);
                },
                isEmpty() {
                    return T(this.items);
                },
                handles({ handle: t }, e) {
                    return t ? Te(t, e) : this.items;
                },
            },
            watch: {
                isEmpty(t) {
                    at(this.target, this.clsEmpty, t);
                },
                handles(t, e) {
                    Kt(e, { touchAction: "", userSelect: "" }), Kt(t, { touchAction: Ye ? "none" : "", userSelect: "none" });
                },
            },
            update: {
                write(t) {
                    if (!this.drag || !gt(this.placeholder)) return;
                    const {
                        pos: { x: e, y: i },
                        origin: { offsetTop: n, offsetLeft: s },
                        placeholder: o,
                    } = this;
                    Kt(this.drag, { top: i - n, left: e - s });
                    const r = this.getSortable(document.elementFromPoint(e, i));
                    if (!r) return;
                    const { items: a } = r;
                    if (a.some(ne.inProgress)) return;
                    const l = (function (t, e) {
                        return t[d(t, (t) => U(e, t.getBoundingClientRect()))];
                    })(a, { x: e, y: i });
                    if (a.length && (!l || l === o)) return;
                    const h = this.getSortable(o),
                        c = (function (t, e, i, n, s, o) {
                            if (!yt(t).length) return;
                            const r = e.getBoundingClientRect();
                            if (!o)
                                return (function (t, e) {
                                    const i = 1 === yt(t).length;
                                    i && pe(t, e);
                                    const n = yt(t),
                                        s = n.some((t, e) => {
                                            const i = t.getBoundingClientRect();
                                            return n.slice(e + 1).some((t) => {
                                                const e = t.getBoundingClientRect();
                                                return !Lo([i.left, i.right], [e.left, e.right]);
                                            });
                                        });
                                    i && be(e);
                                    return s;
                                })(t, i) || s < r.top + r.height / 2
                                    ? e
                                    : e.nextElementSibling;
                            const a = i.getBoundingClientRect(),
                                l = Lo([r.top, r.bottom], [a.top, a.bottom]),
                                [h, c, d, u] = l ? [n, "width", "left", "right"] : [s, "height", "top", "bottom"],
                                f = a[c] < r[c] ? r[c] - a[c] : 0;
                            if (a[d] < r[d]) return !(f && h < r[d] + f) && e.nextElementSibling;
                            if (f && h > r[u] - f) return !1;
                            return e;
                        })(r.target, l, o, e, i, r === h && t.moved !== l);
                    !1 !== c && ((c && o === c) || (r !== h ? (h.remove(o), (t.moved = l)) : delete t.moved, r.insert(o, c), this.touched.add(r)));
                },
                events: ["move"],
            },
            methods: {
                init(t) {
                    const { target: e, button: i, defaultPrevented: n } = t,
                        [s] = this.items.filter((t) => $t(e, t));
                    !s ||
                        n ||
                        i > 0 ||
                        ft(e) ||
                        $t(e, `.${this.clsNoDrag}`) ||
                        (this.handle && !$t(e, this.handle)) ||
                        (t.preventDefault(),
                        (this.touched = new Set([this])),
                        (this.placeholder = s),
                        (this.origin = { target: e, index: St(s), ...this.pos }),
                        Lt(document, Ze, this.move),
                        Lt(document, Ke, this.end),
                        this.threshold || this.start(t));
                },
                start(t) {
                    this.drag = (function (t, e) {
                        let i;
                        if (ce(e, "li", "tr")) {
                            (i = ke("<div>")), pe(i, e.cloneNode(!0).children);
                            for (const t of e.getAttributeNames()) K(i, t, e.getAttribute(t));
                        } else i = e.cloneNode(!0);
                        return pe(t, i), Kt(i, "margin", "0", "important"), Kt(i, { boxSizing: "border-box", width: e.offsetWidth, height: e.offsetHeight, padding: Kt(e, "padding") }), Me(i.firstElementChild, Me(e.firstElementChild)), i;
                    })(this.$container, this.placeholder);
                    const { left: e, top: i } = this.placeholder.getBoundingClientRect();
                    p(this.origin, { offsetLeft: this.pos.x - e, offsetTop: this.pos.y - i }),
                        it(this.drag, this.clsDrag, this.clsCustom),
                        it(this.placeholder, this.clsPlaceholder),
                        it(this.items, this.clsItem),
                        it(document.documentElement, this.clsDragState),
                        qt(this.$el, "start", [this, this.placeholder]),
                        (function (t) {
                            let e = Date.now();
                            Fo = setInterval(() => {
                                let { x: i, y: n } = t;
                                n += document.scrollingElement.scrollTop;
                                const s = 0.3 * (Date.now() - e);
                                (e = Date.now()),
                                    Bi(document.elementFromPoint(i, t.y))
                                        .reverse()
                                        .some((t) => {
                                            let { scrollTop: e, scrollHeight: i } = t;
                                            const { top: o, bottom: r, height: a } = Di(t);
                                            if (o < n && o + 35 > n) e -= s;
                                            else {
                                                if (!(r > n && r - 35 < n)) return;
                                                e += s;
                                            }
                                            if (e > 0 && e < i - a) return (t.scrollTop = e), !0;
                                        });
                            }, 15);
                        })(this.pos),
                        this.move(t);
                },
                move(t) {
                    this.drag ? this.$emit("move") : (Math.abs(this.pos.x - this.origin.x) > this.threshold || Math.abs(this.pos.y - this.origin.y) > this.threshold) && this.start(t);
                },
                end() {
                    if ((jt(document, Ze, this.move), jt(document, Ke, this.end), !this.drag)) return;
                    clearInterval(Fo);
                    const t = this.getSortable(this.placeholder);
                    this === t ? this.origin.index !== St(this.placeholder) && qt(this.$el, "moved", [this, this.placeholder]) : (qt(t.$el, "added", [t, this.placeholder]), qt(this.$el, "removed", [this, this.placeholder])),
                        qt(this.$el, "stop", [this, this.placeholder]),
                        be(this.drag),
                        (this.drag = null);
                    for (const { clsPlaceholder: t, clsItem: e } of this.touched) for (const i of this.touched) nt(i.items, t, e);
                    (this.touched = null), nt(document.documentElement, this.clsDragState);
                },
                insert(t, e) {
                    it(this.items, this.clsItem);
                    this.animate(() => (e ? me(e, t) : pe(this.target, t)));
                },
                remove(t) {
                    $t(t, this.target) && this.animate(() => be(t));
                },
                getSortable(t) {
                    do {
                        const e = this.$getComponent(t, "sortable");
                        if (e && (e === this || (!1 !== this.group && e.group === this.group))) return e;
                    } while ((t = gt(t)));
                },
            },
        };
    let Fo;
    function Lo(t, e) {
        return t[1] > e[0] && e[1] > t[0];
    }
    var jo = {
        props: { pos: String, offset: null, flip: Boolean, shift: Boolean, inset: Boolean },
        data: { pos: "bottom-" + (Xe ? "right" : "left"), offset: !1, flip: !0, shift: !0, inset: !1 },
        connected() {
            (this.pos = this.$props.pos.split("-").concat("center").slice(0, 2)), ([this.dir, this.align] = this.pos), (this.axis = c(["top", "bottom"], this.dir) ? "y" : "x");
        },
        methods: {
            positionAt(t, e, i) {
                let n = [this.getPositionOffset(t), this.getShiftOffset(t)];
                const s = [this.flip && "flip", this.shift && "shift"],
                    o = { element: [this.inset ? this.dir : He(this.dir), this.align], target: [this.dir, this.align] };
                if ("y" === this.axis) {
                    for (const t in o) o[t].reverse();
                    n.reverse(), s.reverse();
                }
                const r = (function (t) {
                        const e = Pi(t),
                            { scrollTop: i } = e;
                        return () => {
                            i !== e.scrollTop && (e.scrollTop = i);
                        };
                    })(t),
                    a = Be(t);
                Kt(t, { top: -a.height, left: -a.width }), Ni(t, e, { attach: o, offset: n, boundary: i, placement: s, viewportOffset: this.getViewportOffset(t) }), r();
            },
            getPositionOffset(t) {
                return Fe(!1 === this.offset ? Kt(t, "--st-position-offset") : this.offset, "x" === this.axis ? "width" : "height", t) * (c(["left", "top"], this.dir) ? -1 : 1) * (this.inset ? -1 : 1);
            },
            getShiftOffset(t) {
                return "center" === this.align ? 0 : Fe(Kt(t, "--st-position-shift-offset"), "y" === this.axis ? "width" : "height", t) * (c(["left", "top"], this.align) ? 1 : -1);
            },
            getViewportOffset: (t) => Fe(Kt(t, "--st-position-viewport-offset")),
        },
    };
    var Wo = {
        mixins: [Vn, Xn, jo],
        args: "title",
        props: { delay: Number, title: String },
        data: { pos: "top", title: "", delay: 0, animation: ["st-animation-scale-up"], duration: 100, cls: "st-active" },
        beforeConnect() {
            var t;
            (this.id = qs(this, {})), (this._hasTitle = Q(this.$el, "title")), K(this.$el, { title: "", "aria-describedby": this.id }), mt((t = this.$el)) || K(t, "tabindex", "0");
        },
        disconnected() {
            this.hide(), K(this.$el, "title") || K(this.$el, "title", this._hasTitle ? this.title : null);
        },
        methods: {
            show() {
                !this.isToggled(this.tooltip || null) && this.title && (clearTimeout(this.showTimer), (this.showTimer = setTimeout(this._show, this.delay)));
            },
            async hide() {
                bt(this.$el, "input:focus") || (clearTimeout(this.showTimer), this.isToggled(this.tooltip || null) && (await this.toggleElement(this.tooltip, !1, !1)), be(this.tooltip), (this.tooltip = null));
            },
            async _show() {
                (this.tooltip = pe(this.container, `<div id="${this.id}" class="st-${this.$options.name}" role="tooltip"> <div class="st-${this.$options.name}-inner">${this.title}</div> </div>`)),
                    Lt(this.tooltip, "toggled", (t, e) => {
                        if (!e) return;
                        const i = () => this.positionAt(this.tooltip, this.$el);
                        i();
                        const [n, s] = (function (t, e, [i, n]) {
                            const s = Pe(t),
                                o = Pe(e),
                                r = [
                                    ["left", "right"],
                                    ["top", "bottom"],
                                ];
                            for (const t of r) {
                                if (s[t[0]] >= o[t[1]]) {
                                    i = t[1];
                                    break;
                                }
                                if (s[t[1]] <= o[t[0]]) {
                                    i = t[0];
                                    break;
                                }
                            }
                            const a = c(r[0], i) ? r[1] : r[0];
                            n = s[a[0]] === o[a[0]] ? a[0] : s[a[1]] === o[a[1]] ? a[1] : "center";
                            return [i, n];
                        })(this.tooltip, this.$el, this.pos);
                        this.origin = "y" === this.axis ? `${He(n)}-${s}` : `${s}-${He(n)}`;
                        const o = [
                            Wt(document, `keydown ${Ge}`, this.hide, !1, (t) => (t.type === Ge && !$t(t.target, this.$el)) || ("keydown" === t.type && t.keyCode === An)),
                            Lt([document, ...Ai(this.$el)], "scroll", i, { passive: !0 }),
                        ];
                        Wt(this.tooltip, "hide", () => o.forEach((t) => t()), { self: !0 });
                    }),
                    (await this.toggleElement(this.tooltip, !0)) || this.hide();
            },
        },
        events: {
            focus: "show",
            blur: "hide",
            [`${Qe} ${ti}`](t) {
                Jt(t) || this[t.type === Qe ? "show" : "hide"]();
            },
            [Ge](t) {
                Jt(t) && this.show();
            },
        },
    };
    var qo = {
        mixins: [ls],
        i18n: { invalidMime: "Invalid File Type: %s", invalidName: "Invalid File Name: %s", invalidSize: "Invalid File Size: %s Kilobytes Max" },
        props: { allow: String, clsDragover: String, concurrent: Number, maxSize: Number, method: String, mime: String, multiple: Boolean, name: String, params: Object, type: String, url: String },
        data: {
            allow: !1,
            clsDragover: "st-dragover",
            concurrent: 1,
            maxSize: 0,
            method: "POST",
            mime: !1,
            multiple: !1,
            name: "files[]",
            params: {},
            type: "",
            url: "",
            abort: V,
            beforeAll: V,
            beforeSend: V,
            complete: V,
            completeAll: V,
            error: V,
            fail: V,
            load: V,
            loadEnd: V,
            loadStart: V,
            progress: V,
        },
        events: {
            change(t) {
                bt(t.target, 'input[type="file"]') && (t.preventDefault(), t.target.files && this.upload(t.target.files), (t.target.value = ""));
            },
            drop(t) {
                Ro(t);
                const e = t.dataTransfer;
                (null == e ? void 0 : e.files) && (nt(this.$el, this.clsDragover), this.upload(e.files));
            },
            dragenter(t) {
                Ro(t);
            },
            dragover(t) {
                Ro(t), it(this.$el, this.clsDragover);
            },
            dragleave(t) {
                Ro(t), nt(this.$el, this.clsDragover);
            },
        },
        methods: {
            async upload(t) {
                if (!(t = f(t)).length) return;
                qt(this.$el, "upload", [t]);
                for (const e of t) {
                    if (this.maxSize && 1e3 * this.maxSize < e.size) return void this.fail(this.t("invalidSize", this.maxSize));
                    if (this.allow && !Vo(this.allow, e.name)) return void this.fail(this.t("invalidName", this.allow));
                    if (this.mime && !Vo(this.mime, e.type)) return void this.fail(this.t("invalidMime", this.mime));
                }
                this.multiple || (t = t.slice(0, 1)), this.beforeAll(this, t);
                const e = (function (t, e) {
                        const i = [];
                        for (let n = 0; n < t.length; n += e) i.push(t.slice(n, n + e));
                        return i;
                    })(t, this.concurrent),
                    i = async (t) => {
                        const n = new FormData();
                        t.forEach((t) => n.append(this.name, t));
                        for (const t in this.params) n.append(t, this.params[t]);
                        try {
                            const t = await (function (t, e) {
                                const i = { data: null, method: "GET", headers: {}, xhr: new XMLHttpRequest(), beforeSend: V, responseType: "", ...e };
                                return Promise.resolve()
                                    .then(() => i.beforeSend(i))
                                    .then(() =>
                                        (function (t, e) {
                                            return new Promise((i, n) => {
                                                const { xhr: s } = e;
                                                for (const t in e)
                                                    if (t in s)
                                                        try {
                                                            s[t] = e[t];
                                                        } catch (t) {}
                                                s.open(e.method.toUpperCase(), t);
                                                for (const t in e.headers) s.setRequestHeader(t, e.headers[t]);
                                                Lt(s, "load", () => {
                                                    0 === s.status || (s.status >= 200 && s.status < 300) || 304 === s.status ? i(s) : n(p(Error(s.statusText), { xhr: s, status: s.status }));
                                                }),
                                                    Lt(s, "error", () => n(p(Error("Network Error"), { xhr: s }))),
                                                    Lt(s, "timeout", () => n(p(Error("Network Timeout"), { xhr: s }))),
                                                    s.send(e.data);
                                            });
                                        })(t, i)
                                    );
                            })(this.url, {
                                data: n,
                                method: this.method,
                                responseType: this.type,
                                beforeSend: (t) => {
                                    const { xhr: e } = t;
                                    Lt(e.upload, "progress", this.progress);
                                    for (const t of ["loadStart", "load", "loadEnd", "abort"]) Lt(e, t.toLowerCase(), this[t]);
                                    return this.beforeSend(t);
                                },
                            });
                            this.complete(t), e.length ? await i(e.shift()) : this.completeAll(t);
                        } catch (t) {
                            this.error(t);
                        }
                    };
                await i(e.shift());
            },
        },
    };
    function Vo(t, e) {
        return e.match(
            new RegExp(
                `^${t
                    .replace(/\//g, "\\/")
                    .replace(/\*\*/g, "(\\/[^\\/]+)*")
                    .replace(/\*/g, "[^\\/]+")
                    .replace(/((?!\\))\?/g, "$1.")}$`,
                "i"
            )
        );
    }
    function Ro(t) {
        t.preventDefault(), t.stopPropagation();
    }
    var Uo = Object.freeze({
        __proto__: null,
        Countdown: tn,
        Filter: Ln,
        Lightbox: Zs,
        LightboxPanel: Js,
        Notification: Qs,
        Parallax: xo,
        Slider: Po,
        SliderParallax: Ao,
        Slideshow: zo,
        SlideshowParallax: Ao,
        Sortable: Ho,
        Tooltip: Wo,
        Upload: qo,
    });
    function Xo(t) {
        qt(document, "spectraafe:init", t),
            document.body && Ce(document.body, Go),
            new MutationObserver((t) => t.forEach(Yo)).observe(document, { subtree: !0, childList: !0 }),
            new MutationObserver((t) => t.forEach(Jo)).observe(document, { subtree: !0, attributes: !0 }),
            (t._initialized = !0);
    }
    function Yo({ addedNodes: t, removedNodes: e }) {
        for (const e of t) Ce(e, Go);
        for (const t of e) Ce(t, Zo);
    }
    function Jo({ target: t, attributeName: e }) {
        var i;
        const n = Ko(e);
        if (n) {
            if (Q(t, e)) return void Hs(n, t);
            null == (i = Ls(t, n)) || i.$destroy();
        }
    }
    function Go(t) {
        const e = Fs(t);
        for (const i in Fs(t)) _s(e[i]);
        for (const e of t.getAttributeNames()) {
            const i = Ko(e);
            i && Hs(i, t);
        }
    }
    function Zo(t) {
        const e = Fs(t);
        for (const i in Fs(t)) Bs(e[i]);
    }
    function Ko(t) {
        l(t, "data-") && (t = t.slice(5));
        const e = Ns[t];
        return e && (v(e) ? e : e.options).name;
    }
    !(function (t) {
        let e;
        (t.component = zs),
            (t.getComponents = Fs),
            (t.getComponent = Ls),
            (t.update = js),
            (t.use = function (t) {
                if (!t.installed) return t.call(null, this), (t.installed = !0), this;
            }),
            (t.mixin = function (t, e) {
                (e = (I(e) ? this.component(e) : e) || this).options = rn(e.options, t);
            }),
            (t.extend = function (t) {
                t || (t = {});
                const e = this,
                    i = function (t) {
                        As(this, t);
                    };
                return ((i.prototype = Object.create(e.prototype)).constructor = i), (i.options = rn(e.options, t)), (i.super = e), (i.extend = e.extend), i;
            }),
            Object.defineProperty(t, "container", {
                get: () => e || document.body,
                set(t) {
                    e = ke(t);
                },
            });
    })(Ds),
        (function (t) {
            (t.prototype.$mount = function (t) {
                const e = this;
                !(function (t, e) {
                    t[Os] || (t[Os] = {}), (t[Os][e.$options.name] = e);
                })(t, e),
                    (e.$options.el = t),
                    $t(t, document) && _s(e);
            }),
                (t.prototype.$destroy = function (t = !1) {
                    const e = this,
                        { el: i } = e.$options;
                    i && Bs(e),
                        Es(e, "destroy"),
                        (function (t, e) {
                            var i;
                            null == (i = t[Os]) || delete i[e.$options.name], T(t[Os]) || delete t[Os];
                        })(i, e),
                        t && be(e.$el);
                }),
                (t.prototype.$create = Hs),
                (t.prototype.$emit = function (t) {
                    ms(this, t);
                }),
                (t.prototype.$update = function (t = this.$el, e) {
                    js(t, e);
                }),
                (t.prototype.$reset = function () {
                    Bs(this), _s(this);
                }),
                (t.prototype.$getComponent = Ls),
                Object.defineProperties(t.prototype, {
                    $el: {
                        get() {
                            return this.$options.el;
                        },
                    },
                    $container: Object.getOwnPropertyDescriptor(t, "container"),
                });
        })(Ds);
    var Qo = {
        mixins: [Ki, Xn],
        props: { animation: Boolean, targets: String, active: null, collapsible: Boolean, multiple: Boolean, toggle: String, content: String, offset: Number },
        data: { targets: "> *", active: !1, animation: !0, collapsible: !0, multiple: !1, clsOpen: "st-open", toggle: "> .st-accordion-title", content: "> .st-accordion-content", offset: 0 },
        computed: {
            items: ({ targets: t }, e) => Te(t, e),
            toggles({ toggle: t }) {
                return this.items.map((e) => ke(t, e));
            },
            contents({ content: t }) {
                return this.items.map((e) => {
                    var i;
                    return (null == (i = e._wrapper) ? void 0 : i.firstElementChild) || ke(t, e);
                });
            },
        },
        watch: {
            items(t, e) {
                if (e || rt(t, this.clsOpen)) return;
                const i = (!1 !== this.active && t[Number(this.active)]) || (!this.collapsible && t[0]);
                i && this.toggle(i, !1);
            },
            toggles() {
                this.$emit();
            },
            contents(t) {
                for (const e of t) {
                    const t = rt(
                        this.items.find((t) => $t(e, t)),
                        this.clsOpen
                    );
                    tr(e, !t);
                }
                this.$emit();
            },
        },
        observe: un(),
        events: [
            {
                name: "click keydown",
                delegate() {
                    return `${this.targets} ${this.$props.toggle}`;
                },
                async handler(t) {
                    var e;
                    ("keydown" === t.type && t.keyCode !== Dn) ||
                        (t.preventDefault(),
                        null == (e = this._off) || e.call(this),
                        (this._off = (function (t) {
                            const e = Pi(t, !0);
                            let i;
                            return (
                                (function n() {
                                    i = requestAnimationFrame(() => {
                                        const { top: i } = t.getBoundingClientRect();
                                        i < 0 && (e.scrollTop += i), n();
                                    });
                                })(),
                                () => requestAnimationFrame(() => cancelAnimationFrame(i))
                            );
                        })(t.target)),
                        await this.toggle(St(this.toggles, t.current)),
                        this._off());
                },
            },
            {
                name: "shown hidden",
                self: !0,
                delegate() {
                    return this.targets;
                },
                handler() {
                    this.$emit();
                },
            },
        ],
        update() {
            const t = vt(this.items, `.${this.clsOpen}`);
            for (const e in this.items) {
                const i = this.toggles[e],
                    n = this.contents[e];
                if (!i || !n) continue;
                (i.id = qs(this, i, `-title-${e}`)), (n.id = qs(this, n, `-content-${e}`));
                const s = c(t, this.items[e]);
                K(i, { role: ce(i, "a") ? "button" : null, "aria-controls": n.id, "aria-expanded": s, "aria-disabled": !this.collapsible && t.length < 2 && s }),
                    K(n, { role: "region", "aria-labelledby": i.id }),
                    ce(n, "ul") && K(yt(n), "role", "presentation");
            }
        },
        methods: {
            toggle(t, e) {
                let i = [(t = this.items[G(t, this.items)])];
                const n = vt(this.items, `.${this.clsOpen}`);
                if ((this.multiple || c(n, i[0]) || (i = i.concat(n)), !(!this.collapsible && n.length < 2 && c(n, t))))
                    return Promise.all(
                        i.map((t) =>
                            this.toggleElement(t, !c(n, t), (t, i) => {
                                if ((at(t, this.clsOpen, i), !1 !== e && this.animation))
                                    return (async function (t, e, { content: i, duration: n, velocity: s, transition: o }) {
                                        var r;
                                        (i = (null == (r = t._wrapper) ? void 0 : r.firstElementChild) || ke(i, t)), t._wrapper || (t._wrapper = we(i, "<div>"));
                                        const a = t._wrapper;
                                        Kt(a, "overflow", "hidden");
                                        const l = P(Kt(a, "height"));
                                        await ne.cancel(a), tr(i, !1);
                                        const h = L(["marginTop", "marginBottom"], (t) => Kt(i, t)) + Be(i).height,
                                            c = l / h;
                                        (n = (s * h + n) * (e ? 1 - c : c)), Kt(a, "height", l), await ne.start(a, { height: e ? h : 0 }, n, o), xe(i), delete t._wrapper, e || tr(i, !0);
                                    })(t, i, this);
                                tr(ke(this.content, t), !i);
                            })
                        )
                    );
            },
        },
    };
    function tr(t, e) {
        t && (t.hidden = e);
    }
    var er = {
        mixins: [Ki, Xn],
        args: "animation",
        props: { animation: Boolean, close: String },
        data: { animation: !0, selClose: ".st-alert-close", duration: 150 },
        events: {
            name: "click",
            delegate() {
                return this.selClose;
            },
            handler(t) {
                t.preventDefault(), this.close();
            },
        },
        methods: {
            async close() {
                await this.toggleElement(this.$el, !1, ir), this.$destroy(!0);
            },
        },
    };
    function ir(t, e, { duration: i, transition: n, velocity: s }) {
        const o = P(Kt(t, "height"));
        return Kt(t, "height", o), ne.start(t, { height: 0, marginTop: 0, marginBottom: 0, paddingTop: 0, paddingBottom: 0, borderTop: 0, borderBottom: 0, opacity: 0 }, s * o + i, n);
    }
    var nr = {
            args: "autoplay",
            props: { automute: Boolean, autoplay: Boolean },
            data: { automute: !1, autoplay: !0 },
            connected() {
                (this.inView = "inview" === this.autoplay),
                    this.inView && !Q(this.$el, "preload") && (this.$el.preload = "none"),
                    ce(this.$el, "iframe") && !Q(this.$el, "allow") && (this.$el.allow = "autoplay"),
                    this.automute && vi(this.$el);
            },
            observe: [cn({ args: { intersecting: !1 } }), hn()],
            update: {
                read({ visible: t }) {
                    return !!bi(this.$el) && { prev: t, visible: dt(this.$el), inView: this.inView && Ti(this.$el) };
                },
                write({ prev: t, visible: e, inView: i }) {
                    !e || (this.inView && !i) ? gi(this.$el) : ((!0 === this.autoplay && !t) || i) && mi(this.$el);
                },
                events: ["resize"],
            },
        },
        sr = {
            mixins: [nr],
            props: { width: Number, height: Number },
            data: { automute: !0 },
            events: {
                "load loadedmetadata"() {
                    this.$emit("resize");
                },
            },
            observe: hn({ target: ({ $el: t }) => [or(t) || gt(t)], filter: ({ _useObjectFit: t }) => !t }),
            connected() {
                this._useObjectFit = ce(this.$el, "img", "video");
            },
            update: {
                read() {
                    if (this._useObjectFit) return;
                    const { ratio: t, cover: e } = J,
                        { $el: i, width: n, height: s } = this;
                    let o = { width: n, height: s };
                    if (!n || !s) {
                        const e = { width: i.naturalWidth || i.videoWidth || i.clientWidth, height: i.naturalHeight || i.videoHeight || i.clientHeight };
                        o = n ? t(e, "width", n) : s ? t(e, "height", s) : e;
                    }
                    const { offsetHeight: r, offsetWidth: a } = or(i) || gt(i),
                        l = e(o, { width: a + (a % 2 ? 1 : 0), height: r + (r % 2 ? 1 : 0) });
                    return !(!l.width || !l.height) && l;
                },
                write({ height: t, width: e }) {
                    Kt(this.$el, { height: t, width: e });
                },
                events: ["resize"],
            },
        };
    function or(t) {
        for (; (t = gt(t)); ) if ("static" !== Kt(t, "position")) return t;
    }
    let rr;
    var ar = {
        mixins: [Vn, jo, Xn],
        args: "pos",
        props: {
            mode: "list",
            toggle: Boolean,
            boundary: Boolean,
            boundaryX: Boolean,
            boundaryY: Boolean,
            target: Boolean,
            targetX: Boolean,
            targetY: Boolean,
            stretch: Boolean,
            delayShow: Number,
            delayHide: Number,
            autoUpdate: Boolean,
            clsDrop: String,
            animateOut: Boolean,
            bgScroll: Boolean,
            closeOnScroll: Boolean,
        },
        data: {
            mode: ["click", "hover"],
            toggle: "- *",
            boundary: !1,
            boundaryX: !1,
            boundaryY: !1,
            target: !1,
            targetX: !1,
            targetY: !1,
            stretch: !1,
            delayShow: 0,
            delayHide: 800,
            autoUpdate: !0,
            clsDrop: !1,
            animateOut: !1,
            bgScroll: !0,
            animation: ["st-animation-fade"],
            cls: "st-open",
            container: !1,
            closeOnScroll: !1,
        },
        computed: {
            boundary: ({ boundary: t, boundaryX: e, boundaryY: i }, n) => [kt(e || t, n) || window, kt(i || t, n) || window],
            target({ target: t, targetX: e, targetY: i }, n) {
                return e || (e = t || this.targetEl), i || (i = t || this.targetEl), [!0 === e ? window : kt(e, n), !0 === i ? window : kt(i, n)];
            },
        },
        created() {
            this.tracker = new li();
        },
        beforeConnect() {
            this.clsDrop = this.$props.clsDrop || `st-${this.$options.name}`;
        },
        connected() {
            it(this.$el, "st-drop", this.clsDrop),
                this.toggle &&
                    !this.targetEl &&
                    (this.targetEl = (function (t) {
                        const { $el: e } = t.$create("toggle", kt(t.toggle, t.$el), { target: t.$el, mode: t.mode });
                        return K(e, "aria-haspopup", !0), e;
                    })(this)),
                (this._style = W(this.$el.style, ["width", "height"]));
        },
        disconnected() {
            this.isActive() && (this.hide(!1), (rr = null)), Kt(this.$el, this._style);
        },
        observe: un({ target: ({ toggle: t, $el: e }) => kt(t, e), targets: ({ $el: t }) => t }),
        events: [
            {
                name: "click",
                delegate: () => ".st-drop-close",
                handler(t) {
                    t.preventDefault(), this.hide(!1);
                },
            },
            {
                name: "click",
                delegate: () => 'a[href*="#"]',
                handler({ defaultPrevented: t, current: e }) {
                    const { hash: i } = e;
                    !t && i && It(e) && !$t(i, this.$el) && this.hide(!1);
                },
            },
            {
                name: "beforescroll",
                handler() {
                    this.hide(!1);
                },
            },
            {
                name: "toggle",
                self: !0,
                handler(t, e) {
                    t.preventDefault(), this.isToggled() ? this.hide(!1) : this.show(null == e ? void 0 : e.$el, !1);
                },
            },
            {
                name: "toggleshow",
                self: !0,
                handler(t, e) {
                    t.preventDefault(), this.show(null == e ? void 0 : e.$el);
                },
            },
            {
                name: "togglehide",
                self: !0,
                handler(t) {
                    t.preventDefault(), bt(this.$el, ":focus,:hover") || this.hide();
                },
            },
            {
                name: `${Qe} focusin`,
                filter() {
                    return c(this.mode, "hover");
                },
                handler(t) {
                    Jt(t) || this.clearTimers();
                },
            },
            {
                name: `${ti} focusout`,
                filter() {
                    return c(this.mode, "hover");
                },
                handler(t) {
                    !Jt(t) && t.relatedTarget && this.hide();
                },
            },
            {
                name: "toggled",
                self: !0,
                handler(t, e) {
                    e && (this.clearTimers(), this.position());
                },
            },
            {
                name: "show",
                self: !0,
                handler() {
                    (rr = this), this.tracker.init(), K(this.targetEl, "aria-expanded", !0);
                    const t = [lr(this), cr(this), ur(this), this.autoUpdate && hr(this), this.closeOnScroll && dr(this), !this.bgScroll && Un(this.$el)];
                    Wt(this.$el, "hide", () => t.forEach((t) => t && t()), { self: !0 });
                },
            },
            {
                name: "beforehide",
                self: !0,
                handler() {
                    this.clearTimers();
                },
            },
            {
                name: "hide",
                handler({ target: t }) {
                    this.$el === t ? ((rr = this.isActive() ? null : rr), this.tracker.cancel(), K(this.targetEl, "aria-expanded", null)) : (rr = null === rr && $t(t, this.$el) && this.isToggled() ? this : rr);
                },
            },
        ],
        update: {
            write() {
                this.isToggled() && !rt(this.$el, this.clsEnter) && this.position();
            },
        },
        methods: {
            show(t = this.targetEl, e = !0) {
                if ((this.isToggled() && t && this.targetEl && t !== this.targetEl && this.hide(!1, !1), (this.targetEl = t), this.clearTimers(), !this.isActive())) {
                    if (rr) {
                        if (e && rr.isDelaying) return void (this.showTimer = setTimeout(() => bt(t, ":hover") && this.show(), 10));
                        let i;
                        for (; rr && i !== rr && !$t(this.$el, rr.$el); ) (i = rr), rr.hide(!1, !1);
                    }
                    this.container && gt(this.$el) !== this.container && pe(this.container, this.$el), (this.showTimer = setTimeout(() => this.toggleElement(this.$el, !0), (e && this.delayShow) || 0));
                }
            },
            hide(t = !0, e = !0) {
                const i = () => this.toggleElement(this.$el, !1, this.animateOut && e);
                this.clearTimers(),
                    (this.isDelayedHide = t),
                    (this.isDelaying = (function (t) {
                        const e = [];
                        return Ce(t, (t) => "static" !== Kt(t, "position") && e.push(t)), e;
                    })(this.$el).some((t) => this.tracker.movesTo(t))),
                    t && this.isDelaying ? (this.hideTimer = setTimeout(this.hide, 50)) : t && this.delayHide ? (this.hideTimer = setTimeout(i, this.delayHide)) : i();
            },
            clearTimers() {
                clearTimeout(this.showTimer), clearTimeout(this.hideTimer), (this.showTimer = null), (this.hideTimer = null), (this.isDelaying = !1);
            },
            isActive() {
                return rr === this;
            },
            position() {
                nt(this.$el, "st-drop-stack"), Kt(this.$el, this._style), (this.$el.hidden = !0);
                const t = this.target.map((t) =>
                        (function (t, e) {
                            return Di(Ai(e).find((e) => $t(t, e)));
                        })(this.$el, t)
                    ),
                    e = this.getViewportOffset(this.$el),
                    i = [
                        [0, ["x", "width", "left", "right"]],
                        [1, ["y", "height", "top", "bottom"]],
                    ];
                for (const [n, [s, o]] of i) this.axis !== s && c([s, !0], this.stretch) && Kt(this.$el, { [o]: Math.min(Pe(this.boundary[n])[o], t[n][o] - 2 * e), [`overflow-${s}`]: "auto" });
                const n = t[0].width - 2 * e;
                (this.$el.hidden = !1), Kt(this.$el, "maxWidth", ""), this.$el.offsetWidth > n && it(this.$el, "st-drop-stack"), Kt(this.$el, "maxWidth", n), this.positionAt(this.$el, this.target, this.boundary);
                for (const [n, [s, o, r, a]] of i)
                    if (this.axis === s && c([s, !0], this.stretch)) {
                        const i = Math.abs(this.getPositionOffset(this.$el)),
                            l = Pe(this.target[n]),
                            h = Pe(this.$el);
                        Kt(this.$el, { [o]: (l[r] > h[r] ? l[this.inset ? a : r] - Math.max(Pe(this.boundary[n])[r], t[n][r] + e) : Math.min(Pe(this.boundary[n])[a], t[n][a] - e) - l[this.inset ? r : a]) - i, [`overflow-${s}`]: "auto" }),
                            this.positionAt(this.$el, this.target, this.boundary);
                    }
            },
        },
    };
    function lr(t) {
        const e = () => t.$emit(),
            i = [ui(e), di(Ai(t.$el).concat(t.target), e)];
        return () => i.map((t) => t.disconnect());
    }
    function hr(t, e = () => t.$emit()) {
        return Lt([document, ...Ai(t.$el)], "scroll", e, { passive: !0 });
    }
    function cr(t) {
        return Lt(document, "keydown", (e) => {
            e.keyCode === An && t.hide(!1);
        });
    }
    function dr(t) {
        return hr(t, () => t.hide(!1));
    }
    function ur(t) {
        return Lt(document, Ge, ({ target: e }) => {
            $t(e, t.$el) ||
                Wt(
                    document,
                    `${Ke} ${ei} scroll`,
                    ({ defaultPrevented: i, type: n, target: s }) => {
                        i || n !== Ke || e !== s || (t.targetEl && $t(e, t.targetEl)) || t.hide(!1);
                    },
                    !0
                );
        });
    }
    var fr = {
        mixins: [Ki, Vn],
        props: {
            align: String,
            clsDrop: String,
            boundary: Boolean,
            dropbar: Boolean,
            dropbarAnchor: Boolean,
            duration: Number,
            mode: Boolean,
            offset: Boolean,
            stretch: Boolean,
            delayShow: Boolean,
            delayHide: Boolean,
            target: Boolean,
            targetX: Boolean,
            targetY: Boolean,
            animation: Boolean,
            animateOut: Boolean,
            closeOnScroll: Boolean,
        },
        data: { align: Xe ? "right" : "left", clsDrop: "st-dropdown", clsDropbar: "st-dropnav-dropbar", boundary: !0, dropbar: !1, dropbarAnchor: !1, duration: 200, container: !1, selNavItem: "> li > a, > ul > li > a" },
        computed: {
            dropbarAnchor: ({ dropbarAnchor: t }, e) => kt(t, e) || e,
            dropbar({ dropbar: t }) {
                return t ? (t = this._dropbar || kt(t, this.$el) || ke(`+ .${this.clsDropbar}`, this.$el)) || (this._dropbar = ke("<div></div>")) : null;
            },
            dropbarOffset: () => 0,
            dropContainer(t, e) {
                return this.container || e;
            },
            dropdowns({ clsDrop: t }, e) {
                var i;
                const n = Te(`.${t}`, e);
                if (this.dropContainer !== e)
                    for (const e of Te(`.${t}`, this.dropContainer)) {
                        const t = null == (i = this.getDropdown(e)) ? void 0 : i.targetEl;
                        !c(n, e) && t && $t(t, this.$el) && n.push(e);
                    }
                return n;
            },
            items: ({ selNavItem: t }, e) => Te(t, e),
        },
        watch: {
            dropbar(t) {
                it(t, "st-dropbar", "st-dropbar-top", this.clsDropbar, `st-${this.$options.name}-dropbar`);
            },
            dropdowns() {
                this.initializeDropdowns();
            },
        },
        connected() {
            this.initializeDropdowns();
        },
        disconnected() {
            be(this._dropbar), delete this._dropbar;
        },
        events: [
            {
                name: "mouseover focusin",
                delegate() {
                    return this.selNavItem;
                },
                handler({ current: t }) {
                    const e = this.getActive();
                    e && c(e.mode, "hover") && e.targetEl && !$t(e.targetEl, t) && !e.isDelaying && e.hide(!1);
                },
            },
            {
                name: "keydown",
                self: !0,
                delegate() {
                    return this.selNavItem;
                },
                handler(t) {
                    var e;
                    const { current: i, keyCode: n } = t,
                        s = this.getActive();
                    n === Fn && (null == s ? void 0 : s.targetEl) === i && (t.preventDefault(), null == (e = ke(pt, s.$el)) || e.focus()), pr(t, this.items, s);
                },
            },
            {
                name: "keydown",
                el() {
                    return this.dropContainer;
                },
                delegate() {
                    return `.${this.clsDrop}`;
                },
                handler(t) {
                    var e;
                    const { current: i, keyCode: n } = t;
                    if (!c(this.dropdowns, i)) return;
                    const s = this.getActive();
                    let o = -1;
                    if ((n === On ? (o = 0) : n === Mn ? (o = "last") : n === zn ? (o = "previous") : n === Fn ? (o = "next") : n === An && (null == (e = s.targetEl) || e.focus()), ~o)) {
                        t.preventDefault();
                        const e = Te(pt, i);
                        e[
                            G(
                                o,
                                e,
                                d(e, (t) => bt(t, ":focus"))
                            )
                        ].focus();
                    }
                    pr(t, this.items, s);
                },
            },
            {
                name: "mouseleave",
                el() {
                    return this.dropbar;
                },
                filter() {
                    return this.dropbar;
                },
                handler() {
                    const t = this.getActive();
                    t && c(t.mode, "hover") && !this.dropdowns.some((t) => bt(t, ":hover")) && t.hide();
                },
            },
            {
                name: "beforeshow",
                el() {
                    return this.dropContainer;
                },
                filter() {
                    return this.dropbar;
                },
                handler({ target: t }) {
                    this.isDropbarDrop(t) && (this.dropbar.previousElementSibling !== this.dropbarAnchor && ge(this.dropbarAnchor, this.dropbar), it(t, `${this.clsDrop}-dropbar`));
                },
            },
            {
                name: "show",
                el() {
                    return this.dropContainer;
                },
                filter() {
                    return this.dropbar;
                },
                handler({ target: t }) {
                    if (!this.isDropbarDrop(t)) return;
                    const e = this.getDropdown(t),
                        i = () => {
                            const e = xt(t, `.${this.clsDrop}`)
                                    .concat(t)
                                    .map((t) => Pe(t)),
                                i = Math.min(...e.map(({ top: t }) => t)),
                                n = Math.max(...e.map(({ bottom: t }) => t)),
                                s = Pe(this.dropbar);
                            Kt(this.dropbar, "top", this.dropbar.offsetTop - (s.top - i) - this.dropbarOffset), this.transitionTo(n - i + P(Kt(t, "marginBottom")) + this.dropbarOffset, t);
                        };
                    (this._observer = di([e.$el, ...e.target], i)), i();
                },
            },
            {
                name: "beforehide",
                el() {
                    return this.dropContainer;
                },
                filter() {
                    return this.dropbar;
                },
                handler(t) {
                    const e = this.getActive();
                    bt(this.dropbar, ":hover") && e.$el === t.target && c(e.mode, "hover") && e.isDelayedHide && !this.items.some((t) => e.targetEl !== t && bt(t, ":focus")) && t.preventDefault();
                },
            },
            {
                name: "hide",
                el() {
                    return this.dropContainer;
                },
                filter() {
                    return this.dropbar;
                },
                handler({ target: t }) {
                    var e;
                    if (!this.isDropbarDrop(t)) return;
                    null == (e = this._observer) || e.disconnect();
                    const i = this.getActive();
                    (i && i.$el !== t) || this.transitionTo(0);
                },
            },
        ],
        methods: {
            getActive() {
                var t;
                return c(this.dropdowns, null == (t = rr) ? void 0 : t.$el) && rr;
            },
            async transitionTo(t, e) {
                const { dropbar: i } = this,
                    n = Me(i);
                (e = n < t && e),
                    await ne.cancel([e, i]),
                    Kt(e, "clipPath", `polygon(0 0,100% 0,100% ${n}px,0 ${n}px)`),
                    Me(i, n),
                    await Promise.all([ne.start(i, { height: t }, this.duration), ne.start(e, { clipPath: `polygon(0 0,100% 0,100% ${t}px,0 ${t}px)` }, this.duration).finally(() => Kt(e, { clipPath: "" }))]).catch(V);
            },
            getDropdown(t) {
                return this.$getComponent(t, "drop") || this.$getComponent(t, "dropdown");
            },
            isDropbarDrop(t) {
                return this.getDropdown(t) && rt(t, this.clsDrop);
            },
            initializeDropdowns() {
                this.$create(
                    "drop",
                    this.dropdowns.filter((t) => !this.getDropdown(t)),
                    { ...this.$props, flip: !1, shift: !0, pos: `bottom-${this.align}`, boundary: !0 === this.boundary ? this.$el : this.boundary }
                );
            },
        },
    };
    function pr(t, e, i) {
        var n, s, o;
        const { current: r, keyCode: a } = t;
        let l = -1;
        a === On ? (l = 0) : a === Mn ? (l = "last") : a === Nn ? (l = "previous") : a === Hn ? (l = "next") : a === Pn && (null == (n = i.targetEl) || n.focus(), null == (s = i.hide) || s.call(i, !1)),
            ~l && (t.preventDefault(), null == (o = i.hide) || o.call(i, !1), e[G(l, e, e.indexOf(i.targetEl || r))].focus());
    }
    var mr = {
            mixins: [Ki],
            args: "target",
            props: { target: Boolean },
            data: { target: !1 },
            computed: {
                input: (t, e) => ke(ut, e),
                state() {
                    return this.input.nextElementSibling;
                },
                target({ target: t }, e) {
                    return t && ((!0 === t && gt(this.input) === e && this.input.nextElementSibling) || ke(t, e));
                },
            },
            update() {
                var t;
                const { target: e, input: i } = this;
                if (!e) return;
                let n;
                const s = ft(e) ? "value" : "textContent",
                    o = e[s],
                    r = (null == (t = i.files) ? void 0 : t[0]) ? i.files[0].name : bt(i, "select") && (n = Te("option", i).filter((t) => t.selected)[0]) ? n.textContent : i.value;
                o !== r && (e[s] = r);
            },
            events: [
                {
                    name: "change",
                    handler() {
                        this.$emit();
                    },
                },
                {
                    name: "reset",
                    el() {
                        return wt(this.$el, "form");
                    },
                    handler() {
                        this.$emit();
                    },
                },
            ],
        },
        gr = {
            extends: vn,
            mixins: [Ki],
            name: "grid",
            props: { masonry: Boolean, parallax: String, parallaxStart: String, parallaxEnd: String, parallaxJustify: Boolean },
            data: { margin: "st-grid-margin", clsStack: "st-grid-stack", masonry: !1, parallax: 0, parallaxStart: 0, parallaxEnd: 0, parallaxJustify: !1 },
            connected() {
                this.masonry && it(this.$el, "st-flex-top", "st-flex-wrap-top");
            },
            observe: pn({ filter: ({ parallax: t, parallaxJustify: e }) => t || e }),
            update: [
                {
                    write({ rows: t }) {
                        at(this.$el, this.clsStack, !t[0][1]);
                    },
                    events: ["resize"],
                },
                {
                    read(t) {
                        const { rows: e } = t;
                        let { masonry: i, parallax: n, parallaxJustify: s, margin: o } = this;
                        if (((n = Math.max(0, Fe(n))), !(i || n || s) || vr(e) || e[0].some((t, i) => e.some((e) => e[i] && e[i].offsetWidth !== t.offsetWidth)))) return (t.translates = t.scrollColumns = !1);
                        let r,
                            a,
                            l = (function (t, e) {
                                const i = t.flat().find((t) => rt(t, e));
                                return P(i ? Kt(i, "marginTop") : Kt(t[0][0], "paddingLeft"));
                            })(e, o);
                        i
                            ? ([r, a] = (function (t, e, i) {
                                  const n = [],
                                      s = [],
                                      o = Array(t[0].length).fill(0);
                                  let r = 0;
                                  for (let a of t) {
                                      Xe && (a = a.reverse());
                                      let t = 0;
                                      for (const l in a) {
                                          const { offsetWidth: h, offsetHeight: c } = a[l],
                                              d = i ? l : o.indexOf(Math.min(...o));
                                          br(n, d, a[l]), br(s, d, [(d - l) * h * (Xe ? -1 : 1), o[d] - r]), (o[d] += c + e), (t = Math.max(t, c));
                                      }
                                      r += t + e;
                                  }
                                  return [n, s];
                              })(e, l, "next" === i))
                            : (r = (function (t) {
                                  const e = [];
                                  for (const i of t) for (const t in i) br(e, t, i[t]);
                                  return e;
                              })(e));
                        const h = r.map((t) => L(t, "offsetHeight") + l * (t.length - 1)),
                            c = Math.max(0, ...h);
                        let d, u, f;
                        return (
                            (n || s) &&
                                ((d = h.map((t, e) => (s ? c - t + n : n / (e % 2 || 8)))),
                                s || (n = Math.max(...h.map((t, e) => t + d[e] - c))),
                                (u = Fe(this.parallaxStart, "height", this.$el, !0)),
                                (f = Fe(this.parallaxEnd, "height", this.$el, !0))),
                            { columns: r, translates: a, scrollColumns: d, parallaxStart: u, parallaxEnd: f, padding: n, height: a ? c : "" }
                        );
                    },
                    write({ height: t, padding: e }) {
                        Kt(this.$el, "paddingBottom", e || ""), !1 !== t && Kt(this.$el, "height", t);
                    },
                    events: ["resize"],
                },
                {
                    read({ rows: t, scrollColumns: e, parallaxStart: i, parallaxEnd: n }) {
                        return (!e || !vr(t)) && { scrolled: !!e && _i(this.$el, i, n) };
                    },
                    write({ columns: t, scrolled: e, scrollColumns: i, translates: n }) {
                        (e || n) &&
                            t.forEach((t, s) =>
                                t.forEach((t, o) => {
                                    let [r, a] = (n && n[s][o]) || [0, 0];
                                    e && (a += e * i[s]), Kt(t, "transform", `translate(${r}px, ${a}px)`);
                                })
                            );
                    },
                    events: ["scroll", "resize"],
                },
            ],
        };
    function vr(t) {
        return t.flat().some((t) => "absolute" === Kt(t, "position"));
    }
    function br(t, e, i) {
        t[e] || (t[e] = []), t[e].push(i);
    }
    var wr = {
        args: "target",
        props: { target: String, row: Boolean },
        data: { target: "> *", row: !0 },
        computed: { elements: ({ target: t }, e) => Te(t, e) },
        observe: hn({ target: ({ $el: t, elements: e }) => [t, ...e] }),
        update: {
            read() {
                return { rows: (this.row ? bn(this.elements) : [this.elements]).map($r) };
            },
            write({ rows: t }) {
                for (const { heights: e, elements: i } of t) i.forEach((t, i) => Kt(t, "minHeight", e[i]));
            },
            events: ["resize"],
        },
    };
    function $r(t) {
        if (t.length < 2) return { heights: [""], elements: t };
        let e = t.map(xr);
        const i = Math.max(...e);
        return { heights: t.map((t, n) => (e[n].toFixed(2) === i.toFixed(2) ? "" : i)), elements: t };
    }
    function xr(t) {
        const e = W(t.style, ["display", "minHeight"]);
        dt(t) || Kt(t, "display", "block", "important"), Kt(t, "minHeight", "");
        const i = Be(t).height - ze(t, "height", "content-box");
        return Kt(t, e), i;
    }
    var yr = {
            props: { expand: Boolean, offsetTop: Boolean, offsetBottom: Boolean, minHeight: Number },
            data: { expand: !1, offsetTop: !1, offsetBottom: !1, minHeight: 0 },
            observe: [fn({ filter: ({ expand: t }) => t }), hn({ target: ({ $el: t }) => Bi(t) })],
            update: {
                read() {
                    if (!dt(this.$el)) return !1;
                    let t = "";
                    const e = ze(this.$el, "height", "content-box"),
                        { body: i, scrollingElement: n } = document,
                        s = Pi(this.$el),
                        { height: o } = Di(s === i ? n : s),
                        r = n === s || i === s;
                    if (((t = "calc(" + (r ? "100vh" : `${o}px`)), this.expand)) {
                        t += ` - ${Be(s).height - Be(this.$el).height}px`;
                    } else {
                        if (this.offsetTop)
                            if (r) {
                                const e = De(!0 === this.offsetTop ? this.$el : kt(this.offsetTop, this.$el))[0] - De(s)[0];
                                t += e > 0 && e < o / 2 ? ` - ${e}px` : "";
                            } else t += ` - ${Kt(s, "paddingTop")}`;
                        !0 === this.offsetBottom
                            ? (t += ` - ${Be(this.$el.nextElementSibling).height}px`)
                            : k(this.offsetBottom)
                            ? (t += ` - ${this.offsetBottom}vh`)
                            : this.offsetBottom && h(this.offsetBottom, "px")
                            ? (t += ` - ${P(this.offsetBottom)}px`)
                            : I(this.offsetBottom) && (t += ` - ${Be(kt(this.offsetBottom, this.$el)).height}px`);
                    }
                    return (t += (e ? ` - ${e}px` : "") + ")"), { minHeight: t };
                },
                write({ minHeight: t }) {
                    Kt(this.$el, "minHeight", `max(${this.minHeight || 0}px, ${t})`);
                },
                events: ["resize"],
            },
        },
        Sr = {
            args: "src",
            props: { width: Number, height: Number, ratio: Number },
            data: { ratio: 1 },
            connected() {
                this.svg = this.getSvg().then((t) => {
                    if (!this._connected) return;
                    const e = (function (t, e) {
                        if (ct(e) || ce(e, "canvas")) {
                            e.hidden = !0;
                            const i = e.nextElementSibling;
                            return Ir(t, i) ? i : ge(e, t);
                        }
                        const i = e.lastElementChild;
                        return Ir(t, i) ? i : pe(e, t);
                    })(t, this.$el);
                    return this.svgEl && e !== this.svgEl && be(this.svgEl), Cr.call(this, e, t), (this.svgEl = e);
                }, V);
            },
            disconnected() {
                this.svg.then((t) => {
                    this._connected || (ct(this.$el) && (this.$el.hidden = !1), be(t), (this.svgEl = null));
                }),
                    (this.svg = null);
            },
            methods: { async getSvg() {} },
        };
    function Ir(t, e) {
        return ce(t, "svg") && ce(e, "svg") && t.innerHTML === e.innerHTML;
    }
    function Cr(t, e) {
        const i = ["width", "height"];
        let n = i.map((t) => this[t]);
        n.some((t) => t) || (n = i.map((t) => K(e, t)));
        const s = K(e, "viewBox");
        s && !n.some((t) => t) && (n = s.split(" ").slice(2)), n.forEach((e, n) => K(t, i[n], P(e) * this.ratio || null));
    }
    const kr = {
            spinner: '<svg width="30" height="30" viewBox="0 0 30 30"><circle fill="none" stroke="#000" cx="15" cy="15" r="14"/></svg>',
            totop: '<svg width="18" height="10" viewBox="0 0 18 10"><polyline fill="none" stroke="#000" stroke-width="1.2" points="1 9 9 1 17 9"/></svg>',
            marker: '<svg width="20" height="20" viewBox="0 0 20 20"><rect x="9" y="4" width="1" height="11"/><rect x="4" y="9" width="11" height="1"/></svg>',
            "close-icon":
                '<svg width="14" height="14" viewBox="0 0 14 14"><line fill="none" stroke="#000" stroke-width="1.1" x1="1" y1="1" x2="13" y2="13"/><line fill="none" stroke="#000" stroke-width="1.1" x1="13" y1="1" x2="1" y2="13"/></svg>',
            "close-large":
                '<svg width="20" height="20" viewBox="0 0 20 20"><line fill="none" stroke="#000" stroke-width="1.4" x1="1" y1="1" x2="19" y2="19"/><line fill="none" stroke="#000" stroke-width="1.4" x1="19" y1="1" x2="1" y2="19"/></svg>',
            "drop-parent-icon": '<svg width="12" height="12" viewBox="0 0 12 12"><polyline fill="none" stroke="#000" stroke-width="1.1" points="1 3.5 6 8.5 11 3.5"/></svg>',
            "nav-parent-icon": '<svg width="12" height="12" viewBox="0 0 12 12"><polyline fill="none" stroke="#000" stroke-width="1.1" points="1 3.5 6 8.5 11 3.5"/></svg>',
            "nav-parent-icon-large": '<svg width="14" height="14" viewBox="0 0 14 14"><polyline fill="none" stroke="#000" stroke-width="1.1" points="1 4 7 10 13 4"/></svg>',
            "navbar-parent-icon": '<svg width="12" height="12" viewBox="0 0 12 12"><polyline fill="none" stroke="#000" stroke-width="1.1" points="1 3.5 6 8.5 11 3.5"/></svg>',
            "navbar-toggle-icon":
                '<svg width="20" height="20" viewBox="0 0 20 20"><style>.st-navbar-toggle-animate svg&gt;[class*=&quot;line-&quot;]{transition:0.2s ease-in-out;transition-property:transform, opacity;transform-origin:center;opacity:1}.st-navbar-toggle svg&gt;.line-3{opacity:0}.st-navbar-toggle-animate[aria-expanded=&quot;true&quot;] svg&gt;.line-3{opacity:1}.st-navbar-toggle-animate[aria-expanded=&quot;true&quot;] svg&gt;.line-2{transform:rotate(45deg)}.st-navbar-toggle-animate[aria-expanded=&quot;true&quot;] svg&gt;.line-3{transform:rotate(-45deg)}.st-navbar-toggle-animate[aria-expanded=&quot;true&quot;] svg&gt;.line-1,.st-navbar-toggle-animate[aria-expanded=&quot;true&quot;] svg&gt;.line-4{opacity:0}.st-navbar-toggle-animate[aria-expanded=&quot;true&quot;] svg&gt;.line-1{transform:translateY(6px) scaleX(0)}.st-navbar-toggle-animate[aria-expanded=&quot;true&quot;] svg&gt;.line-4{transform:translateY(-6px) scaleX(0)}</style><rect class="line-1" y="3" width="20" height="2"/><rect class="line-2" y="9" width="20" height="2"/><rect class="line-3" y="9" width="20" height="2"/><rect class="line-4" y="15" width="20" height="2"/></svg>',
            "overlay-icon": '<svg width="40" height="40" viewBox="0 0 40 40"><rect x="19" y="0" width="1" height="40"/><rect x="0" y="19" width="40" height="1"/></svg>',
            "pagination-next": '<svg width="7" height="12" viewBox="0 0 7 12"><polyline fill="none" stroke="#000" stroke-width="1.2" points="1 1 6 6 1 11"/></svg>',
            "pagination-previous": '<svg width="7" height="12" viewBox="0 0 7 12"><polyline fill="none" stroke="#000" stroke-width="1.2" points="6 1 1 6 6 11"/></svg>',
            "search-icon": '<svg width="20" height="20" viewBox="0 0 20 20"><circle fill="none" stroke="#000" stroke-width="1.1" cx="9" cy="9" r="7"/><path fill="none" stroke="#000" stroke-width="1.1" d="M14,14 L18,18 L14,14 Z"/></svg>',
            "search-large":
                '<svg width="40" height="40" viewBox="0 0 40 40"><circle fill="none" stroke="#000" stroke-width="1.8" cx="17.5" cy="17.5" r="16.5"/><line fill="none" stroke="#000" stroke-width="1.8" x1="38" y1="39" x2="29" y2="30"/></svg>',
            "search-navbar":
                '<svg width="24" height="24" viewBox="0 0 24 24"><circle fill="none" stroke="#000" stroke-width="1.1" cx="10.5" cy="10.5" r="9.5"/><line fill="none" stroke="#000" stroke-width="1.1" x1="23" y1="23" x2="17" y2="17"/></svg>',
            "slidenav-next": '<svg width="14" height="24" viewBox="0 0 14 24"><polyline fill="none" stroke="#000" stroke-width="1.4" points="1.225,23 12.775,12 1.225,1"/></svg>',
            "slidenav-next-large": '<svg width="25" height="40" viewBox="0 0 25 40"><polyline fill="none" stroke="#000" stroke-width="2" points="4.002,38.547 22.527,20.024 4,1.5"/></svg>',
            "slidenav-previous": '<svg width="14" height="24" viewBox="0 0 14 24"><polyline fill="none" stroke="#000" stroke-width="1.4" points="12.775,1 1.225,12 12.775,23"/></svg>',
            "slidenav-previous-large": '<svg width="25" height="40" viewBox="0 0 25 40"><polyline fill="none" stroke="#000" stroke-width="2" points="20.527,1.5 2,20.024 20.525,38.547"/></svg>',
        },
        Tr = {
            install: function (t) {
                t.icon.add = (e, i) => {
                    const n = I(e) ? { [e]: i } : e;
                    H(n, (t, e) => {
                        (kr[e] = t), delete Lr[e];
                    }),
                        t._initialized &&
                            Ce(document.body, (e) =>
                                H(t.getComponents(e), (t) => {
                                    t.$options.isIcon && t.icon in n && t.$reset();
                                })
                            );
                };
            },
            mixins: [Sr],
            args: "icon",
            props: { icon: String },
            isIcon: !0,
            beforeConnect() {
                it(this.$el, "st-icon");
            },
            methods: {
                async getSvg() {
                    const t = (function (t) {
                        if (!kr[t]) return null;
                        Lr[t] ||
                            (Lr[t] = ke(
                                (
                                    kr[
                                        (function (t) {
                                            return Xe ? N(N(t, "left", "right"), "previous", "next") : t;
                                        })(t)
                                    ] || kr[t]
                                ).trim()
                            ));
                        return Lr[t].cloneNode(!0);
                    })(this.icon);
                    if (!t) throw "Icon not found.";
                    return t;
                },
            },
        },
        Er = {
            args: !1,
            extends: Tr,
            data: (t) => ({ icon: s(t.constructor.options.name) }),
            beforeConnect() {
                it(this.$el, this.$options.id);
            },
        },
        _r = {
            extends: Er,
            beforeConnect() {
                const t = this.$props.icon;
                this.icon = wt(this.$el, ".st-nav-primary") ? `${t}-large` : t;
            },
        },
        Br = {
            extends: Er,
            mixins: [ls],
            i18n: { toggle: "Open Search", submit: "Submit Search" },
            beforeConnect() {
                if (((this.icon = rt(this.$el, "st-search-icon") && xt(this.$el, ".st-search-large").length ? "search-large" : xt(this.$el, ".st-search-navbar").length ? "search-navbar" : this.$props.icon), !Q(this.$el, "aria-label")))
                    if (rt(this.$el, "st-search-toggle") || rt(this.$el, "st-navbar-toggle")) {
                        const t = this.t("toggle");
                        K(this.$el, "aria-label", t);
                    } else {
                        const t = wt(this.$el, "a,button");
                        if (t) {
                            K(t, "aria-label", this.t("submit"));
                        }
                    }
            },
        },
        Pr = {
            extends: Er,
            beforeConnect() {
                K(this.$el, "role", "status");
            },
            methods: {
                async getSvg() {
                    const t = await Tr.methods.getSvg.call(this);
                    return 1 !== this.ratio && Kt(ke("circle", t), "strokeWidth", 1 / this.ratio), t;
                },
            },
        },
        Ar = {
            extends: Er,
            mixins: [ls],
            beforeConnect() {
                const t = wt(this.$el, "a,button");
                K(t, "role", null !== this.role && ce(t, "a") ? "button" : this.role);
                const e = this.t("label");
                e && !Q(t, "aria-label") && K(t, "aria-label", e);
            },
        },
        Dr = {
            extends: Ar,
            beforeConnect() {
                it(this.$el, "st-slidenav");
                const t = this.$props.icon;
                this.icon = rt(this.$el, "st-slidenav-large") ? `${t}-large` : t;
            },
        },
        Mr = { extends: Ar, i18n: { label: "Open menu" } },
        Or = {
            extends: Ar,
            i18n: { label: "Close" },
            beforeConnect() {
                this.icon = "close-" + (rt(this.$el, "st-close-large") ? "large" : "icon");
            },
        },
        Nr = { extends: Ar, i18n: { label: "Open" } },
        zr = { extends: Ar, i18n: { label: "Back to top" } },
        Hr = { extends: Ar, i18n: { label: "Next page" }, data: { role: null } },
        Fr = { extends: Ar, i18n: { label: "Previous page" }, data: { role: null } },
        Lr = {};
    const jr = Ue && "loading" in HTMLImageElement.prototype;
    var Wr = {
        args: "dataSrc",
        props: { dataSrc: String, sources: String, margin: String, target: String, loading: String },
        data: { dataSrc: "", sources: !1, margin: "50%", target: !1, loading: "lazy" },
        connected() {
            var t;
            "lazy" === this.loading
                ? (jr && Ur(this.$el) && ((this.$el.loading = "lazy"), qr(this.$el)), Ur((t = this.$el)) && !Q(t, "src") && K(t, "src", 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg"></svg>'))
                : this.load();
        },
        disconnected() {
            this.img && (this.img.onload = ""), delete this.img;
        },
        observe: cn({
            target: ({ $el: t, $props: e }) => [t, ...Tt(e.target, t)],
            handler(t, e) {
                this.load(), e.disconnect();
            },
            options: ({ margin: t }) => ({ rootMargin: t }),
            filter: ({ loading: t }) => "lazy" === t,
        }),
        methods: {
            load() {
                if (this.img) return this.img;
                const t = Ur(this.$el)
                    ? this.$el
                    : (function (t, e, i) {
                          const n = new Image();
                          return (
                              (function (t, e) {
                                  if (
                                      (e = (function (t) {
                                          if (!t) return [];
                                          if (l(t, "["))
                                              try {
                                                  t = JSON.parse(t);
                                              } catch (e) {
                                                  t = [];
                                              }
                                          else t = an(t);
                                          u(t) || (t = [t]);
                                          return t.filter((t) => !T(t));
                                      })(e)).length
                                  ) {
                                      const i = Se("<picture>");
                                      for (const t of e) {
                                          const e = Se("<source>");
                                          K(e, t), pe(i, e);
                                      }
                                      pe(i, t);
                                  }
                              })(n, i),
                              Rr(t, n),
                              (n.onload = () => {
                                  qr(t, n.currentSrc);
                              }),
                              K(n, "src", e),
                              n
                          );
                      })(this.$el, this.dataSrc, this.sources);
                return tt(t, "loading"), qr(this.$el, t.currentSrc), (this.img = t);
            },
        },
    };
    function qr(t, e) {
        if (Ur(t)) {
            const e = gt(t);
            (ce(e, "picture") ? yt(e) : [t]).forEach((t) => Rr(t, t));
        } else if (e) {
            !c(t.style.backgroundImage, e) && (Kt(t, "backgroundImage", `url(${Ft(e)})`), qt(t, Vt("load", !1)));
        }
    }
    const Vr = ["data-src", "data-srcset", "sizes"];
    function Rr(t, e) {
        for (const i of Vr) {
            const n = et(t, i);
            n && K(e, i.replace(/^(data-)+/, ""), n);
        }
    }
    function Ur(t) {
        return ce(t, "img");
    }
    var Xr = {
            mixins: [Ki, to],
            props: { fill: String },
            data: { fill: "", clsWrapper: "st-leader-fill", clsHide: "st-leader-hide", attrFill: "data-fill" },
            computed: {
                fill({ fill: t }) {
                    return t || Kt(this.$el, "--st-leader-fill-content");
                },
            },
            connected() {
                [this.wrapper] = $e(this.$el, `<span class="${this.clsWrapper}">`);
            },
            disconnected() {
                xe(this.wrapper.childNodes);
            },
            observe: hn(),
            update: {
                read() {
                    return { width: Math.trunc(this.$el.offsetWidth / 2), fill: this.fill, hide: !this.matchMedia };
                },
                write({ width: t, fill: e, hide: i }) {
                    at(this.wrapper, this.clsHide, i), K(this.wrapper, this.attrFill, new Array(t).join(e));
                },
                events: ["resize"],
            },
        },
        Yr = {
            install: function ({ modal: t }) {
                function e(e, i, n = V, s = V) {
                    i = { bgClose: !1, escClose: !0, ...i, i18n: { ...t.i18n, ...(null == i ? void 0 : i.i18n) } };
                    const o = t.dialog(e(i), i);
                    return p(
                        new Promise((t) => {
                            const e = Lt(o.$el, "hide", () => t(n()));
                            Lt(o.$el, "submit", "form", (i) => {
                                i.preventDefault(), t(s(o)), e(), o.hide();
                            });
                        }),
                        { dialog: o }
                    );
                }
                (t.dialog = function (e, i) {
                    const n = t(`<div class="st-modal"> <div class="st-modal-dialog">${e}</div> </div>`, { stack: !0, role: "alertdialog", ...i });
                    return (
                        n.show(),
                        Lt(
                            n.$el,
                            "hidden",
                            async () => {
                                await Promise.resolve(), n.$destroy(!0);
                            },
                            { self: !0 }
                        ),
                        n
                    );
                }),
                    (t.alert = function (t, i) {
                        return e(
                            ({ i18n: e }) => `<div class="st-modal-body">${I(t) ? t : ue(t)}</div> <div class="st-modal-footer st-text-right"> <button class="st-button st-button-primary st-modal-close" autofocus>${e.ok}</button> </div>`,
                            i
                        );
                    }),
                    (t.confirm = function (t, i) {
                        return e(
                            ({ i18n: e }) =>
                                `<form> <div class="st-modal-body">${I(t) ? t : ue(t)}</div> <div class="st-modal-footer st-text-right"> <button class="st-button st-button-default st-modal-close" type="button">${
                                    e.cancel
                                }</button> <button class="st-button st-button-primary" autofocus>${e.ok}</button> </div> </form>`,
                            i,
                            () => Promise.reject()
                        );
                    }),
                    (t.prompt = function (t, i, n) {
                        const s = e(
                                ({ i18n: e }) =>
                                    `<form class="st-form-stacked"> <div class="st-modal-body"> <label>${I(t) ? t : ue(t)}</label> <input class="st-input" value="${
                                        i || ""
                                    }" autofocus> </div> <div class="st-modal-footer st-text-right"> <button class="st-button st-button-default st-modal-close" type="button">${
                                        e.cancel
                                    }</button> <button class="st-button st-button-primary">${e.ok}</button> </div> </form>`,
                                n,
                                () => null,
                                () => r.value
                            ),
                            { $el: o } = s.dialog,
                            r = ke("input", o);
                        return Lt(o, "show", () => r.select()), s;
                    }),
                    (t.i18n = { ok: "Ok", cancel: "Cancel" });
            },
            mixins: [Kn],
            data: { clsPage: "st-modal-page", selPanel: ".st-modal-dialog", selClose: ".st-modal-close, .st-modal-close-default, .st-modal-close-outside, .st-modal-close-full" },
            events: [
                {
                    name: "show",
                    self: !0,
                    handler() {
                        rt(this.panel, "st-margin-auto-vertical") ? it(this.$el, "st-flex") : Kt(this.$el, "display", "block"), Me(this.$el);
                    },
                },
                {
                    name: "hidden",
                    self: !0,
                    handler() {
                        Kt(this.$el, "display", ""), nt(this.$el, "st-flex");
                    },
                },
            ],
        };
    var Jr = { extends: Qo, data: { targets: "> .st-parent", toggle: "> a", content: "> ul" } },
        Gr = {
            extends: fr,
            props: { dropbarTransparentMode: Boolean },
            data: {
                clsDrop: "st-navbar-dropdown",
                selNavItem: ".st-navbar-nav > li > a,a.st-navbar-item,button.st-navbar-item,.st-navbar-item a,.st-navbar-item button,.st-navbar-toggle",
                selTransparentTarget: '[class*="st-section"]',
                dropbarTransparentMode: !1,
            },
            computed: {
                dropbarOffset() {
                    return "behind" === this.dropbarTransparentMode ? this.$el.offsetHeight : 0;
                },
                navbarContainer() {
                    return wt(this.$el, ".st-navbar-container");
                },
            },
            watch: {
                items() {
                    const t = rt(this.$el, "st-navbar-justify");
                    for (const e of Te(".st-navbar-nav, .st-navbar-left, .st-navbar-right", this.$el)) Kt(e, "flexGrow", t ? Te(".st-navbar-nav > li > a, .st-navbar-item, .st-navbar-toggle", e).length : "");
                },
            },
            disconnect() {
                var t;
                null == (t = this._colorListener) || t.call(this);
            },
            observe: [
                dn({
                    target: ({ navbarContainer: t }) => t,
                    handler() {
                        this.registerColorListener();
                    },
                    options: { attributes: !0, attributeFilter: ["class"], attributeOldValue: !0 },
                }),
                cn({
                    handler(t) {
                        (this._isIntersecting = t[0].isIntersecting), this.registerColorListener();
                    },
                    args: { intersecting: !1 },
                }),
            ],
            events: [
                {
                    name: "show",
                    el() {
                        return this.dropContainer;
                    },
                    handler({ target: t }) {
                        const e = this.getTransparentMode(t);
                        if (!e || this._mode) return;
                        const i = () =>
                            (this._mode = (function (t, ...e) {
                                for (const i of e) if (rt(t, i)) return nt(t, i), i;
                            })(this.navbarContainer, "st-light", "st-dark"));
                        if ("behind" === e) {
                            const t = Zr(this.$el);
                            t && (i(), it(this.navbarContainer, `st-${t}`));
                        }
                        "remove" === e && (i(), nt(this.navbarContainer, "st-navbar-transparent"));
                    },
                },
                {
                    name: "hide",
                    el() {
                        return this.dropContainer;
                    },
                    async handler({ target: t }) {
                        const e = this.getTransparentMode(t);
                        if (
                            e &&
                            this._mode &&
                            (await (async function () {
                                return new Promise((t) => setTimeout(t));
                            })(),
                            !this.getActive())
                        ) {
                            if ("behind" === e) {
                                const t = Zr(this.$el);
                                t && nt(this.navbarContainer, `st-${t}`);
                            }
                            it(this.navbarContainer, this._mode), "remove" === e && it(this.navbarContainer, "st-navbar-transparent"), (this._mode = null);
                        }
                    },
                },
            ],
            methods: {
                getTransparentMode(t) {
                    if (!this.navbarContainer) return;
                    if (this.dropbar && this.isDropbarDrop(t)) return this.dropbarTransparentMode;
                    const e = this.getDropdown(t);
                    return e && rt(t, "st-dropbar") ? (e.inset ? "behind" : "remove") : void 0;
                },
                registerColorListener() {
                    const t =
                        this._isIntersecting &&
                        rt(this.navbarContainer, "st-navbar-transparent") &&
                        !(function (t) {
                            do {
                                if ("normal" !== Kt(t, "mixBlendMode")) return !0;
                            } while ((t = gt(t)));
                        })(this.navbarContainer) &&
                        !Te(".st-drop", this.dropContainer)
                            .map(this.getDropdown)
                            .some((t) => t.isToggled() && (t.inset || "behind" === this.getTransparentMode(t.$el)));
                    this._colorListener
                        ? t || (this._colorListener(), (this._colorListener = null))
                        : t &&
                          (this._colorListener = (function (t, e) {
                              const i = Pi(t, !0),
                                  n = Lt(i === document.documentElement ? document : i, "scroll", e, { passive: !0 }),
                                  s = di([t, i], e);
                              return () => {
                                  n(), s.disconnect();
                              };
                          })(this.navbarContainer, () => {
                              const { left: t, top: e, height: i } = Pe(this.navbarContainer),
                                  n = { x: t, y: Math.max(0, e) + i / 2 },
                                  s = Kt(
                                      Te(this.selTransparentTarget).find((t) => U(n, Pe(t))),
                                      "--st-navbar-color"
                                  );
                              s && ot(this.navbarContainer, "st-light,st-dark", `st-${s}`);
                          }));
                },
            },
        };
    function Zr(t) {
        return Kt(t, "--st-navbar-dropbar-behind-color");
    }
    var Kr = {
        mixins: [Kn],
        args: "mode",
        props: { mode: String, flip: Boolean, overlay: Boolean, swiping: Boolean },
        data: {
            mode: "slide",
            flip: !1,
            overlay: !1,
            clsPage: "st-offcanvas-page",
            clsContainer: "st-offcanvas-container",
            selPanel: ".st-offcanvas-bar",
            clsFlip: "st-offcanvas-flip",
            clsContainerAnimation: "st-offcanvas-container-animation",
            clsSidebarAnimation: "st-offcanvas-bar-animation",
            clsMode: "st-offcanvas",
            clsOverlay: "st-offcanvas-overlay",
            selClose: ".st-offcanvas-close",
            container: !1,
            swiping: !0,
        },
        computed: {
            clsFlip: ({ flip: t, clsFlip: e }) => (t ? e : ""),
            clsOverlay: ({ overlay: t, clsOverlay: e }) => (t ? e : ""),
            clsMode: ({ mode: t, clsMode: e }) => `${e}-${t}`,
            clsSidebarAnimation: ({ mode: t, clsSidebarAnimation: e }) => ("none" === t || "reveal" === t ? "" : e),
            clsContainerAnimation: ({ mode: t, clsContainerAnimation: e }) => ("push" !== t && "reveal" !== t ? "" : e),
            transitionElement({ mode: t }) {
                return "reveal" === t ? gt(this.panel) : this.panel;
            },
        },
        observe: mn({ filter: ({ swiping: t }) => t }),
        update: {
            read() {
                this.isToggled() && !dt(this.$el) && this.hide();
            },
            events: ["resize"],
        },
        events: [
            {
                name: "touchmove",
                self: !0,
                passive: !1,
                filter() {
                    return this.overlay;
                },
                handler(t) {
                    t.cancelable && t.preventDefault();
                },
            },
            {
                name: "show",
                self: !0,
                handler() {
                    "reveal" !== this.mode || rt(gt(this.panel), this.clsMode) || (we(this.panel, "<div>"), it(gt(this.panel), this.clsMode));
                    const { body: t, scrollingElement: e } = document;
                    it(t, this.clsContainer, this.clsFlip),
                        Kt(t, "touch-action", "pan-y pinch-zoom"),
                        Kt(this.$el, "display", "block"),
                        Kt(this.panel, "maxWidth", e.clientWidth),
                        it(this.$el, this.clsOverlay),
                        it(this.panel, this.clsSidebarAnimation, "reveal" === this.mode ? "" : this.clsMode),
                        Me(t),
                        it(t, this.clsContainerAnimation),
                        this.clsContainerAnimation && (Qr().content += ",user-scalable=0");
                },
            },
            {
                name: "hide",
                self: !0,
                handler() {
                    nt(document.body, this.clsContainerAnimation), Kt(document.body, "touch-action", "");
                },
            },
            {
                name: "hidden",
                self: !0,
                handler() {
                    this.clsContainerAnimation &&
                        (function () {
                            const t = Qr();
                            t.content = t.content.replace(/,user-scalable=0$/, "");
                        })(),
                        "reveal" === this.mode && xe(this.panel),
                        nt(this.panel, this.clsSidebarAnimation, this.clsMode),
                        nt(this.$el, this.clsOverlay),
                        Kt(this.$el, "display", ""),
                        Kt(this.panel, "maxWidth", ""),
                        nt(document.body, this.clsContainer, this.clsFlip);
                },
            },
            {
                name: "swipeLeft swipeRight",
                handler(t) {
                    this.isToggled() && h(t.type, "Left") ^ this.flip && this.hide();
                },
            },
        ],
    };
    function Qr() {
        return ke('meta[name="viewport"]', document.head) || pe(document.head, '<meta name="viewport">');
    }
    var ta = {
            mixins: [Ki],
            props: { selContainer: String, selContent: String, minHeight: Number },
            data: { selContainer: ".st-modal", selContent: ".st-modal-dialog", minHeight: 150 },
            computed: { container: ({ selContainer: t }, e) => wt(e, t), content: ({ selContent: t }, e) => wt(e, t) },
            observe: hn({ target: ({ container: t, content: e }) => [t, e] }),
            update: {
                read() {
                    return !!(this.content && this.container && dt(this.$el)) && { max: Math.max(this.minHeight, Me(this.container) - (Be(this.content).height - Me(this.$el))) };
                },
                write({ max: t }) {
                    Kt(this.$el, { minHeight: this.minHeight, maxHeight: t });
                },
                events: ["resize"],
            },
        },
        ea = {
            props: ["width", "height"],
            connected() {
                it(this.$el, "st-responsive-width");
            },
            observe: hn({ target: ({ $el: t }) => [t, gt(t)] }),
            update: {
                read() {
                    return !!(dt(this.$el) && this.width && this.height) && { width: Oe(gt(this.$el)), height: this.height };
                },
                write(t) {
                    Me(this.$el, J.contain({ height: this.height, width: this.width }, t).height);
                },
                events: ["resize"],
            },
        },
        ia = {
            props: { offset: Number },
            data: { offset: 0 },
            connected() {
                !(function (t) {
                    na.size || Lt(document, "click", sa);
                    na.add(t);
                })(this);
            },
            disconnected() {
                var t;
                (t = this), na.delete(t), na.size || jt(document, "click", sa);
            },
            methods: {
                async scrollTo(t) {
                    (t = (t && ke(t)) || document.body), qt(this.$el, "beforescroll", [this, t]) && (await Ei(t, { offset: this.offset }), qt(this.$el, "scrolled", [this, t]));
                },
            },
        };
    const na = new Set();
    function sa(t) {
        if (!t.defaultPrevented) for (const e of na) $t(t.target, e.$el) && It(e.$el) && (t.preventDefault(), window.location.href !== e.$el.href && window.history.pushState({}, "", e.$el.href), e.scrollTo(Ct(e.$el)));
    }
    var oa = {
            args: "cls",
            props: { cls: String, target: String, hidden: Boolean, margin: String, repeat: Boolean, delay: Number },
            data: () => ({ cls: "", target: !1, hidden: !0, margin: "-1px", repeat: !1, delay: 0, inViewClass: "st-scrollspy-inview" }),
            computed: { elements: ({ target: t }, e) => (t ? Te(t, e) : [e]) },
            watch: {
                elements(t) {
                    this.hidden && Kt(vt(t, `:not(.${this.inViewClass})`), "opacity", 0);
                },
            },
            connected() {
                this.elementData = new Map();
            },
            disconnected() {
                for (const [t, e] of this.elementData.entries()) nt(t, this.inViewClass, (null == e ? void 0 : e.cls) || "");
                delete this.elementData;
            },
            observe: cn({
                target: ({ elements: t }) => t,
                handler(t) {
                    const e = this.elementData;
                    for (const { target: i, isIntersecting: n } of t) {
                        e.has(i) || e.set(i, { cls: et(i, "st-scrollspy-class") || this.cls });
                        const t = e.get(i);
                        (!this.repeat && t.show) || (t.show = n);
                    }
                    this.$emit();
                },
                options: ({ margin: t }) => ({ rootMargin: t }),
                args: { intersecting: !1 },
            }),
            update: [
                {
                    write(t) {
                        for (const [e, i] of this.elementData.entries())
                            !i.show || i.inview || i.queued
                                ? !i.show && i.inview && !i.queued && this.repeat && this.toggle(e, !1)
                                : ((i.queued = !0),
                                  (t.promise = (t.promise || Promise.resolve())
                                      .then(() => new Promise((t) => setTimeout(t, this.delay)))
                                      .then(() => {
                                          this.toggle(e, !0),
                                              setTimeout(() => {
                                                  (i.queued = !1), this.$emit();
                                              }, 300);
                                      })));
                    },
                },
            ],
            methods: {
                toggle(t, e) {
                    var i;
                    const n = this.elementData.get(t);
                    if (n) {
                        if ((null == (i = n.off) || i.call(n), Kt(t, "opacity", !e && this.hidden ? 0 : ""), at(t, this.inViewClass, e), at(t, n.cls), /\bbdt-animation-/.test(n.cls))) {
                            const i = () => st(t, "st-animation-[\\w-]+");
                            e ? (n.off = Wt(t, "animationcancel animationend", i)) : i();
                        }
                        qt(t, e ? "inview" : "outview"), (n.inview = e), this.$update(t);
                    }
                },
            },
        },
        ra = {
            props: { cls: String, closest: Boolean, scroll: Boolean, overflow: Boolean, offset: Number },
            data: { cls: "st-active", closest: !1, scroll: !1, overflow: !0, offset: 0 },
            computed: {
                links: (t, e) => Te('a[href*="#"]', e).filter((t) => t.hash && It(t)),
                elements({ closest: t }) {
                    return this.links.map((e) => wt(e, t || "*"));
                },
            },
            watch: {
                links(t) {
                    this.scroll && this.$create("scroll", t, { offset: this.offset });
                },
            },
            observe: [cn(), pn()],
            update: [
                {
                    read() {
                        const t = this.links.map(Ct).filter(Boolean),
                            { length: e } = t;
                        if (!e || !dt(this.$el)) return !1;
                        const i = Pi(t, !0),
                            { scrollTop: n, scrollHeight: s } = i,
                            o = Di(i);
                        let r = !1;
                        if (n === s - o.height) r = e - 1;
                        else {
                            for (let e = 0; e < t.length; e++) {
                                const i = aa(t[e]),
                                    n = this.offset + (i ? Pe(i).height : 0);
                                if (Pe(t[e]).top - o.top - n > 0) break;
                                r = +e;
                            }
                            !1 === r && this.overflow && (r = 0);
                        }
                        return { active: r };
                    },
                    write({ active: t }) {
                        const e = !1 !== t && !rt(this.elements[t], this.cls);
                        this.links.forEach((t) => t.blur());
                        for (let e = 0; e < this.elements.length; e++) at(this.elements[e], this.cls, +e === t);
                        e && qt(this.$el, "active", [t, this.elements[t]]);
                    },
                    events: ["scroll", "resize"],
                },
            ],
        };
    function aa(t) {
        return t.ownerDocument.elementsFromPoint(1, 1).find((e) => ["fixed", "sticky"].includes(Kt(e, "position")) && !e.contains(t));
    }
    var la = {
        mixins: [Ki, to],
        props: {
            position: String,
            top: null,
            bottom: null,
            start: null,
            end: null,
            offset: String,
            overflowFlip: Boolean,
            animation: String,
            clsActive: String,
            clsInactive: String,
            clsFixed: String,
            clsBelow: String,
            selTarget: String,
            showOnUp: Boolean,
            targetOffset: Number,
        },
        data: {
            position: "top",
            top: !1,
            bottom: !1,
            start: !1,
            end: !1,
            offset: 0,
            overflowFlip: !1,
            animation: "",
            clsActive: "st-active",
            clsInactive: "",
            clsFixed: "st-sticky-fixed",
            clsBelow: "st-sticky-below",
            selTarget: "",
            showOnUp: !1,
            targetOffset: !1,
        },
        computed: { selTarget: ({ selTarget: t }, e) => (t && ke(t, e)) || e },
        connected() {
            (this.start = ca(this.start || this.top)),
                (this.end = ca(this.end || this.bottom)),
                (this.placeholder = ke("+ .st-sticky-placeholder", this.$el) || ke('<div class="st-sticky-placeholder"></div>')),
                (this.isFixed = !1),
                this.setActive(!1);
        },
        beforeDisconnect() {
            this.isFixed && (this.hide(), nt(this.selTarget, this.clsInactive)), da(this.$el), be(this.placeholder), (this.placeholder = null);
        },
        observe: [fn(), pn({ target: () => document.scrollingElement }), hn({ target: ({ $el: t }) => [t, document.scrollingElement] })],
        events: [
            {
                name: "load hashchange popstate",
                el: () => window,
                filter() {
                    return !1 !== this.targetOffset;
                },
                handler() {
                    const { scrollingElement: t } = document;
                    location.hash &&
                        0 !== t.scrollTop &&
                        setTimeout(() => {
                            const e = Pe(ke(location.hash)),
                                i = Pe(this.$el);
                            this.isFixed && R(e, i) && (t.scrollTop = e.top - i.height - Fe(this.targetOffset, "height", this.placeholder) - Fe(this.offset, "height", this.placeholder));
                        });
                },
            },
            {
                name: "transitionstart",
                handler() {
                    this.transitionInProgress = Wt(this.$el, "transitionend transitioncancel", () => (this.transitionInProgress = null));
                },
            },
        ],
        update: [
            {
                read({ height: t, width: e, margin: i, sticky: n }) {
                    if (((this.inactive = !this.matchMedia || !dt(this.$el)), this.inactive)) return;
                    const s = this.isFixed && !this.transitionInProgress;
                    s && (ua(this.selTarget), this.hide()), this.active || (({ height: t, width: e } = Pe(this.$el)), (i = Kt(this.$el, "margin"))), s && this.show();
                    const o = Fe("100vh", "height"),
                        r = Me(window),
                        a = Math.max(0, document.scrollingElement.scrollHeight - o);
                    let l = this.position;
                    this.overflowFlip && t > o && (l = "top" === l ? "bottom" : "top");
                    const h = this.isFixed ? this.placeholder : this.$el;
                    let c = Fe(this.offset, "height", n ? this.$el : h);
                    "bottom" === l && (t < r || this.overflowFlip) && (c += r - t);
                    const d = this.overflowFlip ? 0 : Math.max(0, t + c - o),
                        u = Pe(h).top,
                        f = Pe(this.$el).height,
                        p = (!1 === this.start ? u : ha(this.start, this.$el, u)) - c,
                        m = !1 === this.end ? a : Math.min(a, ha(this.end, this.$el, u + t, !0) - f - c + d);
                    return (
                        (n = a && !this.showOnUp && p + c === u && m === Math.min(a, ha("!*", this.$el, 0, !0) - f - c + d) && "visible" === Kt(gt(this.$el), "overflowY")),
                        { start: p, end: m, offset: c, overflow: d, topOffset: u, height: t, elHeight: f, width: e, margin: i, top: De(h)[0], sticky: n }
                    );
                },
                write({ height: t, width: e, margin: i, offset: n, sticky: s }) {
                    if (((this.inactive || s || !this.isFixed) && da(this.$el), this.inactive)) return;
                    s && ((t = e = i = 0), Kt(this.$el, { position: "sticky", top: n }));
                    const { placeholder: o } = this;
                    Kt(o, { height: t, width: e, margin: i }), $t(o, document) || (o.hidden = !0), (s ? me : ge)(this.$el, o);
                },
                events: ["resize"],
            },
            {
                read({ scroll: t = 0, dir: e = "down", overflow: i, overflowScroll: n = 0, start: s, end: o }) {
                    const r = document.scrollingElement.scrollTop;
                    return { dir: t <= r ? "down" : "up", prevDir: e, scroll: r, prevScroll: t, offsetParentTop: Pe((this.isFixed ? this.placeholder : this.$el).offsetParent).top, overflowScroll: q(n + q(r, s, o) - q(t, s, o), 0, i) };
                },
                write(t, e) {
                    const i = e.has("scroll"),
                        { initTimestamp: n = 0, dir: s, prevDir: o, scroll: r, prevScroll: a = 0, top: l, start: h, topOffset: c, height: d } = t;
                    if (r < 0 || (r === a && i) || (this.showOnUp && !i && !this.isFixed)) return;
                    const u = Date.now();
                    if (((u - n > 300 || s !== o) && ((t.initScroll = r), (t.initTimestamp = u)), !(this.showOnUp && !this.isFixed && Math.abs(t.initScroll - r) <= 30 && Math.abs(a - r) <= 10)))
                        if (this.inactive || r < h || (this.showOnUp && (r <= h || ("down" === s && i) || ("up" === s && !this.isFixed && r <= c + d)))) {
                            if (!this.isFixed) return void (he.inProgress(this.$el) && l > r && (he.cancel(this.$el), this.hide()));
                            if (this.animation && r > c) {
                                if (rt(this.$el, "st-animation-leave")) return;
                                he.out(this.$el, this.animation).then(() => this.hide(), V);
                            } else this.hide();
                        } else this.isFixed ? this.update() : this.animation && r > c ? (this.show(), he.in(this.$el, this.animation).catch(V)) : (ua(this.selTarget), this.show());
                },
                events: ["resize", "resizeViewport", "scroll"],
            },
        ],
        methods: {
            show() {
                (this.isFixed = !0), this.update(), (this.placeholder.hidden = !1);
            },
            hide() {
                const { offset: t, sticky: e } = this._data;
                this.setActive(!1), nt(this.$el, this.clsFixed, this.clsBelow), e ? Kt(this.$el, "top", t) : Kt(this.$el, { position: "", top: "", width: "", marginTop: "" }), (this.placeholder.hidden = !0), (this.isFixed = !1);
            },
            update() {
                let { width: t, scroll: e = 0, overflow: i, overflowScroll: n = 0, start: s, end: o, offset: r, topOffset: a, height: l, elHeight: h, offsetParentTop: c, sticky: d } = this._data;
                const u = 0 !== s || e > s;
                if (!d) {
                    let s = "fixed";
                    e > o && ((r += o - c + n - i), (s = "absolute")), Kt(this.$el, { position: s, width: t, marginTop: 0 }, "important");
                }
                Kt(this.$el, "top", r - n), this.setActive(u), at(this.$el, this.clsBelow, e > a + (d ? Math.min(l, h) : l)), it(this.$el, this.clsFixed);
            },
            setActive(t) {
                const e = this.active;
                (this.active = t), t ? (ot(this.selTarget, this.clsInactive, this.clsActive), e !== t && qt(this.$el, "active")) : (ot(this.selTarget, this.clsActive, this.clsInactive), e !== t && qt(this.$el, "inactive"));
            },
        },
    };
    function ha(t, e, i, n) {
        if (!t) return 0;
        if (k(t) || (I(t) && t.match(/^-?\d/))) return i + Fe(t, "height", e, !0);
        {
            const i = !0 === t ? gt(e) : kt(t, e);
            return Pe(i).bottom - (n && i && $t(e, i) ? P(Kt(i, "paddingBottom")) : 0);
        }
    }
    function ca(t) {
        return "true" === t || ("false" !== t && t);
    }
    function da(t) {
        Kt(t, { position: "", top: "", marginTop: "", width: "" });
    }
    function ua(t) {
        Kt(t, "transition", "0s"), requestAnimationFrame(() => Kt(t, "transition", ""));
    }
    var fa = {
        mixins: [Sr],
        args: "src",
        props: { src: String, icon: String, attributes: "list", strokeAnimation: Boolean },
        data: { strokeAnimation: !1 },
        observe: [
            dn({
                async handler() {
                    const t = await this.svg;
                    t && pa.call(this, t);
                },
                options: { attributes: !0, attributeFilter: ["id", "class", "style"] },
            }),
        ],
        async connected() {
            c(this.src, "#") && ([this.src, this.icon] = this.src.split("#"));
            const t = await this.svg;
            t &&
                (pa.call(this, t),
                this.strokeAnimation &&
                    (function (t) {
                        const e = eo(t);
                        e && Kt(t, "--st-animation-stroke", e);
                    })(t));
        },
        methods: {
            async getSvg() {
                return ce(this.$el, "img") && !this.$el.complete && "lazy" === this.$el.loading
                    ? new Promise((t) => Wt(this.$el, "load", () => t(this.getSvg())))
                    : (function (t, e) {
                          e && c(t, "<symbol") && (t = va(t)[e] || t);
                          return (t = ke(t.substr(t.indexOf("<svg")))), (null == t ? void 0 : t.hasChildNodes()) && t;
                      })(await ma(this.src), this.icon) || Promise.reject("SVG not found.");
            },
        },
    };
    function pa(t) {
        const { $el: e } = this;
        it(t, K(e, "class"), "st-svg");
        for (let i = 0; i < e.style.length; i++) {
            const n = e.style[i];
            Kt(t, n, Kt(e, n));
        }
        for (const e in this.attributes) {
            const [i, n] = this.attributes[e].split(":", 2);
            K(t, i, n);
        }
        this.$el.id || tt(t, "id");
    }
    const ma = Z(async (t) => (t ? (l(t, "data:") ? decodeURIComponent(t.split(",")[1]) : (await fetch(t)).text()) : Promise.reject()));
    const ga = /<symbol([^]*?id=(['"])(.+?)\2[^]*?<\/)symbol>/g,
        va = Z(function (t) {
            const e = {};
            let i;
            for (ga.lastIndex = 0; (i = ga.exec(t)); ) e[i[3]] = `<svg ${i[1]}svg>`;
            return e;
        });
    const ba = ".st-disabled *, .st-disabled, [disabled]";
    var wa = {
            mixins: [Xn],
            args: "connect",
            props: { connect: String, toggle: String, itemNav: String, active: Number, followFocus: Boolean, swiping: Boolean },
            data: { connect: "~.st-switcher", toggle: "> * > :first-child", itemNav: !1, active: 0, cls: "st-active", attrItem: "st-switcher-item", selVertical: ".st-nav", followFocus: !1, swiping: !0 },
            computed: {
                connects: ({ connect: t }, e) => Tt(t, e),
                connectChildren() {
                    return this.connects.map((t) => yt(t)).flat();
                },
                toggles: ({ toggle: t }, e) => Te(t, e),
                children() {
                    return yt(this.$el).filter((t) => this.toggles.some((e) => $t(e, t)));
                },
            },
            watch: {
                connects(t) {
                    this.swiping && Kt(t, "touchAction", "pan-y pinch-zoom"), this.$emit();
                },
                connectChildren() {
                    let t = Math.max(0, this.index());
                    for (const e of this.connects) yt(e).forEach((e, i) => at(e, this.cls, i === t));
                    this.$emit();
                },
                toggles(t) {
                    this.$emit();
                    const e = this.index();
                    this.show(~e ? e : t[this.active] || t[0]);
                },
            },
            connected() {
                K(this.$el, "role", "tablist");
            },
            observe: [un({ targets: ({ connectChildren: t }) => t }), mn({ target: ({ connects: t }) => t, filter: ({ swiping: t }) => t })],
            events: [
                {
                    name: "click keydown",
                    delegate() {
                        return this.toggle;
                    },
                    handler(t) {
                        bt(t.current, ba) || ("click" !== t.type && t.keyCode !== Dn) || (t.preventDefault(), this.show(t.current));
                    },
                },
                {
                    name: "keydown",
                    delegate() {
                        return this.toggle;
                    },
                    handler(t) {
                        const { current: e, keyCode: i } = t,
                            n = bt(this.$el, this.selVertical);
                        let s = i === On ? 0 : i === Mn ? "last" : (i === Nn && !n) || (i === zn && n) ? "previous" : (i === Hn && !n) || (i === Fn && n) ? "next" : -1;
                        if (~s) {
                            t.preventDefault();
                            const i = this.toggles.filter((t) => !bt(t, ba)),
                                n = i[G(s, i, i.indexOf(e))];
                            n.focus(), this.followFocus && this.show(n);
                        }
                    },
                },
                {
                    name: "click",
                    el() {
                        return this.connects.concat(this.itemNav ? Tt(this.itemNav, this.$el) : []);
                    },
                    delegate() {
                        return `[${this.attrItem}],[data-${this.attrItem}]`;
                    },
                    handler(t) {
                        wt(t.target, "a,button") && (t.preventDefault(), this.show(et(t.current, this.attrItem)));
                    },
                },
                {
                    name: "swipeRight swipeLeft",
                    filter() {
                        return this.swiping;
                    },
                    el() {
                        return this.connects;
                    },
                    handler({ type: t }) {
                        this.show(h(t, "Left") ? "next" : "previous");
                    },
                },
            ],
            update() {
                var t;
                K(this.connects, "role", "presentation"), K(yt(this.$el), "role", "presentation");
                for (const e in this.toggles) {
                    const i = this.toggles[e],
                        n = null == (t = this.connects[0]) ? void 0 : t.children[e];
                    K(i, "role", "tab"), n && ((i.id = qs(this, i, `-tab-${e}`)), (n.id = qs(this, n, `-tabpanel-${e}`)), K(i, "aria-controls", n.id), K(n, { role: "tabpanel", "aria-labelledby": i.id }));
                }
                K(this.$el, "aria-orientation", bt(this.$el, this.selVertical) ? "vertical" : null);
            },
            methods: {
                index() {
                    return d(this.children, (t) => rt(t, this.cls));
                },
                show(t) {
                    const e = this.toggles.filter((t) => !bt(t, ba)),
                        i = this.index(),
                        n = G(!$(t) || c(e, t) ? t : 0, e, G(this.toggles[i], e)),
                        s = G(e[n], this.toggles);
                    this.children.forEach((t, e) => {
                        at(t, this.cls, s === e), K(this.toggles[e], { "aria-selected": s === e, tabindex: s === e ? null : -1 });
                    });
                    const o = i >= 0 && i !== n;
                    this.connects.forEach(async ({ children: t }) => {
                        const e = f(t).filter((t, e) => e !== s && rt(t, this.cls));
                        await this.toggleElement(e, !1, o), await this.toggleElement(t[s], !0, o);
                    });
                },
            },
        },
        $a = {
            mixins: [Ki],
            extends: wa,
            props: { media: Boolean },
            data: { media: 960, attrItem: "st-tab-item", selVertical: ".st-tab-left,.st-tab-right" },
            connected() {
                const t = rt(this.$el, "st-tab-left") ? "st-tab-left" : !!rt(this.$el, "st-tab-right") && "st-tab-right";
                t && this.$create("toggle", this.$el, { cls: t, mode: "media", media: this.media });
            },
        };
    var xa = {
        mixins: [to, Xn],
        args: "target",
        props: { href: String, target: null, mode: "list", queued: Boolean },
        data: { href: !1, target: !1, mode: "click", queued: !0 },
        computed: { target: ({ target: t }, e) => ((t = Tt(t || e.hash, e)).length && t) || [e] },
        connected() {
            c(this.mode, "media") || (mt(this.$el) || K(this.$el, "tabindex", "0"), !this.cls && ce(this.$el, "a") && K(this.$el, "role", "button"));
        },
        observe: un({ target: ({ target: t }) => t }),
        events: [
            {
                name: Ge,
                filter() {
                    return c(this.mode, "hover");
                },
                handler(t) {
                    (this._preventClick = null),
                        !Jt(t) ||
                            S(this._showState) ||
                            this.$el.disabled ||
                            (qt(this.$el, "focus"),
                            Wt(
                                document,
                                Ge,
                                () => qt(this.$el, "blur"),
                                !0,
                                (t) => !$t(t.target, this.$el)
                            ),
                            c(this.mode, "click") && (this._preventClick = !0));
                },
            },
            {
                name: `mouseenter mouseleave ${Qe} ${ti} focus blur`,
                filter() {
                    return c(this.mode, "hover");
                },
                handler(t) {
                    if (Jt(t) || this.$el.disabled) return;
                    const e = c(["mouseenter", Qe, "focus"], t.type),
                        i = this.isToggled(this.target);
                    e || !(!S(this._showState) || ("blur" !== t.type && bt(this.$el, ":focus")) || ("blur" === t.type && bt(this.$el, ":hover")))
                        ? (e && S(this._showState) && i !== this._showState) || ((this._showState = e ? i : null), this.toggle("toggle" + (e ? "show" : "hide")))
                        : i === this._showState && (this._showState = null);
                },
            },
            {
                name: "keydown",
                filter() {
                    return c(this.mode, "click") && !ce(this.$el, "input");
                },
                handler(t) {
                    32 === t.keyCode && (t.preventDefault(), this.$el.click());
                },
            },
            {
                name: "click",
                filter() {
                    return ["click", "hover"].some((t) => c(this.mode, t));
                },
                handler(t) {
                    let e;
                    (this._preventClick || wt(t.target, 'a[href="#"], a[href=""]') || ((e = wt(t.target, "a[href]")) && (!this.isToggled(this.target) || (e.hash && bt(this.target, e.hash))))) && t.preventDefault(),
                        !this._preventClick && c(this.mode, "click") && this.toggle();
                },
            },
            {
                name: "mediachange",
                filter() {
                    return c(this.mode, "media");
                },
                el() {
                    return this.target;
                },
                handler(t, e) {
                    e.matches ^ this.isToggled(this.target) && this.toggle();
                },
            },
        ],
        methods: {
            async toggle(t) {
                if (!qt(this.target, t || "toggle", [this])) return;
                if ((Q(this.$el, "aria-expanded") && K(this.$el, "aria-expanded", !this.isToggled(this.target)), !this.queued)) return this.toggleElement(this.target);
                const e = this.target.filter((t) => rt(t, this.clsLeave));
                if (e.length) {
                    for (const t of this.target) {
                        const i = c(e, t);
                        this.toggleElement(t, i, i);
                    }
                    return;
                }
                const i = this.target.filter(this.isToggled);
                (await this.toggleElement(i, !1)) &&
                    (await this.toggleElement(
                        this.target.filter((t) => !c(i, t)),
                        !0
                    ));
            },
        },
    };
    return (
        H(
            Object.freeze({
                __proto__: null,
                Accordion: Qo,
                Alert: er,
                Close: Or,
                Cover: sr,
                Drop: ar,
                DropParentIcon: Er,
                Dropdown: ar,
                Dropnav: fr,
                FormCustom: mr,
                Grid: gr,
                HeightMatch: wr,
                HeightViewport: yr,
                Icon: Tr,
                Img: Wr,
                Leader: Xr,
                Margin: vn,
                Marker: Nr,
                Modal: Yr,
                Nav: Jr,
                NavParentIcon: _r,
                Navbar: Gr,
                NavbarParentIcon: Er,
                NavbarToggleIcon: Mr,
                Offcanvas: Kr,
                OverflowAuto: ta,
                OverlayIcon: Er,
                PaginationNext: Hr,
                PaginationPrevious: Fr,
                Responsive: ea,
                Scroll: ia,
                Scrollspy: oa,
                ScrollspyNav: ra,
                SearchIcon: Br,
                SlidenavNext: Dr,
                SlidenavPrevious: Dr,
                Spinner: Pr,
                Sticky: la,
                Svg: fa,
                Switcher: wa,
                Tab: $a,
                Toggle: xa,
                Totop: zr,
                Video: nr,
            }),
            (t, e) => Ds.component(e, t)
        ),
        (function (t) {
            Ue &&
                window.MutationObserver &&
                (document.body
                    ? requestAnimationFrame(() => Xo(t))
                    : new MutationObserver((e, i) => {
                          document.body && (Xo(t), i.disconnect());
                      }).observe(document.documentElement, { childList: !0 }));
        })(Ds),
        H(Uo, (t, e) => Ds.component(e, t)),
        Ds
    );
});
