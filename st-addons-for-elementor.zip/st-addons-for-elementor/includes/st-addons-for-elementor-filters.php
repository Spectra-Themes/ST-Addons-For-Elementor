<?php

/**
 * Prime Slider widget filters
 * @since 3.0.0
 */

use STElementorAddon\Admin\ModuleService;


if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Settings Filters
if (!function_exists('stafe_is_dashboard_enabled')) {
    function stafe_is_dashboard_enabled() {
        return apply_filters('staddonsforelementor/settings/dashboard', true);
    }
}

if (!function_exists('st_addons_for_elementor_is_widget_enabled')) {
    function st_addons_for_elementor_is_widget_enabled($widget_id, $options = []) {

        if(!$options){
            $options = get_option('st_addons_for_elementor_active_modules', []);
        }

        if( ModuleService::is_module_active($widget_id, $options)){
            $widget_id = str_replace('-','_', $widget_id);
            return apply_filters("staddonsforelementor/widget/{$widget_id}", true);
        }
    }
}

if (!function_exists('st_addons_for_elementor_is_extend_enabled')) {
    function st_addons_for_elementor_is_extend_enabled($widget_id, $options = []) {

        if(!$options){
            $options = get_option('st_addons_for_elementor_elementor_extend', []);
        }

        if( ModuleService::is_module_active($widget_id, $options)){
            $widget_id = str_replace('-','_', $widget_id);
            return apply_filters("staddonsforelementor/extend/{$widget_id}", true);
        }
    }
}
