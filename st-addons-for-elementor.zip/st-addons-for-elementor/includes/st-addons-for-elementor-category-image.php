<?php
if (!class_exists('ST_Addons_For_ElementorCategory_Image')) {
    class ST_Addons_For_ElementorCategory_Image {
        public function __construct() {
            add_action('category_add_form_fields', [$this, 'add_new_category_image'], 10, 2);
            add_action('created_category', [$this, 'save_category_image'], 10, 2);
            add_action('category_edit_form_fields', [$this, 'edit_category_image'], 10, 2);
            add_action('edited_category', [$this, 'updated_category_image'], 10, 2);
            add_action('admin_enqueue_scripts', [$this, 'load_media_files']);
            add_action('admin_footer', [$this, 'load_category_media_scripts']);
        }

        public function add_new_category_image() { ?>
            <div class="form-field term-group-wrap">
                <label for="stafe-category-image-id"><?php esc_html_e('Image', 'st-addons-for-elementor'); ?></label>
                <input type="hidden" id="stafe-category-image-id" name="stafe-category-image-id" class="stafe-hidden-media-url" value="">
                <div id="stafe-category-image-wrapper">
                </div>
                <p>
                    <input type="button" class="button button-secondary stafe-category-image-add" id="stafe-category-image-add" name="stafe-category-image-add" value="<?php esc_html_e('Add Image', 'st-addons-for-elementor'); ?>" />
                    <input type="button" class="button button-secondary stafe-category-image-remove" id="stafe-category-image-remove" name="stafe-category-image-remove" value="<?php esc_html_e('Remove Image', 'st-addons-for-elementor'); ?>" />
                </p>
            </div>
        <?php
        }
        public function save_category_image($term_id) {
            if (isset($_POST['stafe-category-image-id']) && '' !== $_POST['stafe-category-image-id']) {
                $image = sanitize_key($_POST['stafe-category-image-id']);
                add_term_meta($term_id, 'stafe-category-image-id', $image, true);
            }
        }
        public function edit_category_image($term) { ?>
            <tr class="form-field term-group-wrap">
                <th scope="row">
                    <label for="stafe-category-image-id"><?php esc_html_e('Image', 'st-addons-for-elementor'); ?></label>
                </th>
                <td>
                    <?php $image_id = get_term_meta($term->term_id, 'stafe-category-image-id', true); ?>
                    <input type="hidden" id="stafe-category-image-id" name="stafe-category-image-id" value="<?php echo esc_attr($image_id); ?>">
                    <div id="stafe-category-image-wrapper">
                        <?php if ($image_id) { ?>
                            <?php echo wp_get_attachment_image($image_id, 'thumbnail'); ?>
                        <?php } ?>
                    </div>
                    <p>
                        <input type="button" class="button button-secondary stafe-category-image-add" id="stafe-category-image-add" name="stafe-category-image-add" value="<?php esc_html_e('Add Image', 'st-addons-for-elementor'); ?>" />
                        <input type="button" class="button button-secondary stafe-category-image-remove" id="stafe-category-image-remove" name="stafe-category-image-remove" value="<?php esc_html_e('Remove Image', 'st-addons-for-elementor'); ?>" />
                    </p>
                </td>
            </tr>
        <?php
        }

        public function updated_category_image($term_id) {
            if (isset($_POST['stafe-category-image-id']) && '' !== $_POST['stafe-category-image-id']) {
                $image = sanitize_key($_POST['stafe-category-image-id']);
                update_term_meta($term_id, 'stafe-category-image-id', $image);
            } else {
                update_term_meta($term_id, 'stafe-category-image-id', '');
            }
        }

        public function load_media_files() {
            wp_enqueue_media();
        }

        public function load_category_media_scripts() { ?>
            <script>
                (function($) {
                    $(document).ready(function() {
                        $(".stafe-category-image-add.button").on("click", function() {
                            let UPK = wp.media({
                                multiple: false
                            });
                            UPK.on('select', function() {
                                let attachment = UPK.state().get('selection').first().toJSON();
                                $("#stafe-category-image-id").val(attachment.id);
                                $("#stafe-category-image-url").val(attachment.url);
                                $("#stafe-category-image-wrapper").html(`<img width="150" height="150" src='${attachment.url}' />`);
                            });
                            UPK.open();
                            return false;
                        });
                        $('.stafe-category-image-remove.button').on("click", function() {
                            $('#stafe-category-image-id').val('');
                            $('#stafe-category-image-wrapper').html('<img width=150; height=150; class="stafe-media-hidden-image" src="" style="margin:0; max-height:100px; padding:0;float:none;" />');
                        })
                    });
                })(jQuery);
            </script>
<?php }
    }

    new ST_Addons_For_ElementorCategory_Image();
}
