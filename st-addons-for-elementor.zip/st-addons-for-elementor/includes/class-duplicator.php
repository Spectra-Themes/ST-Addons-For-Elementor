<?php

namespace STElementorAddon\Includes;

use Elementor\Core\Files\CSS\Post as Post_CSS;

if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Duplicator Class
 */

if (!class_exists('SpectraThemes_Duplicator')) :
    class SpectraThemes_Duplicator {

        public function __construct() {
            add_action('admin_action_spectrat_duplicate_as_draft', [$this, 'spectrat_duplicate_as_draft']);
            add_filter('post_row_actions', [$this, 'spectrat_duplicate_post_link'], 10, 2);
            add_filter('page_row_actions', [$this, 'spectrat_duplicate_post_link'], 10, 2);
        }

        public function spectrat_duplicate_as_draft() {

            if (!current_user_can('edit_posts')) {
                wp_die('You don\'t have permission to duplicate it; please go back!');
            }

            if (!(isset($_GET['post']) || isset($_POST['post']) || (isset($_REQUEST['action']) && 'spectrat_duplicate_as_draft' == $_REQUEST['action']))) {
                wp_die('No post to duplicate has been supplied!');
            }

            /**
             * Nonce verification
             */
            if (!isset($_GET['duplicate_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['duplicate_nonce'])), basename(__FILE__))) {
                return;
            }

            /**
             * get the original post id
             */
            $post_id = (isset($_GET['post']) ? absint($_GET['post']) : absint($_POST['post']));
            /**
             * and all the original post data then
             */
            $post = get_post($post_id);

            /**
             * if you don't want current user to be the new post author,
             */
            $current_user_id    = get_current_user_id();

            if (current_user_can('manage_options') || current_user_can('edit_others_posts')) {
                $this->duplicate_edit_post($post_id);
            } else if (current_user_can('edit_posts') && $post->post_author == $current_user_id) {
                $this->duplicate_edit_post($post_id);
            } else {
                wp_die('You don\'t have permission to duplicate it; please go back!');
            }
        }

        /**
         * duplicate edit post
         */
        public function duplicate_edit_post($post_id) {
            global $wpdb;
            /**
             * and all the original post data then
             */
            $spectrat_post = get_post($post_id);
            /**
             * if you don't want current user to be the new post author,
             * then change next couple of lines to this: $new_post_author = $post->post_author;
             */
            $spectrat_current_user    = wp_get_current_user();
            $spectrat_new_post_author = $spectrat_current_user->ID;

            /**
             * if post data exists, create the post duplicate
             */
            if (isset($spectrat_post) && $spectrat_post != null) {
                /**
                 * new post data array
                 */
                $spectrat_args = [
                    'post_status'    => 'draft',
                    /* translators: %1$s is the original post title */
                    'post_title'     => sprintf(__('%1$s - [Duplicated]', 'st-addons-for-elementor'), $spectrat_post->post_title),
                    'post_type'      => $spectrat_post->post_type,
                    'post_name'      => $spectrat_post->post_name,
                    'post_content'   => $spectrat_post->post_content,
                    'post_excerpt'   => $spectrat_post->post_excerpt,
                    'post_author'    => $spectrat_new_post_author,
                    'post_parent'    => $spectrat_post->post_parent,
                    'post_password'  => $spectrat_post->post_password,
                    'comment_status' => $spectrat_post->comment_status,
                    'ping_status'    => $spectrat_post->ping_status,
                    'menu_order'     => $spectrat_post->menu_order,
                    'to_ping'        => $spectrat_post->to_ping,
                ];

                /**
                 * insert the post by wp_insert_post() function
                 */
                $spectrat_new_post_id = wp_insert_post($spectrat_args);

                /**
                 * get all current post terms ad set them to the new post draft
                 */
                $spectrat_taxonomies = get_object_taxonomies($spectrat_post->post_type);

                /**
                 * returns array of taxonomy names for post type, ex array("category", "post_tag");
                 */

                foreach ($spectrat_taxonomies as $spectrat_taxonomy) {
                    $spectrat_post_terms = wp_get_object_terms($post_id, $spectrat_taxonomy, ['fields' => 'slugs']);
                    wp_set_object_terms($spectrat_new_post_id, $spectrat_post_terms, $spectrat_taxonomy, false);
                }

                /**
                 * duplicate all post meta just in two SQL queries
                 */
                $cache_key = 'spectrat_post_meta_infos_' . $spectrat_post_id;
                
                $spectrat_post_meta_infos = wp_cache_get($cache_key);

                if (false === $spectrat_post_meta_infos) {
                    // If cache is empty, query the database

                    $spectrat_post_meta_infos = get_post_meta($spectrat_post_id);
                
                    // Store the retrieved post meta info in the cache
                    wp_cache_set($cache_key, $spectrat_post_meta_infos);
                }

                if (is_array($spectrat_post_meta_infos)) {

                    foreach ($spectrat_post_meta_infos as $spectrat_meta_info) {
                        // Prepare the data
                        $spectrat_meta_value = wp_slash($spectrat_meta_info->meta_value);
                
                        // Attempt to insert each meta info
                        add_post_meta($spectrat_new_post_id, $spectrat_meta_info->meta_key, $spectrat_meta_value);
                    }

                    /**
                     * fix template type issues
                     */
                    $source_type = get_post_meta($post_id, '_elementor_template_type', true);
                    delete_post_meta($spectrat_new_post_id, '_elementor_template_type');
                    update_post_meta($spectrat_new_post_id, '_elementor_template_type', $source_type);

                    wp_cache_delete('spectrat_post_meta_infos_' . $spectrat_new_post_id);
                }

                $css = Post_CSS::create($spectrat_new_post_id);
                $css->update();

                /**
                 * finally, redirect to the edit post screen for the new draft
                 */

                $spectrat_all_post_types = get_post_types([], 'names');

                foreach ($spectrat_all_post_types as $spectrat_key => $spectrat_value) {
                    $spectrat_names[] = $spectrat_key;
                }

                $current_post_type = get_post_type($post_id);

                if (is_array($spectrat_names) && in_array($current_post_type, $spectrat_names)) {
                    wp_redirect(admin_url('edit.php?post_type=' . $current_post_type));
                }

                exit;
            } else {
                wp_die('Failed. Not Found Post: ' . esc_html(intval($post_id)));
            }
        }


        public function spectrat_duplicate_post_link($actions, $post) {

            if (current_user_can('manage_options') || current_user_can('edit_others_posts')) {
                if ($post->post_type == 'post') {
                    $actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=spectrat_duplicate_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce') . '" title="Duplicate this post" rel="permalink">' . esc_html_x("Duplicate Post", "Admin String", "st-addons-for-elementor") . '</a>';
                } elseif ($post->post_type == 'page') {
                    $actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=spectrat_duplicate_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce') . '" title="Duplicate this page" rel="permalink">' . esc_html_x("Duplicate Page", "Admin String", "st-addons-for-elementor") . '</a>';
                } elseif ($post->post_type == 'elementor_library') {
                    $actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=spectrat_duplicate_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce') . '" title="Duplicate this template" rel="permalink">' . esc_html_x("Duplicate Template", "Admin String", "st-addons-for-elementor") . '</a>';
                }
            }
            return $actions;
        }
    }
endif;


new SpectraThemes_Duplicator();
