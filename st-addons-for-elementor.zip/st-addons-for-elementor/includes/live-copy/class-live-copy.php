<?php

namespace STElementorAddon\Includes\LiveCopy;


if (!defined('ABSPATH')) exit; // Exit if accessed directly
class SpectraThemes_Live_Copy {

    function __construct() {
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'live_copy_enqueue']);
    }

    public function live_copy_enqueue() {
        wp_enqueue_script('st-live-copy-scripts', STAFE_URL . 'includes/live-copy/assets/st-live-copy.js', ['jquery', 'elementor-editor'], STAFE_VER, true);
    }
}
new SpectraThemes_Live_Copy();
