!(function (e) {
    "use strict";
    e(window).on("elementor:init", function () {
        var t = elementor.modules.controls.BaseData.extend({
            isTitlesReceived: !1,
            addControlSpinner: function () {
                this.ui.select.prop("disabled", !0), this.$el.find(".elementor-control-title").after('<span class="elementor-control-spinner">&nbsp;<i class="eicon-spinner eicon-animation-spin"></i>&nbsp;</span>');
            },
            prepareArgs: function () {
                var e = this,
                    t = e.model.get("query_args");
                return (
                    _.isObject(t) || (t = {}),
                    t.widget_props &&
                        _.isObject(t.widget_props) &&
                        _.each(t.widget_props, function (s, n) {
                            t[n] = e.container.settings.get(s);
                        }),
                    t
                );
            },
            getQueryData: function () {
                var t = e.extend({}, this.prepareArgs());
                return delete t.widget_props, t;
            },
            getValueTitles: function () {
                var t = this,
                    s = this.getControlValue();
                if (s) {
                    _.isArray(s) || (s = [s]);
                    var n = { action: stafe_dynamic_select.action, security: stafe_dynamic_select.nonce, ids: s },
                        i = e.extend({}, n, t.getQueryData());
                    e.ajax({
                        url: ajaxurl,
                        type: "POST",
                        data: i,
                        before: t.addControlSpinner(),
                        success: function (e) {
                            if (((t.isTitlesReceived = !0), e.success)) {
                                var s = {};
                                _.each(e.data, function (e) {
                                    s[e.id] = e.text;
                                }),
                                    t.model.set("options", s),
                                    t.ui.select && t.ui.select.data("select2") && t.render();
                            } else console.log("server errors:", e.data);
                        },
                    });
                }
            },
            onReady: function () {
                var t = this;
                this.ui.select.select2({
                    minimumInputLength: t.model.get("minlen") ? t.model.get("minlen") : 2,
                    placeholder: t.model.get("placeholder") ? t.model.get("placeholder") : "Type & search",
                    allowClear: !0,
                    ajax: {
                        url: ajaxurl,
                        dataType: "json",
                        method: "post",
                        delay: 300,
                        data: function (s) {
                            var n = { action: stafe_dynamic_select.action, security: stafe_dynamic_select.nonce, search_text: s.term };
                            return e.extend({}, n, t.getQueryData());
                        },
                        processResults: function (e) {
                            return e.success && e.data ? { results: e.data } : (console.log("server error!", e.data), { results: [{ id: -1, text: "No Data found", disabled: !0 }] });
                        },
                        cache: !0,
                    },
                }),
                    this.isTitlesReceived || this.getValueTitles();
            },
            onBeforeDestroy: function () {
                this.ui.select.data("select2") && this.ui.select.select2("destroy"), this.$el.remove();
            },
        });
        elementor.addControlView("stafe-dynamic-select", t);
    });
})(jQuery);
