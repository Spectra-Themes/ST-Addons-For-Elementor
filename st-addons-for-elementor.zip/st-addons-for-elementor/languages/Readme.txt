//////////////////////////////////////////////////////////////////////////////
//																	        //
// 	Don't translate your language here.								        //
// 	We have dedicated translation app for translate ST Addons For Elementor	//
// 	Please go to https://spectrathemes.com/                         		//
// 	Register there and modify your language and download it. 		        //
//																	        //
//////////////////////////////////////////////////////////////////////////////

