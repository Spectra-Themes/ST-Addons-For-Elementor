//////////////////////////////////////////////////////////////////////
//																	//
// 	Don't translate your language here.								//
// 	We have dedicated translation app for translate ST Addons For Elementor	//
// 	Please go to https://spectrathemes.co/stafe-translate/			 		//
// 	Register there and modify your language and download it. 		//
//																	//
//////////////////////////////////////////////////////////////////////

