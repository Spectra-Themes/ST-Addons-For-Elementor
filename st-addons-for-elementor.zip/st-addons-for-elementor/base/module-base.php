<?php

namespace STElementorAddon\Base;

use Elementor\Widget_Base;
use STElementorAddon\ST_Addons_For_ElementorLoader;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

abstract class Module_Base extends Widget_Base {

    protected function stafe_is_edit_mode(){

        if(ST_Addons_For_ElementorLoader::elementor()->preview->is_preview_mode() || ST_Addons_For_ElementorLoader::elementor()->editor->is_edit_mode() ){
            return true;
        }

        return false;
    }
}