<?php
/**
 * Plugin Name: ST Addons For Elementor
 * Plugin URI: https://spectrathemes.com/st-addons-for-elementor/
 * Description: ST Addons is the most versatile, intuitive, and easy-to-use Popular Page Builder extension. Our goal is to empower you with the tools to achieve your vision efficiently and swiftly compared to other Elementor addons. Choosing us isn't just a choice; it's a necessity if you aim to outpace your competitors in website creation. The best part? You can design anything without needing to write a single line of code.
 * Version: 0.0.1
 * Author: SpectraThemes
 * Author URI: https://spectrathemes.com/
 * Text Domain: st-addons-for-elementor
 * Domain Path: /languages
 * License: GPL3
 * Elementor requires at least: 3.0.0
 * Elementor tested up to: 3.22.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

error_reporting(E_ALL);
ini_set('display_errors', '1');

// Some pre define value for easy use
define( 'STAFE_VER', '3.11.6' );
define( 'STAFE__FILE__', __FILE__ );


if ( ! function_exists( '_is_stafe_pro_installed' ) ) {

	function _is_stafe_pro_installed() {

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$file_path         = 'st-addons-for-elementor-pro/st-addons-for-elementor-pro.php';
		$installed_plugins = get_plugins();

		return isset( $installed_plugins[ $file_path ] );
	}
}

if ( ! function_exists( '_is_stafe_pro_activated' ) ) {

	function _is_stafe_pro_activated() {

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$file_path = 'st-addons-for-elementor-pro/st-addons-for-elementor-pro.php';

		if ( is_plugin_active( $file_path ) ) {
			return true;
		}

		return false;
	}
}



// Helper function here
require_once( dirname( __FILE__ ) . '/includes/helper.php' );

if ( ! _is_stafe_pro_activated() ) {
	require_once STAFE_INC_PATH . 'class-pro-widget-map.php';
}

if ( function_exists( 'stafe_license_validation' ) && true !== stafe_license_validation() ) {
	require_once STAFE_INC_PATH . 'class-pro-widget-map.php';
}

require_once( dirname( __FILE__ ) . '/includes/utils.php' );

// Widgets filters here
require_once( STAFE_INC_PATH . 'st-addons-for-elementor-filters.php' );


/**
 * Plugin load here correctly
 * Also loaded the language file from here
 */
function st_addons_for_elementor_load_plugin() {
	load_plugin_textdomain( 'st-addons-for-elementor', false, basename( dirname( __FILE__ ) ) . '/languages' );

	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'st_addons_for_elementor_fail_load' );

		return;
	}

	// Element pack widget and assets loader
	require_once( STAFE_PATH . 'loader.php' );
}

add_action( 'plugins_loaded', 'st_addons_for_elementor_load_plugin' );


/**
 * Check Elementor installed and activated correctly
 */
function st_addons_for_elementor_fail_load() {
	$screen = get_current_screen();
	if ( isset( $screen->parent_file ) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id ) {
		return;
	}

	$plugin = 'elementor/elementor.php';

	if ( _is_elementor_installed() ) {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );
		$admin_message  = '<p>' . esc_html__( 'Ops! ST Addons For Elementor not working because you need to activate the Elementor plugin first.', 'st-addons-for-elementor' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__( 'Activate Elementor Now', 'st-addons-for-elementor' ) ) . '</p>';
	} else {
		if ( ! current_user_can( 'install_plugins' ) ) {
			return;
		}
		$install_url   = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );
		$admin_message = '<p>' . esc_html__( 'Ops! ST Addons For Elementor not working because you need to install the Elementor plugin', 'st-addons-for-elementor' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__( 'Install Elementor Now', 'st-addons-for-elementor' ) ) . '</p>';
	}

	echo '<div class="error">' . $admin_message . '</div>';
}

/**
 * Check the elementor installed or not
 */
if ( ! function_exists( '_is_elementor_installed' ) ) {

	function _is_elementor_installed() {
		$file_path         = 'elementor/elementor.php';
		$installed_plugins = get_plugins();

		return isset( $installed_plugins[ $file_path ] );
	}
}



/**
 * Review Automation Integration
 */

if ( ! function_exists( 'rc_stafe_core_plugin' ) ) {
	function rc_stafe_core_plugin() {

		require_once STAFE_INC_PATH . 'feedback-hub/start.php';

		rc_dynamic_init( array(
			'sdk_version'  => '1.0.0',
			'plugin_name'  => 'ST Addons For Elementor',
			'plugin_icon'  => STAFE_ASSETS_URL . 'images/logo.svg',
			'slug'         => 'st_addons_for_elementor_options',
			'menu'         => array(
				'slug' => 'st_addons_for_elementor_options',
			),
			'review_url'   => 'https://spectrathemes.com/st-addons-for-elementor',
			'plugin_title' => 'Yay! Great that you\'re using ST Addons For Elementor',
			'plugin_msg'   => '<p>Loved using ST Addons For Elementor on your website? Share your experience in a review and help us spread the love to everyone right now. Good words will help the community.</p>',
		) );

	}
	add_action( 'admin_init', 'rc_stafe_core_plugin' );
}

/**
 * DCI SDK Integration
 */

if ( ! function_exists( 'dci_plugin_st_addons_for_elementor' ) ) {
	function dci_plugin_st_addons_for_elementor() {

		// Include DCI SDK.
		require_once dirname( __FILE__ ) . '/dci/start.php';

		dci_dynamic_init( array(
			'sdk_version'  => '1.1.0',
			'product_id'   => 1,
			'plugin_name'  => 'ST Addons For Elementor', // make simple, must not empty
			'plugin_title' => 'Love using ST Addons For Elementor? Congrats 🎉 ( Never miss an Important Update )', // You can describe your plugin title here
			'plugin_icon'  => STAFE_ASSETS_URL . 'images/logo.svg',
			'api_endpoint' => 'https://analytics.spectrathemes.com/wp-json/dci/v1/data-insights',
			'menu'         => array(
				'slug' => 'st_addons_for_elementor_options',
			),
			'public_key'   => 'pk_yLi403LFWfR4A0u4CKhH9uLR9pmZ0KOF',
			'is_premium'   => false,
			'plugin_msg'   => '<p>Be Top-contributor by sharing non-sensitive plugin data and create an impact to the global WordPress community today! You can receive valuable emails periodically.</p>',
		) );

	}
	add_action( 'admin_init', 'dci_plugin_st_addons_for_elementor' );
}