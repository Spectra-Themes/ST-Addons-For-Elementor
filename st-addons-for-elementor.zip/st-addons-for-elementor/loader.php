<?php

namespace STElementorAddon;

use Elementor\Plugin;
use STElementorAddon\Admin;

if (!defined('ABSPATH')) {
	exit;
} // Exit if accessed directly

/**
 * Main class for element pack
 */
class ST_Addons_For_ElementorLoader {

	/**
	 * @var ST_Addons_For_ElementorLoader
	 */
	private static $_instance;

	/**
	 * @var Manager
	 */
	private $_modules_manager;

	private $classes_aliases;

	public $elements_data = [
		'sections' => [],
		'columns'  => [],
		'widgets'  => [],
	];

	/**
	 * @return string
	 * @deprecated
	 *
	 */
	public function get_version() {
		return STAFE_VER;
	}

	/**
	 * return active theme
	 */
	public function get_theme() {
		return wp_get_theme();
	}

	/**
	 * Throw error on object clone
	 *
	 * The whole idea of the singleton design pattern is that there is a single
	 * object therefore, we don't want the object to be cloned.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function __clone() {
		// Cloning instances of the class is forbidden
		_doing_it_wrong(__FUNCTION__, esc_html__('Cheatin&#8217; huh?', 'st-addons-for-elementor'), '1.6.0');
	}

	/**
	 * Disable unserializing of the class
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function __wakeup() {
		// Unserializing instances of the class is forbidden
		_doing_it_wrong(__FUNCTION__, esc_html__('Cheatin&#8217; huh?', 'st-addons-for-elementor'), '1.6.0');
	}

	/**
	 * @return Plugin
	 */

	public static function elementor() {
		return Plugin::$instance;
	}

	/**
	 * @return ST_Addons_For_ElementorLoader
	 */
	public static function instance() {
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		do_action('spectrathemes_st_addons_for_elementor/init');
		return self::$_instance;
	}


	/**
	 * we loaded module manager + admin php from here
	 * @return [type] [description]
	 */
	private function _includes() {
		$category_image = st_addons_for_elementor_option('category_image', 'st_addons_for_elementor_other_settings', 'off');
		$duplicator = st_addons_for_elementor_option('duplicator', 'st_addons_for_elementor_other_settings', 'off');
		$live_copy = st_addons_for_elementor_option('live-copy', 'st_addons_for_elementor_other_settings', 'off');


		// Admin settings controller
		require_once STAFE_ADMIN_PATH . 'module-settings.php';

		// Dynamic Select control
		require STAFE_INC_PATH . 'controls/select-input/dynamic-select-input-module.php';
		require STAFE_INC_PATH . 'controls/select-input/dynamic-select.php';
		
		//require STAFE_PATH . 'base/st-addons-for-elementor-base.php';

		// all widgets control from here
		require_once STAFE_PATH . 'traits/global-widget-controls.php';
		require_once STAFE_PATH . 'traits/global-swiper-functions.php';
		require_once STAFE_INC_PATH . 'modules-manager.php';

		if ($category_image == 'on') {
			require STAFE_INC_PATH . 'st-addons-for-elementor-category-image.php';
		}
		// if ($category_image == 'on') {
		require STAFE_INC_PATH . 'st-addons-for-elementor-metabox.php';
		// }

		if (!class_exists('SpectraThemes_Duplicator')) {
			if ($duplicator == 'on') {
				require STAFE_PATH . 'includes/class-duplicator.php';
			}
		}

		if (!class_exists('SpectraThemes_Live_Copy')) {
			if (($live_copy == 'on') && (!is_plugin_active('live-copy-paste/live-copy-paste.php'))) {
				require_once STAFE_PATH . 'includes/live-copy/class-live-copy.php';
			}
		}

		if (is_admin()) {
			if (!defined('STAFE_CH')) {
				// Notice class
				require_once STAFE_ADMIN_PATH . 'admin-notice.php';
				require_once STAFE_ADMIN_PATH . 'admin.php';

				// Load admin class for admin related content process
				new Admin();
			}
		}
	}

	/**
	 * Autoloader function for all classes files
	 *
	 * @param  [type] class [description]
	 *
	 * @return [type]        [description]
	 */
	public function autoload($class) {
		if (0 !== strpos($class, __NAMESPACE__)) {
			return;
		}

		$class_to_load = $class;

		if (!class_exists($class_to_load)) {
			$filename = strtolower(
				preg_replace(
					['/^' . __NAMESPACE__ . '\\\/', '/([a-z])([A-Z])/', '/_/', '/\\\/'],
					['', '$1-$2', '-', DIRECTORY_SEPARATOR],
					$class_to_load
				)
			);
			$filename = STAFE_PATH . $filename . '.php';

			if (is_readable($filename)) {
				include($filename);
			}
		}
	}

	public function register_site_styles() {
		$direction_suffix = is_rtl() ? '.rtl' : '';

		wp_register_style('stafe-all-styles', STAFE_ASSETS_URL . 'css/stafe-all-styles' . $direction_suffix . '.css', [], STAFE_VER);
		wp_register_style('stafe-font', STAFE_ASSETS_URL . 'css/stafe-font' . $direction_suffix . '.css', [], STAFE_VER);
	}

	public function register_site_scripts() {

		// $suffix = '.min';

		wp_register_script('goodshare', STAFE_ASSETS_URL . 'vendor/js/goodshare.min.js', ['jquery'], '4.1.2', true);
		wp_register_script('scrolline', STAFE_ASSETS_URL . 'vendor/js/jquery.scrolline.min.js', ['jquery'], '4.1.2', true);
		wp_register_script('news-ticker-js', STAFE_ASSETS_URL . 'vendor/js/newsticker.min.js', ['jquery'], '', true);
		wp_register_script('stafe-animations', STAFE_ASSETS_URL . 'js/extensions/stafe-animations.min.js', ['jquery'], '', true);

		wp_register_script('stafe-all-scripts', STAFE_ASSETS_URL . 'js/stafe-all-scripts.min.js', [
			'jquery',
			'elementor-frontend',
			'scrolline'
		], STAFE_VER, true);
	}


	/**
	 * Loading site related style from here.
	 * @return [type] [description]
	 */
	public function enqueue_site_styles() {

		$direction_suffix = is_rtl() ? '.rtl' : '';

		wp_enqueue_style('stafe-site', STAFE_ASSETS_URL . 'css/stafe-site' . $direction_suffix . '.css', [], STAFE_VER);
	}


	/**
	 * Loading site related script that needs all time such as spectraafe.
	 * @return [type] [description]
	 */
	public function enqueue_site_scripts() {

		// $suffix = '.min';


		wp_enqueue_script('stafe-site', STAFE_ASSETS_URL . 'js/stafe-site.min.js', [
			'jquery',
			'elementor-frontend'
		], STAFE_VER, true); // tooltip file should be separate

		$script_config = [
			'ajaxurl'       => admin_url('admin-ajax.php'),
			'nonce'         => wp_create_nonce('stafe-site'),
			'mailchimp'     => [
				'subscribing' => esc_html_x('Subscribing you please wait...', 'Mailchimp String', 'st-addons-for-elementor'),
			],
			'elements_data' => $this->elements_data,
		];


		$script_config = apply_filters('st_addons_for_elementor/frontend/localize_settings', $script_config);

		// TODO for editor script
		wp_localize_script('stafe-site', 'STAddonsElementorConfig', $script_config);
	}

	public function enqueue_editor_scripts() {

		// $suffix = '.min';

		wp_enqueue_script('stafe-editor', STAFE_ASSETS_URL . 'js/stafe-editor.min.js', [
			'backbone-marionette',
			'elementor-common-modules',
			'elementor-editor-modules',
		], STAFE_VER, true);

		$_is_stafe_pro_activated = false;
		if (function_exists('stafe_license_validation') && true === stafe_license_validation()) {
			$_is_stafe_pro_activated = true;
		}

		$localize_data = [
			'pro_installed'  => _is_stafe_pro_activated(),
			'pro_license_activated'  => $_is_stafe_pro_activated,
			'promotional_widgets'   => [],
		];

		if (!$_is_stafe_pro_activated) {
			$pro_widget_map = new \STElementorAddon\Includes\Pro_Widget_Map();
			$localize_data['promotional_widgets'] = $pro_widget_map->get_pro_widget_map();
		}

		wp_localize_script('stafe-editor', 'StAddonsForElementorConfigEditor', $localize_data);
	}

	/**
	 * Load editor editor related style from here
	 * @return [type] [description]
	 */
	public function enqueue_preview_styles() {
		$direction_suffix = is_rtl() ? '.rtl' : '';

		wp_enqueue_style('stafe-preview', STAFE_ASSETS_URL . 'css/stafe-preview' . $direction_suffix . '.css', '', STAFE_VER);
	}


	public function enqueue_editor_styles() {
		$direction_suffix = is_rtl() ? '.rtl' : '';

		wp_enqueue_style('stafe-editor', STAFE_ASSETS_URL . 'css/stafe-editor' . $direction_suffix . '.css', '', STAFE_VER);
		wp_enqueue_style('stafe-font', STAFE_URL . 'assets/css/stafe-font' . $direction_suffix . '.css', [], STAFE_VER);
	}

	/**
	 * initialize the category
	 * @return [type] [description]
	 */
	public function st_addons_for_elementor_init() {
		$this->_modules_manager = new Manager();
	}

	/**
	 * initialize the category
	 * @return [type] [description]
	 */
	public function st_addons_for_elementor_category_register() {

		$elementor = Plugin::$instance;

		// Add element category in panel
		$elementor->elements_manager->add_category(STAFE_SLUG, ['title' => STAFE_TITLE, 'icon' => 'font']);
	}


	private function setup_hooks() {
		add_action('elementor/elements/categories_registered', [$this, 'st_addons_for_elementor_category_register']);
		add_action('elementor/init', [$this, 'st_addons_for_elementor_init']);

		add_action('elementor/editor/after_enqueue_styles', [$this, 'enqueue_editor_styles']);

		add_action('elementor/frontend/before_register_styles', [$this, 'register_site_styles']);
		add_action('elementor/frontend/before_register_scripts', [$this, 'register_site_scripts']);

		add_action('elementor/preview/enqueue_styles', [$this, 'enqueue_preview_styles']);
		// add_action('elementor/editor/before_enqueue_scripts', [$this, 'enqueue_editor_scripts']);
		add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueue_editor_scripts']);

		add_action('elementor/frontend/after_register_styles', [$this, 'enqueue_site_styles']);
		add_action('elementor/frontend/before_enqueue_scripts', [$this, 'enqueue_site_scripts']);
	}

	/**
	 * ST_Addons_For_ElementorLoader constructor.
	 */
	private function __construct() {
		// Register class automatically
		spl_autoload_register([$this, 'autoload']);
		// Include some backend files
		$this->_includes();

		// Finally hooked up all things here
		$this->setup_hooks();
	}
}

if (!defined('STAFE_TESTS')) {
	// In tests we run the instance manually.
	ST_Addons_For_ElementorLoader::instance();
}

// handy fundtion for push data
function st_addons_for_elementor_config() {
	return ST_Addons_For_ElementorLoader::instance();
}
