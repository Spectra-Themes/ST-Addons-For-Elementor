<?php

namespace STElementorAddon\Traits;

use STElementorAddon\Utils;

defined('ABSPATH') || die();

trait Global_Widget_Functions {

	/**
	 * New Image Render Method With Lazy Load Support
	 *
	 * @return void
	 */

	function render_image($image_id, $size) {
		$placeholder_image_src = Utils::get_placeholder_image_src();
		$image_src             = wp_get_attachment_image_src($image_id, $size);

		if (!$image_src) {
			printf('<img class="stafe-img" src="%1$s" alt="%2$s">', esc_url($placeholder_image_src), esc_html(get_the_title()));
		} else {
			print(wp_get_attachment_image(
				$image_id,
				$size,
				false,
				[
					'class' => 'stafe-img',
					'alt'   => esc_html(get_the_title())
				]
			));
		}
	}

	/**
	 * Old Image Render Method
	 * Not Using Anymore
	 * @return void
	 */
	function __render_image($image_id, $size) {
		$placeholder_image_src = Utils::get_placeholder_image_src();
		$image_src = wp_get_attachment_image_src($image_id, $size);
		if (!$image_src) {
			$image_src = $placeholder_image_src;
		} else {
			$image_src = $image_src[0];
		}
?>
		<img class="stafe-img" src="<?php echo esc_url($image_src); ?>" alt="<?php echo esc_html(get_the_title()); ?>">
	<?php
	}

	function render_title($widget_name) {
		$settings = $this->get_settings_for_display();
		if (!$this->get_settings('show_title')) {
			return;
		}
		apply_filters('stae/' . $widget_name . '/before/title', '');
		printf('<%1$s class="stafe-title"><a href="%2$s" title="%3$s" class="title-animation-%4$s" >%3$s</a></%1$s>', esc_attr(Utils::get_valid_html_tag($settings['title_tags'])), esc_url(get_permalink()), esc_html(get_the_title()), esc_attr($settings['title_style']));
		apply_filters('stae/' . $widget_name . '/after/title', '');
	}



	function render_category() {
		if (!$this->get_settings('show_category')) {
			return;
		}
	?>
		<div class="stafe-category">
			<?php echo wp_kses_post(stafe_get_category($this->get_settings('posts_source'))); ?>
		</div>
	<?php
	}

	function render_date() {
		$settings = $this->get_settings_for_display();
		if (!$this->get_settings('show_date')) {
			return;
		}
	?>
		<div class="stafe-date">
			<?php if ($settings['human_diff_time'] == 'yes') {
				echo esc_html(st_addons_for_elementor_post_time_diff(($settings['human_diff_time_short'] == 'yes') ? 'short' : ''));
			} else {
				echo get_the_date();
			} ?>
		</div>

		<?php if ($settings['show_time']) : ?>
			<div class="stafe-post-time">
				<i class="stafe-icon-clock" aria-hidden="true"></i>
				<?php echo esc_html(get_the_time()); ?>
			</div>
		<?php endif; ?>
	<?php
	}

	function render_excerpt($excerpt_length) {
		if (!$this->get_settings('show_excerpt')) {
			return;
		}
		$strip_shortcode = $this->get_settings_for_display('strip_shortcode');
	?>
		<div class="stafe-text">
			<?php
			if (has_excerpt()) {
				the_excerpt();
			} else {
				echo wp_kses_post(st_addons_for_elementor_custom_excerpt($excerpt_length, $strip_shortcode));
			}
			?>
		</div>
	<?php
	}

	function render_post_format() {
		$settings = $this->get_settings_for_display();

		if (!$settings['show_post_format']) {
			return;
		}
	?>
		<div class="stafe-post-format">
			<a href="<?php echo esc_url(get_permalink()) ?>">
				<?php if (has_post_format('aside')) : ?>
					<i class="stafe-icon-aside" aria-hidden="true"></i>
				<?php elseif (has_post_format('gallery')) : ?>
					<i class="stafe-icon-gallery" aria-hidden="true"></i>
				<?php elseif (has_post_format('link')) : ?>
					<i class="stafe-icon-link" aria-hidden="true"></i>
				<?php elseif (has_post_format('image')) : ?>
					<i class="stafe-icon-image" aria-hidden="true"></i>
				<?php elseif (has_post_format('quote')) : ?>
					<i class="stafe-icon-quote" aria-hidden="true"></i>
				<?php elseif (has_post_format('status')) : ?>
					<i class="stafe-icon-status" aria-hidden="true"></i>
				<?php elseif (has_post_format('video')) : ?>
					<i class="stafe-icon-video" aria-hidden="true"></i>
				<?php elseif (has_post_format('audio')) : ?>
					<i class="stafe-icon-music" aria-hidden="true"></i>
				<?php elseif (has_post_format('chat')) : ?>
					<i class="stafe-icon-chat" aria-hidden="true"></i>
				<?php else : ?>
					<i class="stafe-icon-post" aria-hidden="true"></i>
				<?php endif; ?>
			</a>
		</div>
<?php
	}
}
